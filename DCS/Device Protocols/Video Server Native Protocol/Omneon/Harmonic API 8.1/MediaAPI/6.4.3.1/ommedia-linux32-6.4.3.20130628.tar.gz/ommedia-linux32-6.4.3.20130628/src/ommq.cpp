#include "ommedia.h"
#include <stdio.h>
//#include <process.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>

bool pauseAtExit = false;

int pauseExec(int value)
{
    char buf[ 128 ];
    if (pauseAtExit) {
        printf("hit return to exit...");
        if (fgets(buf, sizeof(buf) - 1, stdin));
    }
    omMediaShutdown();
    return value;
}

static void fatalErr(const char* format, ...)
{
    va_list argList;
    va_start(argList, format);
    vfprintf(stderr, format, argList);
    exit(pauseExec(1));
}

static void usage(const char* format, ...)
{
    va_list argList;
    va_start(argList, format);
    vfprintf(stderr, format, argList);
    printf("Usage: ommq <options> movie [movie...]\n"
           "where the options are:\n"
           "  -lsamples in addition to the movie and track summary, sizes\n"
           "            and offsets for every frame in the movie\n"
           "  -ldata    list the (string) user data items\n"
           "  -sdata name=value\n"
           "  -sdata N:name=value\n"
           "            set user data items on the movie (first\n"
           "            usage), or on track N (second usage)\n"
           "  -genumid  generate a new UMID in the movie\n"
           "  -q        quiet; by default ommq shows a summary of all the\n"
           "            tracks; -q suppresses that (useful w/ -din & -dout,\n"
           "            or if you just want -lsamples output.\n"
           "  -din N    change the default in frame to N\n"
           "  -dout N   change the default out frame to N\n"
           "  -fframe N change the first frame to N\n"
           "  -tc HH:MM:SS.FF\n"
           "            change the start timecode to HH:MM:SS.FF\n"
           "  -afd N    change the afd value of the first video track to N,\n"
           "            which should be given as an 8-bit hex number. See\n"
           "            SMPTE 2016-1 for the allowed values.\n"
           "  -pause    wait for a CR from user before exiting\n");
    exit(pauseExec(1));
}

static char* getArg(int& argc, char**& argv)
{
    if (argc <= 1)
        fatalErr("missing %s argument\n", *argv);
    argc--, argv++;
    return *argv;
}

const char* toString(OmFrameRate fr)
{
    switch(fr) {
    default:                return "bad FPS";
    case omFrmRate23_976Hz: return "23.976 FPS";
    case omFrmRate24Hz:     return "24 FPS";
    case omFrmRate25Hz:     return "25 FPS";
    case omFrmRate29_97Hz:  return "29.97 FPS";
    case omFrmRate30Hz:     return "30 FPS";
    case omFrmRate50Hz:     return "50 FPS";
    case omFrmRate59_94Hz:  return "59.94 FPS";
    case omFrmRate60Hz:     return "60 FPS";
    }
};

const char* toString(OmVideoSampleRatio vsr)
{
    switch(vsr) {
    default:                return "bad VSR";
    case omVideoSampleNone: return "none";
    case omVideoSample420:  return "4:2:0";
    case omVideoSample411:  return "4:1:1";
    case omVideoSample422:  return "4:2:2";
    case omVideoSample444:  return "4:4:4";
    }
};

const char* toString(OmVideoAspectRatio asr)
{
    switch (asr) {
    default: return ""; 
    case omVideoAspect4to3: return "4:3";
    case omVideoAspect16to9: return "16:9";
    }
};

const char *gopToString(const OmMediaSummary& oms)
{
    if (oms.specific.mpeg.gopLength == 1)
        return "iframe";
    return "lgop";
}

const char* typeToString(const OmMediaSummary& oms)
{
    const char *typeStr = "";

    switch(oms.type) {
    case omMediaMpegVideo:      return "mpeg video";
    case omMediaMpegStdAudio:   typeStr = "mpeg audio"; break;
    case omMediaMpegAc3:        typeStr = "mpeg ac3 audio"; break;
    case omMediaPcmAudio:       typeStr = "pcm audio"; break;
    case omMediaDvVideo:        return "dv video";
    case omMediaDvAudio:        typeStr = "dv audio"; break;
    case omMediaRec601Video:    return "rec601 video";
    case omMediaHdcam:          return "hdcam video";
    case omMediaVbi:            return "vertical blanking";
    case omMediaData:           return "data";
    case omMediaDnxhd:          return "dnxhd video";
    case omMediaMpeg4Video:     return "mpeg4 video";
    case omMediaAvc:            return "avc video";
    case omMediaAlawAudio:      typeStr = "alaw audio"; break;
    case omMediaMpeg1System:    typeStr = "mpeg1 system"; break;
    case omMedia436mAnc:        return "436Vanc";
    case omMedia436mVbi:        return "436Vbi";

    // unknown/unmapped
    case omMediaUnknown:
    case omMediaTc:
    case omMediaDisplay:
                                return "unknown media";
    }

    // audio makes it to here...
    static char buf[ 128 ];
    sprintf(buf, "%d-channel,  %s", oms.channels,
        oms.specific.audio.bigEndian ? "big-endian" : "little-endian",
        typeStr);
    return buf;
};

const char* bitrateToString(uint bitrate)
{
    static char buf[ 64 ];
    if (bitrate >= 1000000)
        sprintf(buf, "%0.1fMbit", float(bitrate) / 1000000);
    else
        sprintf(buf, "%0.1fKbit", float(bitrate) / 1000);
    return buf;
}

struct QueryInfo {
    enum { maxInputs = 16 };
    enum { maxDataValues = 16 };

    struct PropInfo {
        int track;
        OmMediaProperty* prop;
        PropInfo() : track(-1), prop(0) {}
        void set(int t, const char* name, const char* value)
        {
            track = t; 
            prop = new OmMediaProperty(name, value);
        }
    };

    char* inputs[ maxInputs ];
    int nInputs;
    PropInfo props[ maxDataValues ];
    int nProperties;
    uint defaultIn;
    uint defaultOut;
    uint firstFrame;
    uint tcHours;
    uint tcMinutes;
    uint tcSeconds;
    uint tcFrames;
    bool quiet;
    bool listSamples;
    bool listData;
    bool generateUmid;
    uint afd;

    QueryInfo()
      : nInputs(0),
        nProperties(0),
        defaultIn(~0),
        defaultOut(~0),
        firstFrame(~0),
        tcHours(~0),
        tcMinutes(~0),
        tcSeconds(~0),
        tcFrames(~0),
        quiet(false),
        listSamples(false),
        listData(false),
        generateUmid(false),
        afd(~0)
    {}
};

void query(QueryInfo& q)
{
    // this is declared locally so that when this function returns,
    // it will properly be destroyed and resources released.  This means
    // that you should not call exit in here which would bypass the destructor.
    OmMediaQuery omq;
    bool writable = q.defaultIn != (unsigned int)~0
                 || q.defaultOut != (unsigned int)~0
                 || q.firstFrame != (unsigned int)~0
                 || q.tcHours != (unsigned int)~0
                 || q.nProperties > 0
                 || q.generateUmid
                 || q.afd != (unsigned int)~0;

    for (int i = 0; i < q.nInputs; i++) {
        if (! omq.setFile(q.inputs[i], writable)) {
            printf("can't open %s\n", q.inputs[i]);
            continue;
        }
        OmMediaInfo omi;
        if (! omq.getMovieInfo(omi)) {
            printf("can't get movie info for %s\n", q.inputs[i]);
            continue;
        }

        OmMediaSample sample;
        OmMediaSummary* oms = 0;
        uint trkIdx;
        if (omi.numTracks != 0) {
            oms = new OmMediaSummary[ omi.numTracks ];
            for (trkIdx = 0; trkIdx < omi.numTracks; trkIdx++) {
                if (! omq.getTrackInfo(trkIdx, oms[trkIdx])) {
                    printf("can't get track info for %s, track %d\n",
                        q.inputs[i], trkIdx);
                    break;
                }
            }
            if (trkIdx != omi.numTracks)
                continue;
        }

        if (! q.quiet) {
            uint tch, tcm, tcs, tcf;
            omq.getStartTimecode(tch, tcm, tcs, tcf);
            const char* umid = omq.getUmid();
            printf("%s: %s, %d tracks, %d frames (%d-%d)\n"
                "  def in/out=%d/%d, precharge=%d, first frame=%d, tc=%02d:%02d:%02d.%02d\n"
                "  clipProperties=%s, umid=%s, afd=0x%x\n",
                q.inputs[i], toString(omi.frameRate), omi.numTracks,
                omi.lastFrame - omi.firstFrame, omi.firstFrame,
                omi.lastFrame, omi.defaultIn, omi.defaultOut,
                omi.numPrecharge, omi.firstFrame, tch, tcm, tcs, tcf, 
                omi.clipProperties ? omi.clipProperties : "",
                umid ? umid : "",
                (uint)omq.getVideoAfd());

            enum { pathLength = 256 };
            char path[ pathLength ];
            for (uint mediaIdx = 0; mediaIdx < omi.numMedia; mediaIdx++) {
                OmMediaId id = omq.getMediaId(mediaIdx);
                if (id == 0 || ! omq.getPath(id, path, pathLength))
                    printf("  media %d: 0x%x bad?\n", mediaIdx, id);
                else
                    printf("  media %d: %s\n", mediaIdx, path);
            }
            for (trkIdx = 0; trkIdx < omi.numTracks; trkIdx++) {
                if (oms[trkIdx].type == omMediaMpegVideo) {
                    printf("  track %d: %d-bit %s %s,%s,%s,%s\n",
                        trkIdx, oms[trkIdx].bitsPerUnit,
                        gopToString(oms[trkIdx]),
                        typeToString(oms[trkIdx]),
                        toString(oms[trkIdx].aspect), toString(oms[trkIdx].vsr),
                        bitrateToString(oms[trkIdx].bitrate));
                } else {
                    printf("  track %d: %d-bit %s,%s,%s,%s\n",
                        trkIdx, oms[trkIdx].bitsPerUnit,
                        typeToString(oms[trkIdx]),
                        toString(oms[trkIdx].aspect), toString(oms[trkIdx].vsr),
                        bitrateToString(oms[trkIdx].bitrate));
                }
            }
        }

        if (q.listSamples) {
            for (int f = omi.firstFrame - omi.numPrecharge; f < int(omi.lastFrame); f++) {
                for (trkIdx = 0; trkIdx < omi.numTracks; trkIdx++) {
                    if (! omq.getSampleInfo(trkIdx, f, sample))
                        continue;
                    printf("t%d,f%d: ", trkIdx, f);
                    for (uint c = 0; c < sample.nChunks; c++)
                        printf("%db@%I64d",
                            sample.chunk[c].nBytes, sample.chunk[c].offset);
                    printf("\n");
                }
            }
        }

        if (q.listData) {
            const OmMediaPropertyList* propList = omq.getProperties();
            for (uint i = 0; i < propList->getPropertyCount(); i++) {
                if (i == 0)
                    printf("movie user data:\n");
                const OmMediaProperty* prop = propList->get(i);
                printf("  %d: %s=%s\n",
                    i, prop->getName(), prop->getValue());
            }
            for (trkIdx = 0; trkIdx < omi.numTracks; trkIdx++) {
                propList = omq.getProperties(trkIdx);
                for (uint i = 0; i < propList->getPropertyCount(); i++) {
                    if (i == 0)
                        printf("  track %d:\n", trkIdx);
                    const OmMediaProperty* prop = propList->get(i);
                    printf("    %d: %s=%s\n",
                        i, prop->getName(), prop->getValue());
                }
            }
        }

        if (q.generateUmid) {
            printf("generate umid %s\n", omq.generateUmid() ? "success" : "failure");
        }

        if (q.defaultIn != (unsigned int)~0 && ! omq.setDefaultIn(q.defaultIn)) {
            printf("can't set default in to %d in %s\n",
                q.defaultIn, q.inputs[i]);
        }
        if (q.defaultOut != (unsigned int)~0 && ! omq.setDefaultOut(q.defaultOut)) {
            printf("can't set default out to %d in %s\n",
                q.defaultOut, q.inputs[i]);
        }
        if (q.firstFrame != (unsigned int)~0 && ! omq.setFirstFrame(q.firstFrame)) {
            printf("can't set first frame to %d in %s\n",
                q.firstFrame, q.inputs[i]);
        }
        if (q.tcHours != (unsigned int)~0 && q.tcMinutes != (unsigned int)~0 &&
            q.tcSeconds != (unsigned int)~0 && q.tcFrames != (unsigned int)~0 &&
            ! omq.setStartTimecode(q.tcHours, q.tcMinutes, q.tcSeconds, q.tcFrames)) {
            printf("can't set start timecode to %02d:%02d:%02d.%02d in %s\n",
                q.tcHours, q.tcMinutes, q.tcSeconds, q.tcFrames, q.inputs[i]);
        }

        if (q.afd != (unsigned int)~0 && ! omq.setVideoAfd(q.afd)) {
            printf("can't set afd to 0x%x in %s\n",
                q.afd, q.inputs[i]);
        }

        if (q.nProperties > 0) {
            for (int i = 0; i < q.nProperties; i++) {
                if (q.props[i].track >= 0) {
                    if (! omq.setProperty(q.props[i].track, *q.props[i].prop)) {
                        printf("can't set property %s=%s on track %d\n",
                            q.props[i].prop->getName(),
                            q.props[i].prop->getValue(),
                            q.props[i].track);
                    }
                } else {
                    if (! omq.setProperty(*q.props[i].prop)) {
                        printf("can't set property %s=%s\n",
                            q.props[i].prop->getName(),
                            q.props[i].prop->getValue());
                    }
                }
            }
        }
    }
}

int main(int argc, char**argv)
{
    QueryInfo q;

    for (argc--, argv++; argc; argc--, argv++) {
        if (strcmp(*argv, "-din") == 0) {
            if (q.defaultIn != (unsigned int)~0)
                usage("-din specified twice\n");
            q.defaultIn = atoi(getArg(argc, argv));
        } else if (strcmp(*argv, "-dout") == 0) {
            if (q.defaultOut != (unsigned int)~0)
                usage("-dout specified twice\n");
            q.defaultOut = atoi(getArg(argc, argv));
        } else if (strcmp(*argv, "-fframe") == 0) {
            if (q.firstFrame != (unsigned int)~0)
                usage("-fframe specified twice\n");
            q.firstFrame = atoi(getArg(argc, argv));
        } else if (strcmp(*argv, "-tc") == 0) {
            if (sscanf(getArg(argc, argv), "%d:%d:%d.%d",
                &q.tcHours, &q.tcMinutes, &q.tcSeconds, &q.tcFrames) != 4)
                usage("incorrect timecode");
        } else if (strcmp(*argv, "-sdata") == 0) {
            if (q.nProperties >= QueryInfo::maxDataValues) {
                usage("too many properties specified (max %d)\n",
                    QueryInfo::maxDataValues);
            }
            const char* p0 = getArg(argc, argv);
            const char* p1 = p0;
            int track = -1;
            while (*p1 && *p1 != '=' && *p1 != ':')
                p1++;
            if (*p1 == ':') {
                track = atoi(p0);
                for (p0 = ++p1; *p1 && *p1 != '=' && *p1 != ':'; )
                    p1++;
            }                

            if (*p1 == '\0' || *(p1+1) == '\0')
                usage("-data arg should have the form name=value\n");
            int length = p1-p0;
            char* pName = new char[ length+1 ];
            strncpy(pName, p0, length);
            pName[ length ] = '\0';
            q.props[q.nProperties++].set(track, pName, ++p1);
            delete pName;
        } else if (strcmp(*argv, "-q") == 0) {
            q.quiet = true;
        } else if (strcmp(*argv, "-pause") == 0) {
            pauseAtExit = true;
        } else if (strcmp(*argv, "-lsamples") == 0) {
            q.listSamples = true;
        } else if (strcmp(*argv, "-ldata") == 0) {
            q.listData = true;
        } else if (strcmp(*argv, "-genumid") == 0) {
            q.generateUmid = true;
        } else if (strcmp(*argv, "-afd") == 0) {
            if (q.afd != (unsigned int)~0)
                usage("-afd specified twice\n");
            sscanf(getArg(argc, argv), "%x", &q.afd);
        } else if (**argv == '-') {
            usage("unknown flag: %s\n", *argv);
        } else {
            if (q.nInputs >= QueryInfo::maxInputs) {
                fatalErr("too many inputs specified (max %d)\n",
                    QueryInfo::maxInputs);
            }
            q.inputs[ q.nInputs++ ] = *argv;
        }
    }

    if (q.nInputs == 0)
        usage("no files specified\n");

    query(q);

    return pauseExec ( 0 );
}

/*
    Omneon MediaAPI Sample File: ommdata.cpp

    Sample cli application demonstrating using the OmMediaQuery
    class to access ancillary data in a movie via getFrameData()
    and setFrameData().

    Only supports Omneon Neutral Format Type-2

    Copyright (c) 2010 Harmonic Inc.
*/

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string>

// Media API Includes
#include "ommedia.h"


enum OmmdataConst { 
    BufferSize = 128*1024,   // Ommdata internal buffer size
    FramesPerLoop = 10       // Number of frames to service at a time
};

// Omneon Neutral Format Header Versions
enum OmneonFrameHeaderType {
    omVancType1     = 0x01,
    omVancType2     = 0x02,
    omUnknown,
};

// Size in bytes of the different frame headers
enum OmneonFrameHeaderSize {
    omVancType1size = 4,
    omVancType2size = 6,
};

enum Omneon_Sample_Coding {
    OSC_8bit_luma_frame_wrap = 0,
    OSC_unknown,
};

bool pauseAtExit = false;
uint bufferSize = BufferSize;

int pauseExec(int value)
{
    char buf[ 128 ];
    if (pauseAtExit) {
        printf("hit return to exit...");
        if (fgets(buf, sizeof(buf) - 1, stdin) == 0) {
            omMediaShutdown();
            return 2;
        }
    }
    omMediaShutdown();
    return value;
}

static void usage(const char* format, ...)
{
    va_list argList;
    va_start(argList, format);
    vfprintf(stderr, format, argList);
    printf("\nUsage: ommdata <options> [-extract | -insert] -movie <clipname> -trackNumber <#>" 
           " -startFrame <frame #> -numFrames <# of frames> -dataType <dataType> -vancFile <filename>\n"
        " Where:\n"
        "  -extract         Extract ancillary data from movie.\n"
        "  -insert          Insert ancillary data into a movie.\n"
        "  -movie           Filename of the target movie.\n"
        "  -trackNumber     The track number (zero based) containing the data.\n"
        "  -startFrame      The first frame (zero based) to access.\n"
        "  -numFrames       The number of frames to access.\n"
        "  -vancFile        For insert:  file containing omneon neutral vanc binary data.\n"
        "                   For extract: file containing extracted omneon neutral vanc binary data.\n" 
        "  -dataType        See available data types below.\n"
        "\n"
        " Available Data Types:\n"
        "  436Vbi       VBI stored in 436M track\n"
        "  436Vanc      VANC stored in a 436M track\n"
        "  EmbVideoVanc VANC stored in a video track\n"
        "\n"
        " Available Options:\n"
        "  -help       this message\n"
        "  -pause      wait for a CR from user before exiting\n"
        " \n");
    exit(pauseExec(1));
}

static char* getArg(int& argc, char**& argv)
{
    if (argc <= 1) {
        usage("\nMissing argument..\n\n");
        exit(1);
    }
    argc--, argv++;
    return *argv;
}

// Parses the user provided omneon neutral input file
// Only supports Omneon Neutral Format Type-2
bool parseOmneonNeutralFormat(FILE* fp, uint nFrames, unsigned char* outputBuffer, uint outputBufSize) 
{
    if (fp == 0 || outputBuffer == 0)
        return false;
    
    // Omneon Header
    unsigned char header[omVancType2size];
    uint currentOffset = ftell(fp);
    uint dataEnd = 0;   // data end for the nth frame in the src file

    // Reads the Omneon Frame Header for each frame seeking to the end of each
    // frame to pass into the output buffer
    for (uint frame = 0; frame < nFrames; frame++) {

        // Read the first byte of the header
        if (fread(header, 1, 1, fp) != 1)
            return false;

        // Make sure we're working with Type-2 Frame headers
        if ((header[0] >> 4) != omVancType2) {
            printf("VANC file not encoded with Type-2 frame headers\n");
            return false;
        }

        // Read the complete header
        if (fread((header + 1), 1, (omVancType2size - 1), fp) != (omVancType2size - 1))
            return false;
       
        // Read the length of this frame, which is 2-bytes in length
        // and stored at bytes 2 and 3
        uint frameLength = static_cast<unsigned int> (header[2] << 8) |
                           static_cast<unsigned int> (header[3] << 0);

        dataEnd += frameLength; // update the end of the frame range
        
        // seek to the beginning of the next frame
        if (fseek(fp, frameLength - omVancType2size, SEEK_CUR) != 0) {
            printf("Error while reading vanc file\n");
            return false;
        }
    }

    // make sure we don't overrun the buffer
    if (dataEnd > outputBufSize) {
        printf("internal write buffer out of space requested %u, available %u\n",
            dataEnd, outputBufSize);
        return false;
    }

    // rewind to the start of the frame range
    if (fseek(fp, currentOffset, SEEK_SET) != 0) {
        printf("error while reading src file\n");
        return false;
    }

    // read all of the data of into the internal buffer
    if (fread(outputBuffer, 1, dataEnd, fp) != dataEnd) {
        printf("error while reading src file\n");
        return false;
    }
    
    return true;
}

// Extracts ancillary data from a movie using getFrameData()
bool extractANC(char* clipName, uint trackNum, uint startFrame, uint numFrames, OmMediaClipDataType data, char* file)
{
    // Open the target movie read-only
    OmMediaQuery omq;
    if (! omq.setFile(clipName, false)) {
        printf("Couldn't open movie %s\n", clipName);
        return false;
    }

    // Open the output file
    FILE* fp;
    fp = fopen(file, "wb");
    if (fp == 0) {
        printf("Cannot open destination file \"%s\"\n", file);
        return false;
    }
    
    // Create a buffer for reading the omneon neutral data
    uint pDataSize = bufferSize;
    unsigned char *pData = new unsigned char[bufferSize];
    if (pData == 0)
        return false;

    uint frame = startFrame;      // starting frame to process
    uint framesLeft = numFrames;  // number of frames left to process for the caller's request
    uint nFrames = FramesPerLoop; // number of frames to process

    // This loop will divide up the users frame range request before calling getFrameData().
    // This allows us to handle very large VANC payloads, by flushing our buffer to our output file.
    while (framesLeft > 0) {
    
        if (framesLeft < nFrames)
            nFrames = framesLeft;
    
        // Call getFrameData() on the smaller clip range
        if (! omq.getFrameData(trackNum, frame, nFrames, data, pData, &pDataSize)) {
            // we've encountered an error while reading data, to keep this simple we just return an error.
            printf("Error extracting data from frame range %d - %d\n", frame, frame + nFrames);
            fclose(fp);
            delete pData;
            return false;
        }
            
        // flush our internal buffer to the output file
        fwrite(pData, 1, pDataSize, fp);
        pDataSize = bufferSize; // reset pDataSize

        // Setup next loop
        frame += nFrames;
        framesLeft -= nFrames;

    }

    fclose(fp);
    delete pData;
    return true;
}

// Inserts ancillary data into a movie using setFrameData()
bool insertANC(char* clipName, uint trackNum, uint startFrame, uint numFrames, OmMediaClipDataType data, char* file)
{   
    // Open the target movie with write-access
    OmMediaQuery omq;
    if (! omq.setFile(clipName, true)) {
        printf("Couldn't open movie %s\n", clipName);
        return false;
    }

    // Open the input file containing omneon neutral data
    FILE *fp;
    fp = fopen(file, "rb");
    if (fp == 0) {
        printf("Cannot open input file \"%s\"\n", file);
        return false;
    }

    // internal buffer for sending omneon neutral data through setFrameData()
    uint pDataSize = bufferSize;
    unsigned char *pData = new unsigned char[bufferSize];
    if (pData == 0)
        return false;
    
    uint frame = startFrame;      // starting frame to process
    uint framesLeft = numFrames;  // number of frames left to process for the caller's request
    uint nFrames = FramesPerLoop; // number of frames to process
    
    // This loop will divide up the users frame range request before calling setFrameData().
    // This allows us to handle very large VANC payloads or greater than 512 frame counts
    while (framesLeft > 0) {
        
        if (framesLeft < nFrames) {
            nFrames = framesLeft;
        }

        // read the omneon neutral data from the input file
        if (! parseOmneonNeutralFormat(fp, nFrames, pData, pDataSize)) {  
            fclose(fp);
            delete pData;
            return false;
        }

        // call setFrameData() on the small frame range
        if (! omq.setFrameData(trackNum, frame, nFrames, data, pData, &pDataSize)) {
            // we've encountered an error while inserting data, to keep this simple we just return an error.
            printf("Error inserting data into frame range %d - %d\n", frame, frame + nFrames);
            fclose(fp);
            delete pData;
            return false;
        }

        // Setup next loop
        frame += nFrames;
        framesLeft -= nFrames;
        pDataSize = bufferSize;
    }

    fclose(fp);
    delete pData;
    return true;
}

int main(int argc, char**argv)
{
    bool writeData   = false;
    bool extractData = false;
    char* movie     = 0;
    char* vancFile  = 0;
    char* dataString = 0;
    int trackNum    = -1;
    int startFrame  = -1;
    int numFrames   = -1;
    OmMediaClipDataType dataType = omClipDataUnknown;

    if (argc <= 1) {
        usage("Missing arguments..\n");
    }

    for (argc--, argv++; argc; argc--, argv++) {
        if (strcmp(*argv, "-help") == 0) {
            usage("");

        } else if (strcmp(*argv, "-pause") == 0) {
            pauseAtExit = true;

        } else if (strcmp(*argv, "-insert") == 0) {
            if (extractData)
                usage("Too many operation arguments");
            writeData = true;

        } else if (strcmp(*argv, "-extract") == 0) {
            if (writeData)
                usage("Too many operation arguments");
            extractData = true;

        } else if (strcmp(*argv, "-movie") == 0) {
            movie = getArg(argc, argv);
        
        } else if (strcmp(*argv, "-trackNumber") == 0) {
            trackNum = atoi(getArg(argc, argv));
        
        } else if (strcmp(*argv, "-startFrame") == 0) {
            startFrame = atoi(getArg(argc, argv));
        
        } else if (strcmp(*argv, "-numFrames") == 0) {
            numFrames = atoi(getArg(argc, argv));

        } else if (strcmp(*argv, "-vancFile") == 0) {
            vancFile = getArg(argc, argv);

        } else if (strcmp(*argv, "-dataType") == 0) {
            dataString = getArg(argc, argv);
            if (strcmp(dataString, "436Vbi") == 0) {
                dataType = omClipData436Vbi;

            } else if (strcmp(dataString, "436Vanc") == 0) {
                dataType = omClipData436Vanc;

            } else if (strcmp(dataString, "EmbVideoVanc") == 0) {
                dataType = omClipDataVideoEmbVanc;
            }
        }
    }

    // Validate the command line arguments
    if (!extractData && !writeData)
        usage("Must use -extract or -insert");

    if (movie == 0)
        usage("Must specify a -movie");

    if (vancFile == 0)
        usage("Must specify a -vancFile");

    if (trackNum < 0)
        usage("Must specify 0 or greater -trackNumber");

    if (startFrame < 0)
        usage("Must specify 0 or greater -startFrame");

    if (numFrames < 1)
        usage("Must specify 1 or greater -numFrames");

    if (dataType == omClipDataUnknown)
        usage("Must specify a -dataType");

    if (dataType != omClipData436Vanc && dataType != omClipData436Vbi && dataType != omClipDataVideoEmbVanc)
        usage("Invalid data type %s", dataString);

    // This example application performs either a read or a write operation.  For more complex ancillary processing
    // the recommended approach would be a getFrameData(), process the existing data, finishing with a setFrameData().
    bool success; 
    if (writeData)
        success = insertANC(movie, trackNum, startFrame, numFrames, dataType, vancFile);
    else
        success = extractANC(movie, trackNum, startFrame, numFrames, dataType, vancFile);
    
    return success ? pauseExec(0): pauseExec(1);
}

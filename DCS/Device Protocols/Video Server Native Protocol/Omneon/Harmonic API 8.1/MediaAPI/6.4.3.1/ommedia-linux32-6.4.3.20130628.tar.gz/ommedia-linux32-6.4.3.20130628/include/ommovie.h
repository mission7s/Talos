/**********************************************************************
Filename:    ommmovie.h

Description: Defines the Omneon Media API

Copyright (c) 1998-2010 Omneon Video Networks (TM)

OMNEON VIDEO NETWORKS CONFIDENTIAL
************************************************************************/

/**
 * @mainpage
 *
 * @section s1 Copyright and Trademarks
 * Copyright &copy; 2000-2010 Harmonic Inc. All rights reserved. Omneon and the 
 * Omneon logo are trademarks of Harmonic Inc. All other trademarks are the property of 
 * their respective holders. May be covered by one or more of U.S. Patents No. 6,571,351; 
 * 6,696,996; 6,545,721; 6,574,225; 6,895,003; 6,522,649; 6,643,702; foreign counterparts 
 * and pending patent applications.
 *
 * @section s2 Notice
 * Information contained in this guide is subject to change without notice or obligation. 
 * While every effort has been made to ensure that the information is accurate as of the 
 * publication date, Harmonic Inc. assumes no liability for errors or omissions. In addition, 
 * Harmonic Inc. assumes no responsibility for damages resulting from the use of this guide. 
 *
 * @section s3 Company Address
 *
 * <b>Harmonic Inc.</b><br />
 * 4300 North First St.<br />
 * San Jose, CA 95134, U.S.A.<br />
 * <br />
 * Phone (inside the U.S): +1 (800) 788-1330<br />
 * (Outside the U.S.): +1 (408) 542-2500<br />
 * Fax: +1 (408) 542-2511<br />
 * Technical Support: +1 (408) 585-5200<br />
 * Fax (Sales and Technical Support): +1 (408) 490-7390<br />
 * Web Site: http://www.omneon.com<br />
 * E-mail (Sales): sales@omneon.com<br />
 * E-mail (Support): support@omneon.com<br />
 */

/** 
 * @file ommovie.h
 * Definition of the OmMovie class.
 */

#ifndef _OMMOVIE_H_
#define _OMMOVIE_H_

#  ifdef _MSC_VER
#    ifdef OMMEDIA_EXPORTS
       // defined for developers of this DLL
#      define OMMOVIE_CPP_API __declspec(dllexport)
#      define OMMOVIE_C_API extern "C" __declspec(dllexport)
#    else
       // defined for DLL users
#      define OMMOVIE_CPP_API __declspec(dllimport)
#      define OMMOVIE_C_API extern "C" __declspec(dllimport)
#    endif
#  else
#    define OMMOVIE_CPP_API
#    define OMMOVIE_C_API extern "C"
#  endif

#ifndef OMMOVIE_CPP_API
#define OMMOVIE_CPP_API
#endif

#ifndef OMMOVIE_C_API
#define OMMOVIE_C_API
#endif

#include <ommedia.h>
#include <omtcdata.h>

/**
 * Error constants.
 * These are returned by most methods of the OmMovie class.
 */
typedef enum {
    omErrOk = 0,          /**< Success. */
    omErrUnknown,         /**< Unknown error. */
    omErrNotImplemented,  /**< Functionality not implemented at this time. */
    omErrInvalidArgument, /**< An argument provided was invalid. */
    omErrBadState,        /**< The object is in a state that does not allow the operation requested. */
    omErrBufferTooSmall,  /**< The memory buffer provided was too small. */
    omErrInProgress,      /**< The operation hasn't finished yet. */
    omErrAborted,         /**< The operation has been aborted. */
    /* Error codes 8-11 reserved; used in 7.0+ */
    omErrInternal = 12,   /**< Internal logic error. */
    /* Error codes 13-15 reserved; used in 7.0+ */
    omErrInvalidMovieHandle = 16, /**< Movie handle provided to the C API is invalid. */
    omErrRpcDisabled,     /**< Remote procedure calls are disabled. */
    omErrRpcFatalError,   /**< Remote procedure calls had an unrecoverable error. No further RPC calls will be made for that object. */
    omErrRpcTimeout,      /**< Remote procedure call timed out. */
    omErrRpcOutOfMemory,  /**< Remote server is out of memory. */
    omErrRpcInternal,     /**< Internal logic error in the RPC code. */
    /* new error codes go here at the bottom */
} OmMovieErr;

/** 
 * Access mode constants.
 * These are used in the OmMovie::open() method to specify the type of file access desired.
 */
enum OmAccessMode {
    omAccCreate,      /**< Create a brand new movie clip, but do not overwrite existing clips. */
    omAccTruncate,    /**< Create a brand new movie clip, overwriting a previous clip of the same name if it exists. */
    omAccReadOnly,    /**< Open the movie clip with read only access. Use to obtain information about an existing movie clip. */
    omAccReadWrite    /**< Open the movie clip with read and write access. Use to obtain information and make modifications to an existing movie clip. */
};
    
/** 
 * Wrapping mode constants. 
 * These are used in the OmMovie::open() and OmMovie::saveCopy() methods to indicate the type of wrapper to generate.
 */
enum OmWrapMode {
    omWrapPreserve,             /**< Preserve the current wrapping mode. */
    omWrapEmbedded,             /**< Create a self-contained movie clip. */
    omWrapDiscrete,             /**< Create a referenced movie clip with flattened media files. */
    omWrapReferenced,           /**< Create a referenced movie clip that points to the original media files. */
    omWrapEmbeddedLowBitrate    /**< Create a self-contained movie clip with optimal buffering for low bitrate (i.e. proxy) media. */
};

/**
 * Dirty mode constants.
 * These are returned by the OmMovie::isDirty() method to indicate what kind of changes are pending.
 */
enum OmDirtyMode {
    omDirtyNone,       /**< The movie is clean. */
    omDirtyNeedsFlush, /**< The movie wrapper does not need to be regenerated, OmMovie::flush() is enough to write all the pending changes to disk. */
    omDirtyNeedsSave,  /**< The movie wrapper needs to be regenerated, OmMovie::Save() or OmMovie::SaveCopy should be used to update the movie on disk. */
    omDirtyUnknown     /**< The dirty state is unknown. This may happen if an rpc call fails for a remote object. */
};

/** 
 * Movie information. 
 * This structure provides information about a movie.
 */
struct OmMovieInfo {
    enum OmMediaFileType type;           /**< type of movie file. */
    enum OmMediaContainment containment; /**< containment mode (i.e. referenced, self-contained). */
    uint firstFrame;                     /**< First frame (may be non-zero). */
    uint lastFrame;                      /**< Last frame (exclusive, last stored frame is one before this). */
    uint lastReadableFrame;              /**< If the movie is growing, this is the last frame that is safe to read. Frames between lastReadableFrame and lastFrame should not be read until the clip stops growing. */
    uint defaultIn;                      /**< Default in (inclusive, first frame to play). */
    uint defaultOut;                     /**< Default out (exclusive, first frame *not* played). */
    uint numTracks;                      /**< Number of video and audio tracks. */
    uint numMedia;                       /**< Number of media files referenced by movie. */
    uint numPrecharge;                   /**< Number of precharge frames before the first frame. */
    enum OmFrameRate frameRate;          /**< Clip frame rate. */
    char clipProperties[128];            /**< Comma-delimited list of properties. */
    uint_64 createTime;                  /**< Creation time stored in movie wrapper (seconds since Unix epoch, zero if unknown). */
    uint_64 modifyTime;                  /**< Modification time stored in movie wrapper (seconds since Unix epoch, zero if unknown). */
};

/** 
 * Track information. 
 * This structure provides information about a movie track.
 */
struct OmTrackInfo {
    enum OmMediaType essenceType;                   /**< Essence type. */
    uint bitrate;                                   /**< Bitrate for this track, or 0 for embedded audio. */
    uint bitsPerUnit;                               /**< For audio this is the bits per sample (16 or 24); for 601 video it is the bits per pixel (8 or 10); otherwise it is 0. */
    uint sampleRate;                                /**< Media sample rate * 100; e.g. NTSC video is 2997; 48khz audio is 4800000. */
    uint channels;                                  /**< 1 for video; N for audio. */

    // video specific items
    enum OmFrameStruct frameStructure;              /**< frame structure (interlaced or progressive). */
    enum OmSequenceCodingType sequenceCodingType;   /**< sequence coding (intracoded or non-intracoded). */
    enum OmVideoSampleRatio vsr;                    /**< Pixel sample ratio. Set to 'omVideoSampleNone' for non-video tracks. */
    enum OmVideoAspectRatio aspect;                 /**< Video aspect ratio. Set to 'omVideoAspectNone' for non-video tracks. */
    uint gopLength;                                 /**< Length of the gop structure; typically 15 for MPEG long-GOP video, 1 for everything else. */
    uint subGopLength;                              /**< Length of the sub-gop; usually 3 for IBBPBBP... MPEG long-GOP video; 1 for everything else. */
    unsigned short width;                           /**< Picture width, in pixels. Set to 0 for non-video tracks. */
    unsigned short height;                          /**< Picture height, in pixels. Set to 0 for non-video tracks. */

    // audio specific items
    enum OmAudioFormat audioFormat;                 /**< Audio compression format. Ignored for non-audio tracks. */
    unsigned char bigEndian;                        /**< 1 if samples are store in big-endian byte order; 0 if stored in little-endian byte order. Ignored for non-audio tracks. */
    unsigned char sampleStride;                     /**< Size of one audio sample, in bytes. Set to 0 for non-audio tracks. */

    // vbi specific items
    uint lineMask;                                  /**< VBI line mask. Set to 0 for non-VBI tracks. */

#ifdef __cplusplus
    /**
     * Check if the track is a video track.
     * @return <i>true</i> if the track is a video track, <i>false</i> if not.
     */
    bool isVideoType() const
    {
        return essenceType == omMediaMpegVideo
            || essenceType == omMediaDvVideo
            || essenceType == omMediaAvc 
            || essenceType == omMediaRec601Video
            || essenceType == omMediaHdcam 
            || essenceType == omMediaDnxhd 
            || essenceType == omMediaMpeg4Video;
    }

    /**
     * Check if the track is a audio track.
     * @return <i>true</i> if the track is a audio track, <i>false</i> if not.
     */
    bool isAudioType() const
    {
        return essenceType == omMediaPcmAudio
            || essenceType == omMediaDvAudio
            || essenceType == omMediaMpegAc3
            || essenceType == omMediaMpegStdAudio
            || essenceType == omMediaAlawAudio;
    }

    /**
     * Check if the track is a data track.
     * @return <i>true</i> if the track is a data track, <i>false</i> if not.
     */
    bool isDataType() const
    {
        return essenceType == omMediaVbi
            || essenceType == omMediaTc
            || essenceType == omMedia436mVbi
            || essenceType == omMedia436mAnc;
    }
#endif
};

/** 
 * Frame coding type constants. 
 */
enum OmSampleCodingType {
    codingUnknown = 0,              /**< Unknown sample conding type. */
    codingIntracoded,               /**< Intra-coded frame (a I-picture), GOP is closed. */
    codingPartialIntracoded,        /**< Intra-coded frame (a I-picture), GOP is open. */
    codingPredictive,               /**< Predictive-coded frame (a P-picture). */
    codingBidir                     /**< Bidirectionally predictive-coded frame (a B-picture). */
};

/** 
 * Frame information. 
 * This structure provides information about a movie frame.
 */
struct OmFrameInfo {
    enum OmSampleCodingType codingType;  /**< Sample coding type. */
    uint nSamples;                  /**< Number of samples in this frame. */
    uint size;                      /**< Size, in bytes, of the frame. */
    struct OmTcData timecode;       /**< If available, timecode associated with this frame. */
    OmMediaId mediaId;              /**< Id of the file where this frame is stored. */
    uint nChunks;                   /**< Number of chunks for this frame. For video this is always 1, for audio it can be 1 or 2. When writing a frame it should always be 1. */
    uint_64 offset0;                /**< File offset of the first chunk. When writing a frame in a referenced movie this should be the offset of the frame, otherwise it should be set to 0. */
    uint size0;                     /**< Size of the first chunk. Set to 0 when writing a frame. */
    uint_64 offset1;                /**< File offset of the second chunk. Set to 0 when writing a frame. */
    uint size1;                     /**< Size of the second chunk. Set to 0 when writing a frame. */
    int anchorFrame;                /**< The anchor frame number for this frame. Intracoded material is self-anchored (i.e. anchor = frame). For non-intracoded material the anchor frame points to the previous I or P frame. Set to 0 when writing a frame. */
};

/**
 * An opaque handle that is used to track progress on an asynchronous save operation.
 * @remarks Save handles are unique across all OmMovie instances.
 * @see OmMovie::saveCopy
 * @see OmMovie::save
 * @see OmMovie::getSaveProgress
 */
typedef unsigned int OmSaveHandle;

/**
 * An opaque handle to an OmMovie object, used by the C interface.
 */
typedef void* OmMovieHandle;

#ifdef __cplusplus

// C++ interfaces

/** 
 * Class that represents a movie clip.
 */
class OMMOVIE_CPP_API OmMovie {
public:
    /** 
     * Return the Media API software version.
     * This method returns the software version
     * of the currently loaded Media API. A client application
     * can, for example, present this information in its
     * "about" box. Omneon API version numbers are composed of 
     * four parts: major version, minor version, service release
     * number and hotfix number.
     * @return An object that represents an Omneon API version number.
     *  Methods on this object provide access to the four components of 
     *  the version number, as well as comparison functions.
     * @see OmSwVersion
     * @see getRemoteSwVersion
     */
    static OmSwVersion getThisSwVersion();

    /**
     * Return the Media API software version running on a remote host.
     * This method returns the software version of Media API currently
     * loaded on the remote host identified by hostname.
     * @return An object that represents an Omneon API version number.
     *  Methods on this object provide access to the four components of
     *  the version number, as well as comparison functions.
     * @see OmSwVersion
     * @see getThisSwVersion
     */
    static OmSwVersion getRemoteSwVersion(const char* hostname);

    /**
     * Check if host is running a remote MAPI service.
     * @return Error code
     *  - <i>omErrOk</i> if the service is available.
     *  - <i>omRpcTimeout</i> if the service is not available.
     *  - <i>omRpcDisabled</i> if remote services are not enabled in this version of the MAPI.
     */
    static OmMovieErr pingRemoteHost(const char* hostname);

    /** 
     * Enable logging to a file.
     * This method enables or disables logging of Media API activity to a file.
     * @param logfile A string with the filename of the log file to use.
     * @remarks If a filename is specified, logging will be appended at the
     *  end of the file. If filename is NULL or "", logging will be
     *  turned off. Note that once logging is enabled, <i>all</i> calls
     *  to the Media API will be logged, not just those of the OmMovie class.
     */
    static void setDebug(const char* logfile);

    static void setDebug(const char*, const char*);
    static void setDebug(const char*, unsigned int);

    /**
     * Set debug variables on a remote MAPI service.
     * @param hostname Host running remote MAPI service.
     * @remarks This will change debug settings for all users of the service. Use with caution.
     */
    static OmMovieErr setRemoteDebug(const char* hostname, const char*, const char*);
    static OmMovieErr setRemoteDebug(const char* hostname, const char*, unsigned int);

    /** 
     * Create a new OmMovie object.
     * @remarks This constructor creates an empty OmMovie object. To associate this object with
     *   an existing movie file, the open() method needs to be called.
     * @see open
     */
    OmMovie();

    /** 
     * Create a new OmMovie object.
     * @param hostname A string with the name of the host to run on.
     * @remarks This constructor creates an empty OmMovie object. To associate this object with
     *   an existing movie file, the open() method needs to be called.
     * @see open
     */
    OmMovie(const char* hostname);

    /** 
     * Destroy an OmMovie object
     * @remarks When an object that is open is destroyed, close() will automatically be called.
     */
    virtual ~OmMovie();

    /**
     * Initialize the remote media server.
     * @remarks This causes any ongoing operations on that server to abort
     *  immediately. This may be useful in cases where the client application
     *  crashed or exited unexpectedly, leaving one or more orphaned operations
     *  running on the remote server. The application can call this function 
     *  after it is restarted, to esure that the host goes back to a clean state.
     *  A limitation of this function is that when there are several clients 
     *  sending operations to the same host, all operations will be aborted, even
     *  those from a different client.
     * @return Error code
     *   - <i>omErrOk</i> remote host was initialized successfully.
     *   - <i>???</i> 
     */
    OmMovieErr initializeRemoteHost() const;

    /** 
     * Open a movie clip.
     * This method opens a movie clip. This operation associates a
     * newly constructed OmMovie object with a movie clip. Most other methods
     * in the OmMovie class expect an object that is open.
     * @param filename A string with the filename of the movie clip to open.
     * @param accessMode The access mode for this clip. If an access mode is not given, <i>accReadOnly</i> is assumed by default.
     * @param wrapMode The wrapping mode for this clip. Note that when opening an existing clip <i>wrapPreserve</i> is the only allowed value.
     * @param style When creating a new clip, this is a string that can be used to indicate a specific type of clip to create. Examples:
     *   - <i>"d10"</i> to create an eVTR/D10 MXF OP1a movie clip.
     *   - <i>"as02"</i> to create an AS02 MXF movie clip.
     *   - <i>"rdd9"</i> to create an RDD9 MXF OP1a movie clip.
     *   - <i>"lowLatency"</i> to create a low latency MXF OP1a movie clip.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the object is already open.
     *   - <i>omErrInvalidArgument</i>: one of the arguments provided is not compatible with the open operation requested.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks An open OmMovie object can be closed by calling the close() method. Closing the object releases all 
     *   resources associated with the movie clip and resets the object back to an empty state. At this point, the object
     *   can be reused by calling open() again.
     * @see OmAccessMode
     * @see OmWrapMode
     * @see close
     */
    OmMovieErr open(const char* filename, OmAccessMode accessMode = omAccReadOnly, OmWrapMode wrapMode = omWrapPreserve, const char* style = "");

    /**
     * Check if a movie object is in an open state.
     * @return <i>true</i> if the object has been successfully initialized and is open, <i>false</i> if the object is in a closed state.
     * @remarks A movie object is in an open state when it is associated with a movie file on disk, typically after a successful call to open().
     *   A movie object that is closed is in an empty state, without an association to a movie file.
     * @see open
     * @see close
     */
    bool isOpen() const;

    /**
     * Check if a movie object has been modified since loaded or last written to disk.
     * @return <i>true</i> if the object has changes that have not been written to disk, <i>false</i> otherwise.
     * @remarks The flush() method is used to write unsaved metadata changes to an existing movie on disk. The save() and saveCopy() methods 
     *   regenerate the movie wrapper.
     * @see save
     * @see saveCopy
     * @see flush
     */
    bool isDirty() const;

    /**
     * Return the dirty mode of the movie.
     * @return A value that indicates what kind of changes have been made to the movie, and if a flush() or a save() is necessary to write those changes to disk.
     * @remarks The dirty mode gives more information than the boolean dirty flag. The flush() method is used to write unsaved metadata changes to an existing movie on disk. The save() and saveCopy() methods 
     *   regenerate the movie wrapper.
     * @see OmDirtyMode
     * @see save
     * @see saveCopy
     * @see flush
     */
    OmDirtyMode getDirtyMode() const;

    /**
     * Check if the movie was open with write access.
     * @return <i>true</i> if the movie can be modified, <i>false</i> if the movie was open in read-only mode.
     */
    bool isWritable() const;

    /**
     * Check if the movie is growing.
     * @return <i>true</i> if the movie is growing, <i>false</i> if not.
     * @remarks 
     *   - The movie length reported by the getDuration() should not be considered final if the movie is growing. As soon as the 
     *     movie stops growing, a new call to getDuration() will return the final length.
     *   - If the movie is growing, the <i>lastReadableFrame</i> member of the OmMovieInfo structure contains the last frame that
     *     is safe to read. Reading frames past the reported last readable frame may result in an error, as the frames at the
     *     end of a growing movie may not have been completely flushed to disk by the process that is doing the writing.
     *   - It may take a few seconds after the movie stops growing for this function to return <i>false</i>.
     * @see getDuration
     */
    bool isGrowing() const;

    /**
     * Set the default video frame rate to use for movies that don't specify one.
     * @param videoRate The video frame rate to use on this movie, if the movie itself does not provide one.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot accept a default video rate at this time, for example because it is closed.
     * @remarks A default video frame rate is useful, for example, for .wav or .aiff audio files. It is also
     *   used by raw DNxHD files. All functions that accept or return frame numbers will assume this frame rate if
     *   the movie does not explicitly provide one.
     */
    OmMovieErr setDefaultVideoRate(OmFrameRate videoRate);

    /**
     * Return the error code for the last operation done on this object.
     * @return The error code of the last operation.
     */
    OmMovieErr getLastErrorCode() const;

    /**
     * Return a text message for the last error code.
     * @return A string with information about the last operation done on this object.
     * @remarks For applications that write log files, Omneon recommends that the error string be written to the log whenever a 
     *   function returns an error.
     */
    const char* getLastErrorString() const;

    /**
     * Write any unsaved changes on this object to disk.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot be flushed in its current state.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks If there are no unsaved changes then this method does nothing.
     */
    OmMovieErr flush();

    /**
     * Write the movie associated with this object to disk.
     * @return A handle that can be used to obtain information about the asynchronous save operation.
     * @remarks
     *   - The filename and other movie parameters are those given in the open() call.
     *   - The save() operation is asynchronous. This method will return immediately and the
     *     operation will be carried out as a background task. 
     *   - The getSaveProgress() method can be used to find out when the operation has completed.
     *   - Multiple save operations can be started. The returned OmSaveHandle identifies each one.
     *   - For some types of changes the movie wrapper needs to be regenerated. In those cases, the save operation will
     *     write the new wrapper to a temporary file and, as soon as the new wrapper is complete, the original movie will be 
     *     deleted and the temporary wrapper renamed. If this asynchronous behavior causes problems, then saveCopy()
     *     should be used instead.
     * @see getSaveProgress
     * @see saveCopy
     * @see OmSaveHandle
     */
    OmSaveHandle save();

    /**
     * Write the movie associated with this object to a new file on disk.
     * @param filename The target file on disk.
     * @param replace <i>true</i> to overwrite an existing file, <i>false</i> to only write if the file did not exist before.
     * @param wrapMode The wrapping mode for the saved clip.
     * @param style A string that can be used to indicate a specific type of clip to create. Examples:
     *   - <i>"d10"</i> to create an eVTR/D10 MXF OP1a movie clip.
     *   - <i>"as02"</i> to create an AS02 MXF movie clip.
     *   - <i>"rdd9"</i> to create an RDD9 MXF OP1a movie clip.
     *   - <i>"lowLatency"</i> to create a low latency MXF OP1a movie clip.
     * @return A handle that can be used to obtain information about the asynchronous save operation.
     * @remarks 
     *   - The saveCopy() operation is asynchronous, this method will return immediately and the
     *     operation will be carried out as a background task. 
     *   - The getSaveProgress() method can be used to find out when the operation has completed.
     *   - Multiple save operations can be started. The returned OmSaveHandle identifies each one.
     * @see getSaveProgress
     * @see OmSaveHandle
     */
    OmSaveHandle saveCopy(const char* filename, bool replace, OmWrapMode wrapMode, const char* style = "");

    /**
     * Return progress information about an asynchronous save operation.
     * @param saveHandle The OmSaveHandle instance returned by save() or saveCopy().
     * @param totalFrames If not NULL, the total number of frames will be stored on this location.
     * @param processedFrames If not NULL, the number of processed frames will be stored in this location.
     * @return Error code
     *   - <i>omErrOk</i>: the save operation completed successfully. The totalFrames and processedFrames numbers are final.
     *   - <i>omErrInProgress</i>: the save operation is still in progress. The totalFrames and processedFrames numbers are not final.
     *   - <i>omErrAborted</i>: the background save was aborted by a call to abortSave().
     *   - <i>omErrInvalidArgument</i>: the handle is not valid for this object.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks 
     *   - If the source clip is growing, totalFrames will change as the clip grows.
     *   - To compute save completion percentage in the 0-100 range, use the following expression:<br /> 
     *     <i>totalFrames == 0 ? 0 : processedFrames * 100 / totalFrames</i>.
     *   - Save handles are unique across OmMovie objects, so any OmMovie instance (even one that is in a closed state)
     *     can return progress information for any save operation currently in progress.
     * @see saveCopy
     * @see OmSaveHandle
     * @see OmWrapMode
     * @see abortSave
     */
    #ifndef SWIG
    OmMovieErr getSaveProgress(OmSaveHandle saveHandle, unsigned int* totalFrames = 0, unsigned int* processedFrames = 0) const;
    #else
    OmMovieErr getSaveProgress(OmSaveHandle saveHandle, unsigned int* OUTPUT, unsigned int* OUTPUT) const;
    #endif

    /** 
     * Abort a save operation.
     * @param saveHandle The OmSaveHandle instance returned by save() or saveCopy().
     * @return Error code
     *   - <i>omErrOk</i>: the save operation was canceled.
     *   - <i>omErrInvalidArgument</i>: the handle is not valid for this object.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks This method simply passes the abort request to the background save task. The
     *   task has been effectively aborted when calls to getSaveProgress() return an
     *   omErrAborted error code.
     */
    OmMovieErr abortSave(OmSaveHandle saveHandle);

    /** 
     * Close an OmMovie object.
     * This method closes an open OmMovie object, releasing all the resources associated with the open movie clip and
     * bringing the object back to an empty state.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the object is already in a closed state.
     * @remarks Omneon recommends that you close OmMovie objects as soon as you are done with them as this releases all the
     *  resources associated with the open movie clip. Closing an open object is required if the object is going to be reused.
     *  Note that the ~OmMovie() destructor automatically closes objects that are still open.
     * @see open
     * @see ~OmMovie
     */
    OmMovieErr close();

    /**
     * Return the duration of the movie.
     * @return The duration of the movie in video frames, or 0 in case an error occurred.
     * @remarks Error information can be obtained by calling getLastErrorCode() and getLastErrorString().
     */
    int getDuration() const;

    /**
     * Return the duration of the movie.
     * @param trimAudio If set to <i>true</i>, the duration returned will be the one for the longest video track. 
     *  If set to <i>false</i> the duration returned will be the one for the longest track of any type. 
     * @return The duration of the movie in video frames, or 0 in case an error occurred.
     * @remarks 
     *   - Some movies have slightly longer audio tracks, and that may cause the movie duration to be a frame too long. 
     *     Passing trimAudio set to true prevents the audio tracks from being considered when calculating the movie duration.
     *   - Error information can be obtained by calling getLastErrorCode() and getLastErrorString().
     */
    int getDuration(bool trimAudio) const;

    /**
     * Return movie information.
     * @param info A reference to a OmMovieInfo structure, where the movie information will be stored.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot return movie information in its current state. For example, it may be closed.
     * @see OmMovieInfo
     */
    OmMovieErr getMovieInfo(OmMovieInfo& info) const;

    /**
     * Return the media id associated with the specified media file index.
     * @param mediaIndex A zero-based index for the media file.
     * @return OmMediaId for the requested media file, or OmMediaId(0) if the mediaIndex given is invalid.
     * @remarks The total number of media files in a movie is returned in the numMedia field of the OmMovieInfo structure.
     *  The return value of this function can be passed as an argument to getPath() to obtain a pathname.
     * @see OmMovieInfo
     * @see getMovieInfo
     * @see getPath
     */
    OmMediaId getMediaId(int mediaIndex) const;

    #ifndef SWIG
    /**
     * Return the pathname of the media file associated with the given media id.
     * @param id The OmMediaId of the media file. A media file index can be converted to a OmMediaId by the getMediaId() method.
     * @param buffer The buffer that will hold the pathname.
     * @param bufferSize On input, a pointer to the size of buffer. On output, the actual length of the pathname, including the string terminator.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot return path information in its current state. For example, it may be closed.
     *   - <i>omErrBufferTooSmall</i>: the buffer provided isn't big enough to hold the pathname. The bufferSize argument indicates how much space is needed.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    OmMovieErr getPath(OmMediaId id, char* buffer, int* bufferSize) const;
    #endif

    /**
     * Return the pathname of the media file associated with the given media id.
     * @param id The OmMediaId of the media file. A media file index can be converted to a OmMediaId by the getMediaId() method.
     * @return A string with the requested pathname, or 0 if there was an error.
     * @remarks 
     *   - The returned pointer points to memory owned by the OmMovie class. The pointer may become invalid after other calls are made.
     *     Therefore, Omneon recommends that you copy the data into an application-owned buffer.
     *   - Error information can be obtained by calling getLastErrorCode() and getLastErrorString().
     */
    const char* getPath(OmMediaId id) const;

    /**
     * Return track information.
     * @param trackNum The zero-based index for the track.
     * @param info A reference to a OmTrackInfo structure where the track information will be stored.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot return track information in its current state. For example, it may be closed.
     *   - <i>omErrInvalidArgument</i>: the track index is out of range.
     * @remarks The total number of tracks in a movie is returned in the numTracks field of the OmMovieInfo structure.
     * @see OmTrackInfo
     * @see OmMovieInfo
     */
    OmMovieErr getTrackInfo(int trackNum, OmTrackInfo& info) const;

    /**
     * Return frame information.
     * @param trackNum The zero-based index for the track.
     * @param frameNum The frame number.
     * @param info A reference to a OmFrameInfo structure, where the frame information will be stored.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot return frame information in its current state. For example, it may be closed.
     *   - <i>omErrInvalidArgument</i>: the track or frame index is out of range.
     * @remarks
     *   - The total number of tracks in a movie is returned in the numTracks field of the OmMovieInfo structure.
     *   - The valid frame range is given in the numPrecharge, firstFrame and lastFrame fields of the OmMovieInfo structure.
     *     The range goes from (firstFrame - numPrecharge) to (lastFrame - 1).
     * @see OmFrameInfo
     * @see OmMovieInfo
     */
    OmMovieErr getFrameInfo(int trackNum, int frameNum, OmFrameInfo& info) const;

    #ifndef SWIG
    /**
     * Read a frame of the movie.
     * @param trackNum The zero-based index for the track.
     * @param frameNum The frame number.
     * @param buffer The buffer where the frame is to be stored.
     * @param bufferSize A pointer to the size of buffer. On output the actual size of the frame will be stored in this variable.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot return a frame in its current state. For example, it may be closed.
     *   - <i>omErrInvalidArgument</i>: the track or frame index is out of range.
     *   - <i>omErrBufferTooSmall</i>: the buffer provided isn't big enough to hold the entire frame. The bufferSize argument indicates how much space is needed.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    OmMovieErr readFrame(int trackNum, int frameNum, char* buffer, int* bufferSize) const;
    #endif

    /**
     * Read a frame of the movie.
     * @param trackNum The zero-based index for the track.
     * @param frameNum The frame number.
     * @param bufferSize A pointer where the size of the frame will be stored.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot return a frame in its current state. For example, it may be closed.
     *   - <i>omErrInvalidArgument</i>: the track or frame index is out of range.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    #ifndef SWIG
    const char* readFrame(int trackNum, int frameNum, int* bufferSize) const;
    #else
    const char* readFrame(int trackNum, int frameNum, int* IGNORE) const;
    #endif

    /**
     * Rename the movie on disk.
     * @param newName The new pathname of the movie.
     * @param renameMedia If <i>true</i>, media files will also be renamed. If <i>false</i>, media files will keep their names.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot be renamed in its current state. For example, it may be closed, or read-only.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks 
     *   - The newName argument can indicate a new directory for the movie, in which case the movie will be moved to that
     *     directory, along with all its referenced media files.
     *   - If the renameMedia argument is <i>true</i> then the movie must be open with write access to perform the rename operation.
     */
    OmMovieErr rename(const char* newName, bool renameMedia);

    /**
     * Delete the movie on disk.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot be deleted in its current state. For example, it may be closed.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks Any media files referenced by the movie will also be deleted.
     */
    OmMovieErr remove();

    /**
     * Check if the movie was created by Omneon.
     * @return <i>true</i> if the movie was created by Omneon software, <i>false</i> otherwise.
     */
    bool isOmneonMovie() const;

    /**
     * Return the version of Omneon software that created the movie.
     * @return An OmSwVersion object with the Omneon version information.
     * @remarks If the movie was not created by Omneon software, the returned OmSwVersion will
     *  be marked as invalid (the OmSwVersion::isValid() method will return <i>false</i>).
     */
    OmSwVersion getOmneonCreateVersion() const;

    /**
     * Return the default in frame of the movie.
     * @param defaultIn A reference to an integer variable that will receive the default in frame number of the movie.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
     * @remarks To returned default in frame number will be between OmMovieInfo::firstFrame
     *  and the current default out frame number.
     * @see getMovieInfo
     * @see getFirstFrame
     */
    #ifndef SWIG
    OmMovieErr getDefaultIn(int& defaultIn) const;
    #else
    OmMovieErr getDefaultIn(int& OUTPUT) const;
    #endif

    /**
     * Set the default in frame of the movie.
     * @param defaultIn The frame number of the new default in frame of the movie.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks The range of valid values for the default in frame number is between OmMovieInfo::firstFrame
     *  and the current default out frame number.
     * @see getMovieInfo
     * @see getFirstFrame
     */
    OmMovieErr setDefaultIn(int defaultIn);

    /**
     * Return the default out frame of the movie.
     * @param defaultOut A reference to an integer variable that will receive the default out frame number of the movie.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
     * @remarks To returned default out frame number will be between the current default in frame number and 
     *  OmMovieInfo::lastFrame
     * @see getMovieInfo
     * @see getFirstFrame
     */
    #ifndef SWIG
    OmMovieErr getDefaultOut(int& defaultOut) const;
    #else
    OmMovieErr getDefaultOut(int& OUTPUT) const;
    #endif

    /**
     * Set the default out frame of the movie.
     * @param defaultOut The frame number of the new default out frame of the movie.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks The range of valid values for the default out frame number is between the current default in
     *  frame number and OmMovieInfo::lastFrame.
     * @see getMovieInfo
     * @see getFirstFrame
     */
    OmMovieErr setDefaultOut(int defaultOut);

    /**
     * Return the timecode for the first frame of the movie.
     * @param hour A reference to an integer variable that will receive the hour portion of the start timecode.
     * @param min A reference to an integer variable that will receive the minute portion of the start timecode.
     * @param sec A reference to an integer variable that will receive the second portion of the start timecode.
     * @param frame A reference to an integer variable that will receive the frame portion of the start timecode.
     * @param drop A reference to a boolean variable that will receive the drop-frame flag of the start timecode.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
     */
    #ifndef SWIG
    OmMovieErr getStartTimecode(int& hour, int& min, int& sec, int& frame, bool& drop) const;
    #else
    OmMovieErr getStartTimecode(int& OUTPUT, int& OUTPUT, int& OUTPUT, int& OUTPUT, bool& OUTPUT) const;
    #endif

    /**
     * Set the timecode for the first frame of the movie.
     * @param hour The hour portion of the new start timecode.
     * @param min The minute portion of the new start timecode.
     * @param sec The second portion of the new start timecode.
     * @param frame The frame portion of the new start timecode.
     * @param drop The drop-frame flag of the new start timecode, <i>true</i> for drop-frame, <i>false</i> for non-drop frame.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    OmMovieErr setStartTimecode(int hour, int min, int sec, int frame, bool drop);

    /**
     * Return the starting frame number for the movie.
     * @param firstFrame A reference to an integer variable that will receive the first frame number of the movie.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
     * @remarks All frame numbers returned and accepted by the OmMovie class are adjusted by the first frame of the movie.
     */
    #ifndef SWIG
    OmMovieErr getFirstFrame(int& firstFrame) const;
    #else
    OmMovieErr getFirstFrame(int& OUTPUT) const;
    #endif

    /**
     * Set the starting frame number for the movie.
     * @param firstFrame The new first frame number of the movie.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks All frame numbers returned and accepted by the OmMovie class are adjusted by the first frame of the movie.
     */
    OmMovieErr setFirstFrame(int firstFrame);

    #ifndef SWIG
    /**
     * Return the UMID for the movie.
     * @param buffer The buffer that will hold the UMID.
     * @param bufferSize The size of buffer.
     * @param bufferNeeded If provided, this variable will store the actual length of the UMID, including the string terminator.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: buffer is NULL.
     *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
     *   - <i>omErrBufferTooSmall</i>: the buffer provided isn't big enough to hold the umid. The bufferNeeded argument indicates how much space is needed.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    OmMovieErr getUmid(char* buffer, int bufferSize, int* bufferNeeded = 0) const;
    #endif

    /**
     * Return the UMID for the movie.
     * @return A string with the movie UMID, or 0 if there was an error.
     * @remarks 
     *   - The returned pointer points to memory owned by the OmMovie class. The pointer may become invalid after other calls are made.
     *     Therefore, Omneon recommends that you copy the data into an application-owned buffer.
     *   - Error information can be obtained by calling getLastErrorCode() and getLastErrorString().
     */
    const char* getUmid() const;

    /**
     * Generate a new UMID for the movie.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    OmMovieErr generateUmid();

    /**
     * Set the UMID of a proxy movie.
     * @param sourceMovie The proxy source movie
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be closed.
     *   - <i>omErrInvalidArgument</i>: the source movie could not be used.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks
     *   - A proxy's UMID is identical to the source movie's UMID with the exception of the instance number byte (bytes 14). See SMPTE 330M. 
     *   - No validation is done to ensure that the UMID on the source movie really does describe the contents of the proxy (such as number of tracks, and their types).
     */
    OmMovieErr setProxyUmid(OmMovie& sourceMovie) const;

    #ifndef SWIG
    /**
     * Return the UMID for a proxy's source movie.
     * @param buffer The buffer that will hold the UMID.
     * @param bufferSize The size of buffer.
     * @param bufferNeeded If provided, this variable will store the actual length of the UMID, including the string terminator.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: buffer is NULL.
     *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
     *   - <i>omErrBufferTooSmall</i>: the buffer provided isn't big enough to hold the umid. The bufferNeeded argument indicates how much space is needed.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    OmMovieErr getSourceUmid(char* buffer, int bufferSize, int* bufferNeeded = 0) const;
    #endif

    /**
     * Return the UMID for a proxy's source movie.
     * @return A string with the movie UMID, or 0 if there was an error.
     * @remarks 
     *   - The returned pointer points to memory owned by the OmMovie class. The pointer may become invalid after other calls are made.
     *     Therefore, Omneon recommends that you copy the data into an application-owned buffer.
     *   - Error information can be obtained by calling getLastErrorCode() and getLastErrorString().
     */
    const char* getSourceUmid() const;

    /**
     * Return the AFD (active format description) associated with the movie.
     * @param afd A reference to a variable that will receive the AFD of the movie.
     * @param trackNum The zero-based index of the track to query, or ~0 to use the first video track of the movie.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: the requested track is not a video track.
     *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks See SMPTE 2016-1 for the format of the AFD byte.
     */
    #ifndef SWIG
    OmMovieErr getVideoAfd(unsigned char& afd, int trackNum = ~0) const;
    #else
    OmMovieErr getVideoAfd(unsigned char& OUTPUT, int trackNum = ~0) const;
    #endif

    /**
     * Set the AFD (active format description) of the movie.
     * @param afd The new AFD value for the movie.
     * @param trackNum The zero-based index of the track to change, or ~0 to use the first video track of the movie.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: the requested track is not a video track.
     *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks See SMPTE 2016-1 for the format of the AFD byte.
     */
    OmMovieErr setVideoAfd(unsigned char afd, int trackNum = ~0);

    #ifndef SWIG
    /**
     * Extract data such as closed captions or timecodes embedded in the frames.
     * @param trackNum The zero-based index for the track.
     * @param startFrame The first frame number to extract.
     * @param numFrames The number of frames to extract.
     * @param dataType An OmMediaClipDataType value that indicates the type of data to extract.
     * @param buffer The buffer where the data is to be stored.
     * @param bufferSize A pointer to the size of the buffer. On output the actual size of the returned data will be stored in this variable.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: one of the arguments is invalid.
     *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @see OmMediaClipDataType
     */
    OmMovieErr getFrameData(int trackNum, int startFrame, int numFrames,
                      OmMediaClipDataType dataType, char *buffer, int *bufferSize) const;
    #endif

    /**
     * Extract data such as closed captions or timecodes embedded in the frames.
     * @param trackNum The zero-based index for the track.
     * @param startFrame The first frame number to read.
     * @param numFrames The number of frames to extract.
     * @param dataType An OmMediaClipDataType value that indicates the type of data to extract.
     * @param bufferSize A pointer to the size of the buffer. On output the actual size of the data will be stored in this variable.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: one of the arguments is invalid.
     *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @see OmMediaClipDataType
     */
    #ifndef SWIG
    const char* getFrameData(int trackNum, int startFrame, int numFrames,
                      OmMediaClipDataType dataType, int *bufferSize) const;
    #else
    const char* getFrameData(int trackNum, int startFrame, int numFrames,
                      OmMediaClipDataType dataType, int *IGNORE) const;
    #endif

    /**
     * Insert data such as closed captions or timecodes into frames.
     * @param trackNum The zero-based index for the track.
     * @param startFrame The first frame number to read.
     * @param numFrames The number of frames to extract.
     * @param dataType An OmMediaClipDataType value that indicates the type of data to insert.
     * @param buffer The buffer that will hold the data.
     * @param bufferSize A pointer to the size of buffer. On output the actual size of the data will be stored in this variable.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: one of the arguments is invalid.
     *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @see OmMediaClipDataType
     */
    OmMovieErr setFrameData(int trackNum, int startFrame, int numFrames,
                      OmMediaClipDataType dataType, char *buffer, int *bufferSize);

    /**
     * Return the number of properties associated with the movie.
     * @return The number of properties stored in the movie, or 0 in case of error.
     * @remarks Error information can be obtained by calling getLastErrorCode() and getLastErrorString().
     */
    int getMoviePropertyCount() const;

    /**
     * Return a property of the movie.
     * @param index The index of the property.
     * @param prop A reference to a OmMediaProperty object that will receive the property information.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omInvalidArgument</i>: the property index is out of range.
     *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    OmMovieErr getMovieProperty(int index, OmMediaProperty& prop) const;

    /**
     * Return a property of the movie.
     * @param name The name of the property.
     * @param prop A reference to a OmMediaProperty object that will receive the property information.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omInvalidArgument</i>: the property index is out of range, or the property name was not found.
     *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    OmMovieErr getMovieProperty(const char* name, OmMediaProperty& prop) const;

    /**
     * Add or replace a property in the movie.
     * @param prop A OmMediaProperty object with the new property.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omInvalidArgument</i>: the property is incompatible with an existing property of the same name.
     *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    OmMovieErr setMovieProperty(const OmMediaProperty& prop);

    /**
     * Delete a property of the movie.
     * @param prop The OmMediaProperty to delete.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    OmMovieErr deleteMovieProperty(const OmMediaProperty& prop);

    /**
     * Return the number of properties associated with a track of the movie.
     * @return The number of properties stored in the track, or 0 in case of error.
     * @remarks Error information can be obtained by calling getLastErrorCode() and getLastErrorString().
     */
    int getTrackPropertyCount(int trackNum) const;

    /**
     * Return a track property of the movie.
     * @param trackNum The zero-based index for the track.
     * @param index The index of the property.
     * @param prop A reference to a OmMediaProperty object that will receive the property information.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omInvalidArgument</i>: the track or property indexes are out of range.
     *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    OmMovieErr getTrackProperty(int trackNum, int index, OmMediaProperty& prop) const;

    /**
     * Return a track property of the movie.
     * @param trackNum The zero-based index for the track.
     * @param name The name of the property.
     * @param prop A reference to a OmMediaProperty object that will receive the property information.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omInvalidArgument</i>: the track or property indexes are out of range, or the property name was not found.
     *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    OmMovieErr getTrackProperty(int trackNum, const char* name, OmMediaProperty& prop) const;

    /**
     * Add or replace a track property of the movie.
     * @param trackNum The zero-based index for the track.
     * @param prop A OmMediaProperty object with the new property.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omInvalidArgument</i>: the track index is out of range, or the property is incompatible with an existing property of the same name.
     *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    OmMovieErr setTrackProperty(int trackNum, const OmMediaProperty& prop);

    /**
     * Delete a track property of the movie.
     * @param trackNum The zero-based index for the track.
     * @param prop The OmMediaProperty to delete.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omInvalidArgument</i>: the track index is out of range.
     *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    OmMovieErr deleteTrackProperty(int trackNum, const OmMediaProperty& prop);

    /**
     * Create a new track.
     * @param trackInfo A reference to a OmTrackInfo structure that describes the track.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: A field in the trackInfo structure is invalid.
     *   - <i>omErrBadState</i>: A track cannot be added to the movie in its current state.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks
     *   - Only movies open with omAccCreate or omAccTruncate access can create new tracks.
     *   - The createTrack() function cannot be mixed with addTrack(), addMovie() and addEffect().
     */
    OmMovieErr createTrack(OmTrackInfo& trackInfo);

    /**
     * Create a new track.
     * @param trackInfo A reference to a OmTrackInfo structure that describes the track.
     * @param filename A filename to use for this track when writing a referenced movie.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: A field in the trackInfo structure is invalid.
     *   - <i>omErrBadState</i>: A track cannot be added to the movie in its current state.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks
     *   - Only movies open with omAccCreate or omAccTruncate access can create new tracks.
     *   - The createTrack() function cannot be mixed with addTrack(), addMovie() and addEffect().
     *   - Only the base name portion of the filename argument is used. The path and the file
     *     extension cannot be changed.
     *   - The filename argument is ignored if the wrap mode is not omWrapDiscrete.
     */
    OmMovieErr createTrack(OmTrackInfo& trackInfo, const char* filename);

    #ifndef SWIG
    /**
     * Add a referenced media file to the movie.
     * @param filename The pathname of the media file added to the movie.
     * @param id A reference to an OmMediaId that will receive the id assigned to the media file.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: A referenced media file cannot be added to the movie in its current state.
     * @remarks This function can only be called for movies that were open with omAccCreate or omAccTruncate
     *   access, and with omWrapReferenced wrap mode.
     */
    OmMovieErr addReferencedMedia(const char* filename, OmMediaId& id);
    #endif

    /**
     * Add a referenced media file to the movie.
     * @param filename The pathname of the media file added to the movie.
     * @return The OmMediaId assigned to the media file.
     * @remarks 
     *   - This function can only be called for movies open with omAccCreate or omAccTruncate access, and 
     *     with omWrapReferenced wrap mode.
     *   - Error information can be obtained by calling getLastErrorCode() and getLastErrorString().
     */
    OmMediaId addReferencedMedia(const char* filename);

    /**
     * Prepare the movie to accept precharge frames. Precharge frames may be necessary to decode the first picture
     * on non-intracoded material.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: precharge frames cannot be added to the movie in its current state.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks 
     *   - This function is only required for non-intracoded movies that have precharge, and should be called before beginRecord().
     *   - After calling this function precharge frames can be written to the movie by calling writeFrame().
     * @see beginRecord
     * @see writeFrame
     */
    OmMovieErr beginPrecharge();

    /**
     * Prepare the movie to accept frames.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: frames cannot be added to the movie in its current state.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks 
     *   - If the movie has precharge frames, those must be added to the movie before calling this function.
     *   - After calling this function frames can be written to the movie by calling writeFrame().
     * @see beginPrecharge
     * @see writeFrame
     */
    OmMovieErr beginRecord();

    /**
     * Prepare the movie to accept rollout frames. Rollout frames may be necessary to play the last frame on non-intracoded
     * material.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrBadState</i>: rollout frames cannot be added to the movie in its current state.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     * @remarks 
     *   - This function is only necessary for non-intracoded movies. If used, it should be called after the last visible frame of the movie has been written.
     *   - For non intra-coded material the movie will have an implicit frame of rollout.
     *   - After calling this function rollout frames can be written to the movie by calling writeFrame().
     *   - During recording of non-intracoded material a rollout of one frame is implied. To finalize a clip that has no rollout frames, call beginRollout() after the last frame is written and then don't write any more frames.
     * @see beginPrecharge
     * @see writeFrame
     */
    OmMovieErr beginRollout();

    /**
     * Write a frame to the movie.
     * @param trackNum The zero-based index of the track where the frame is to be written.
     * @param info A reference to a OmFrameInfo structure that describes the frame.
     * @param data A buffer with the frame data.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: An argument is out of range or invalid.
     *   - <i>omErrBadState</i>: a frame cannot be written to the movie in its current state.
     *   - <i>omErrUnknown</i>: an internal error has occurred.
     */
    OmMovieErr writeFrame(int trackNum, const OmFrameInfo& info, char* data = 0);

    /**
     * Add a track from another movie to this movie.
     * @param sourceMovie A reference to the movie object that owns the track to add.
     * @param sourceTrackNum The zero-based index of the track in the source movie.
     * @param destTrackNum The zero-based index of the track where the new content will be added. To create a new track, enter -1 for this value. 
     * @param destFrameNum The start position within the track where the new content will be added. To align the new content with the beginning of the movie, enter -1 for this value.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: An argument is out of range or invalid.
     *   - <i>omErrBadState</i>: A track cannot be added to this movie in its current state.
     *   - <i>omErrUnknown</i>: An internal error has occurred.
     */
    OmMovieErr addTrack(const OmMovie& sourceMovie, int sourceTrackNum, int destTrackNum = -1, int destFrameNum = -1);

    /**
     * Add all tracks from another movie to this movie.
     * @param sourceMovie A reference to the movie object that owns the track to add.
     * @param destTrackNum The zero-based index of the destination track where the first track of the source movie will be added. The remaining source tracks will be added to the 
     *   movie in the tracks that follow immediately after this one. To add the tracks of the source movie as new tracks, enter -1 for this value. 
     * @param destFrameNum The start position within the track where the new content will be added. To align the new content with the beginning of the movie, enter -1 for this value.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: An argument is out of range or invalid, or the source and destination tracks do not match.
     *   - <i>omErrBadState</i>: A source movie cannot be added to this movie in its current state.
     *   - <i>omErrUnknown</i>: An internal error has occurred.
     * @remarks 
     *   - The source tracks will be inserted in the order in which they are defined in the source movie.
     *   - The movie on disk will not be immediately updated when addMovie is called. To update the movie call save() after all the modifications have been done.
     *     To leave the original movie unmodified and write a new movie with the changes use saveCopy().
     * @see save
     * @see saveCopy
     */
    OmMovieErr addMovie(const OmMovie& sourceMovie, int destTrackNum = -1, int destFrameNum = -1);

    /**
     * Add a filter to a track of the movie.
     * @param destTrackNum The zero-based index of the track where the filter will be added. 
     * @param destFrameNum The start position of the filter.
     * @param numFrames The duration of the filter.
     * @param name The name of the filter.
     * @param arguments A string with a comma-separated list of key/value pairs that configure the filter.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: An argument is out of range or invalid.
     *   - <i>omErrBadState</i>: A source movie cannot be added to this movie in its current state.
     *   - <i>omErrUnknown</i>: An internal error has occurred.
     * @remarks
     *   - Currently available filters are "xfade" and "vfade" for audio tracks.
     *   - None of the available filters require arguments at this time, but arguments will be used in the future.
     */
    OmMovieErr addFilter(int destTrackNum, int destFrameNum, int numFrames, const char* name, const char* arguments = "");

    /**
     * Add a filter to all the tracks of the movie that match the given essence type.
     * @param trackEssenceType The track type. 
     * @param destFrameNum The start position of the filter.
     * @param numFrames The duration of the filter.
     * @param name The name of the filter.
     * @param arguments A string with a comma separated list of key/value pairs that configure the filter.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: An argument is out of range or invalid.
     *   - <i>omErrBadState</i>: A source movie cannot be added to this movie in its current state.
     *   - <i>omErrUnknown</i>: An internal error has occurred.
     * @remarks
     *   - Currently available filters are "xfade" and "vfade" for audio tracks.
     *   - None of the available filters require arguments at this time, but arguments will be used in the future.
     */
    OmMovieErr addFilters(OmMediaType trackEssenceType, int destFrameNum, int numFrames, const char* name, const char* arguments = "");

    /**
     * Remove a track from this movie.
     * @param trackNum The zero-based index of the track to remove.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: An argument is out of range or invalid.
     *   - <i>omErrBadState</i>: A source movie cannot be added to this movie in its current state.
     *   - <i>omErrUnknown</i>: An internal error has occurred.
     * @remarks
     *  - The movie on disk will not be immediately updated when removeTrack is called. To update the movie, call save() after all the modifications have been done.
     *  - To leave the original movie unmodified and write a new movie with the changes, use saveCopy().
     * @see save
     * @see saveCopy
     */
    OmMovieErr removeTrack(int trackNum);

    /**
     * Discard frames from the beginning and/or the end of the movie.
     * @param startFrameNum The first frame of the range of frames to keep.
     * @param numFrames The number of frames to keep.
     * @return Error code
     *   - <i>omErrOk</i>: the operation was successful.
     *   - <i>omErrInvalidArgument</i>: An argument is out of range or invalid.
     *   - <i>omErrBadState</i>: A source movie cannot be added to this movie in its current state.
     *   - <i>omErrUnknown</i>: An internal error has occurred.
     * @remarks 
     *  - The movie on disk will not be immediately updated when subClip is called. To update the movie call save() after all the modifications have been done.
     *  - To leave the original movie unmodified and write a new movie with the changes use saveCopy().
     * @see save
     * @see saveCopy
     */
    OmMovieErr subClip(int startFrameNum, int numFrames = -1);

    /* Safely stop threads, and release resources before exit.
     * @remarks This signals threads to stop, and frees up memory. Not calling
     *   this prior to application exit can result in crashes due to internal
     *   threads attempting to access memory that has been already released
     *   by the exit handler.
     */
    static bool shutdown();

    /* Initialize OmMedia resources.
     * @remarks This must be called before calling any other Media API function
     *   prior to first use of the API, or any time after a shutdown() call has 
     *   been made.
     */
    static bool init();

private:
    OmMovie(const OmMovie& movie);
    OmMovie& operator=(const OmMovie& movie);
    struct MovieImpl& m;

public:
    /* For internal use, to support the C-interface. */
    static OmMovie* castFrom(OmMovieHandle m);

    /* For internal use, to support the C-interface. */
    struct MovieImpl& getImpl();
};

#endif // __cplusplus

/*************************************************************************
 *
 * C interfaces
 *
 *************************************************************************/

#ifndef __cplusplus
#   undef  OMMOVIE_C_API
#   define OMMOVIE_C_API
#endif

/**
 * Check if the track is a video track.
 * @return <i>true</i> if the track is a video track, <i>false</i> if not.
 */
OMMOVIE_C_API bool omTrackIsVideoType(const struct OmTrackInfo t);

/**
 * Check if the track is a audio track.
 * @return <i>true</i> if the track is a audio track, <i>false</i> if not.
 */
OMMOVIE_C_API bool omTrackIsAudioType(const struct OmTrackInfo t);

/**
 * Check if the track is a data track.
 * @return <i>true</i> if the track is a data track, <i>false</i> if not.
 */
OMMOVIE_C_API bool omTrackIsDataType(const struct OmTrackInfo t);

/** 
 * Return the Media API software version.
 * This function returns the software version of the currently loaded Media API.
 * A client application can, for example, present this information in its
 * "about" box. Omneon API version numbers are composed of four parts:
 * major version, minor version, service release number and hotfix number.
 * @param major Holds the major release number.
 * @param minor Holds the minor release number.
 * @param service Holds the service release number.
 * @param hotfix Holds the hotfix release number.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidArgument</i>: one of the arguments was null.
 * @see OmSwVersion
 * @see omMovieGetThisSwVersionAsScalar
 * @see omMovieGetOmneonCreateVersion
 * @see omMovieGetOmneonCreateVersionAsScalar
 */
#ifndef SWIG
OMMOVIE_C_API OmMovieErr omMovieGetThisSwVersion(unsigned char *major,
                                                 unsigned char *minor,
                                                 unsigned char *service,
                                                 unsigned char *hotfix);
#else
OMMOVIE_C_API OmMovieErr omMovieGetThisSwVersion(unsigned char *OUTPUT,
                                                 unsigned char *OUTPUT,
                                                 unsigned char *OUTPUT,
                                                 unsigned char *OUTPUT);
#endif

/**
 * Return the Media API software version as a scalar.
 * This function returns the software version of the currently loaded Media API
 * as a single integer. This makes it easy to do comparisons on version numbers.
 * @return The version number.
 * @see OmSwVersion
 * @see omMovieGetThisSwVersion
 * @see omMovieGetRemoteSwVersionAsScalar
 * @see omMovieGetOmneonCreateVersion
 * @see omMovieGetOmneonCreateVersionAsScalar
 */
OMMOVIE_C_API unsigned int omMovieGetThisSwVersionAsScalar();

/**
 * Return the Media API software version running on a remote host.
 * This method returns the software version of Media API currently
 * loaded on the remote host identified by hostname.
 * @param hostname Name of remote host.
 * @param major Holds the major release number.
 * @param minor Holds the minor release number.
 * @param service Holds the service release number.
 * @param hotfix Holds the hotfix release number.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidArgument</i>: one of the arguments was null.
 * @see omMovieGetThisSwVersion
 */
#ifndef SWIG
OMMOVIE_C_API OmMovieErr omMovieGetRemoteSwVersion(const char* hostname,
                                                   unsigned char *major,
                                                   unsigned char *minor,
                                                   unsigned char *service,
                                                   unsigned char *hotfix);
#else
OMMOVIE_C_API OmMovieErr omMovieGetRemoteSwVersion(const char* INPUT,
                                                   unsigned char *OUTPUT,
                                                   unsigned char *OUTPUT,
                                                   unsigned char *OUTPUT,
                                                   unsigned char *OUTPUT);
#endif

/**
 * Return the Media API software version as a scalar.
 * This function returns the software version of the currently loaded Media API
 * as a single integer. This makes it easy to do comparisons on version numbers.
 * @param hostname Name of remote host.
 * @return The version number.
 * @see OmSwVersion
 * @see omMovieGetRemoteSwVersion
 * @see omMovieGetThisSwVersionAsScalar
 */
OMMOVIE_C_API unsigned int omMovieGetRemoteSwVersionAsScalar(const char* hostname);

/**
 * Check if host is running a remote MAPI service.
 * @param hostname Name of host running RPC service.
 * @return Error code
 *  - <i>omErrOk</i> if the service is available.
 *  - <i>omRpcTimeout</i> if the service is not available.
 *  - <i>omRpcDisabled</i> if remote services are not enabled in this version of the MAPI.
 */
OMMOVIE_C_API OmMovieErr omMoviePingRemoteHost(const char* hostname);

/** 
 * Enable logging to a file.
 * This function enables or disables logging of Media API activity to a file.
 * @param logfile A string with the filename of the log file to use.
 * @remarks If a filename is specified, logging will be appended at the
 *  end of the file. If filename is NULL or "", logging will be
 *  turned off. Note that once logging is enabled, <i>all</i> calls
 *  to the Media API will be logged, not just those of the OmMovie class.
 */
OMMOVIE_C_API void omMovieSetDebugLog(const char* logfile);

/**
 * Turn on a select bit of a debug variable.
 * This function enables a particular bit of a debug variable.
 * @param var Name of the debug variable.
 * @param bitName Name of the bit to turn on.
 * @see omMovieSetDebugValue
 */
OMMOVIE_C_API void omMovieSetDebugBitName(const char* var, const char* bitName);

/**
 * Turn on a select bit of a debug variable.
 * This function enables a particular bit of a debug variable.
 * @param hostname Name of host running RPC service.
 * @param var Name of the debug variable.
 * @param bitName Name of the bit to turn on.
 * @return Error code
 * @see omMovieRemoteSetDebugValue
 */
OMMOVIE_C_API OmMovieErr omMovieSetRemoteDebugBitName(const char* hostname, const char* var, const char* bitName);

/**
 * Turn on a select bit of a debug variable.
 * This function enables a particular bit of a debug variable.
 * @param var Name of the debug variable.
 * @param value Value of debug variable.
 * @see omMovieSetDebugBitName
 */
OMMOVIE_C_API void omMovieSetDebugValue(const char* var, unsigned int value);

/**
 * Turn on a select bit of a debug variable.
 * This function enables a particular bit of a debug variable.
 * @param hostname Name of host running RPC service.
 * @param var Name of the debug variable.
 * @param value Value of debug variable.
 * @return Error code
 * @see omMovieSetRemoteDebugBitName
 */
OMMOVIE_C_API OmMovieErr omMovieSetRemoteDebugValue(const char* hostname, const char* var, unsigned int value);

/** 
 * Create a new OmMovie object.
 * @param hostname A string with the name of the host to run on. Use NULL to run locally.
 * @return Handle to newly created OmMovie.
 * @remarks This constructor creates an empty OmMovie object. To associate this object with
 *   an existing movie file, the omMovieOpen() function needs to be called. This object must 
 *   be released with freeOmMovie().
 * @see omMovieOpen
 * @see freeOmMovie
 */
OMMOVIE_C_API OmMovieHandle omMovieCreate(const char* hostname);

/** 
 * Destroy an OmMovie object
 * @param m Handle to OmMovie object.
 * @remarks When an object that is open is destroyed, omMovieClose() will automatically be called.
 */
OMMOVIE_C_API void omMovieDestroy(OmMovieHandle m);

/** 
 * Open a movie clip.
 * This function opens a movie clip. This operation associates a
 * newly constructed OmMovie object with a movie clip. Most other functions
 * in the OmMovie class expect an object that is open.
 * @param m Handle to OmMovie object.
 * @param filename A string with the filename of the movie clip to open.
 * @param accessMode The access mode for this clip. If an access mode is not given, <i>accReadOnly</i> is assumed by default.
 * @param wrapMode The wrapping mode for this clip. Note that when opening an existing clip <i>wrapPreserve</i> is the only allowed value.
 * @param style When creating a new clip, this is a string that can be used to indicate a specific type of clip to create. Examples:
 *   - <i>"d10"</i> to create an eVTR/D10 MXF OP1a movie clip.
 *   - <i>"as02"</i> to create an AS02 MXF movie clip.
 *   - <i>"rdd9"</i> to create an RDD9 MXF OP1a movie clip.
 *   - <i>"lowLatency"</i> to create a low latency MXF OP1a movie clip.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the object is already open.
 *   - <i>omErrInvalidArgument</i>: one of the arguments provided is not compatible with the open operation requested.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks An open OmMovie object can be closed by calling the omMovieClose() function. Closing the object
 *   releases all resources associated with the movie clip and resets the object back to an empty state.
 *   At this point, the object can be reused by calling omMovieOpen() again.
 * @see OmAccessMode
 * @see OmWrapMode
 * @see omMovieClose
 */
OMMOVIE_C_API OmMovieErr omMovieOpen(OmMovieHandle m,
                                     const char* filename,
                                     enum OmAccessMode accessMode,
                                     enum OmWrapMode wrapMode,
                                     const char* style);

/**
 * Check if a movie object is in an open state.
 * @param m Handle to OmMovie object.
 * @return <i>true</i> if the object has been successfully initialized and is open, <i>false</i> if the object is in a closed state, or <i>m</i> is not a valid handle.
 * @remarks A movie object is in an open state when it is associated with a movie file on disk, typically after a successful call to omMovieOpen().
 *   A movie object that is closed is in an empty state, without an association to a movie file.
 * @see omMovieOpen
 * @see omMovieClose
 */
OMMOVIE_C_API bool omMovieIsOpen(OmMovieHandle m);

/**
 * Check if a movie object has been modified since loaded or last written to disk.
 * @param m Handle to OmMovie object.
 * @return <i>true</i> if the object has changes that have not been written to disk, <i>false</i> otherwise (or <i>m</i> is not a valid handle).
 * @remarks The omMovieFlush() function is used to write unsaved metadata changes to an existing movie on disk.
 *   The omMovieSave() and omMovieSaveCopy() functions regenerate the movie wrapper.
 * @see omMovieSave
 * @see omMovieSaveCopy
 * @see omMovieFlush
 */
OMMOVIE_C_API bool omMovieIsDirty(OmMovieHandle m);

/**
 * Return the dirty mode of the movie.
 * @param m Handle to OmMovie object.
 * @return A value that indicates what kind of changes have been made to the movie, and if an omMovieFlush() or a omMovieSave() is necessary to write those changes to disk.
 * @remarks The dirty mode gives more information than the boolean dirty flag. The omMovieFlush()
 *   function is used to write unsaved metadata changes to an existing movie on disk. The omMovieSave()
 *   and omMovieSaveCopy() functions regenerate the movie wrapper.
 * @see OmDirtyMode
 * @see omMovieSave
 * @see omMovieSaveCopy
 * @see omMovieFlush
 */
OMMOVIE_C_API enum OmDirtyMode omMovieGetDirtyMode(OmMovieHandle m);

/**
 * Check if the movie was open with write access.
 * @param m Handle to OmMovie object.
 * @return <i>true</i> if the movie can be modified, <i>false</i> if the movie was open in read-only mode, or <i>m</i> is an invalid handle.
 */
OMMOVIE_C_API bool omMovieIsWritable(OmMovieHandle m);

/**
 * Check if the movie is growing.
 * @param m Handle to OmMovie object.
 * @return <i>true</i> if the movie is growing, <i>false</i> if not, or <i>m</i> is an invalid handle.
 * @remarks 
 *   - The movie length reported by omMovieGetDuration() should not be considered final if the movie
 *     is growing. As soon as the movie stops growing, a new call to omMovieGetDuration() will return
 *     the final length.
 *   - If the movie is growing, the <i>lastReadableFrame</i> member of the OmMovieInfo structure contains
 *     the last frame that is safe to read. Reading frames past the reported last readable frame may result
 *     in an error, as the frames at the end of a growing movie may not have been completely flushed to
 *     disk by the process that is doing the writing.
 *   - It may take a few seconds after the movie stops growing for this function to return <i>false</i>.
 * @see omMovieGetDuration
 */
OMMOVIE_C_API bool omMovieIsGrowing(OmMovieHandle m);

/**
 * Set the default video frame rate to use for movies that don't specify one.
 * @param m Handle to OmMovie object.
 * @param videoRate The video frame rate to use on this movie, if the movie itself does not provide one.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the movie cannot accept a default video rate at this time, for example because it is closed.
 * @remarks A default video frame rate is useful, for example, for .wav or .aiff audio files. It is also
 *   used by raw DNxHD files. All functions that accept or return frame numbers will assume this frame rate if
 *   the movie does not explicitly provide one.
 */
OMMOVIE_C_API OmMovieErr omMovieSetDefaultVideoRate(OmMovieHandle m, enum OmFrameRate videoRate);

/**
 * Return the error code for the last operation done on an object.
 * @param m Handle to OmMovie object.
 * @return The error code of the last operation on the OmMovie object referenced by <i>m</i>, or <i>omErrInvalidMovieHandle</i> if <i>m</i> is not valid.
 */
OMMOVIE_C_API OmMovieErr omMovieGetLastErrorCode(OmMovieHandle m);

/**
 * Return a text message for the last error code.
 * @param m Handle to OmMovie object.
 * @return A string with information about the last operation done on the object referenced by <i>m</i>.
 * @remarks For applications that write log files, Omneon recommends that the error string be written to
 *   the log whenever a function returns an error.
 */
OMMOVIE_C_API const char* omMovieGetLastErrorString(OmMovieHandle m);

/**
 * Write any unsaved changes on the object to disk.
 * @param m Handle to OmMovie object.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the movie cannot be flushed in its current state.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks If there are no unsaved changes then this function does nothing.
 */
OMMOVIE_C_API OmMovieErr omMovieFlush(OmMovieHandle m);

/**
 * Write the movie associated with the object to disk.
 * @param m Handle to OmMovie object.
 * @return A handle that can be used to obtain information about the asynchronous save operation, or 0 if <i>m</i> is an invalid handle.
 * @remarks
 *   - The filename and other movie parameters are those given in the omMovieOpen() call.
 *   - The omMovieSave() operation is asynchronous. This function will return immediately and the
 *     operation will be carried out as a background task. 
 *   - The omMovieGetSaveProgress() function can be used to find out when the operation has completed.
 *   - Multiple save operations can be started. The returned OmSaveHandle identifies each one.
 *   - For some types of changes the movie wrapper needs to be regenerated. In those cases, the
 *     save operation will write the new wrapper to a temporary file and, as soon as the new
 *     wrapper is complete, the original movie will be deleted and the temporary wrapper renamed.
 *     If this asynchronous behavior causes problems, then omMovieSaveCopy() should be used instead.
 * @see omMovieGetSaveProgress
 * @see omMovieSaveCopy
 * @see OmSaveHandle
 */
OMMOVIE_C_API OmSaveHandle omMovieSave(OmMovieHandle m);

/**
 * Write the movie associated with the object to a new file on disk.
 * @param m Handle to OmMovie object.
 * @param filename The target file on disk.
 * @param replace <i>true</i> to overwrite an existing file, <i>false</i> to only write if the file did not exist before.
 * @param wrapMode The wrapping mode for the saved clip.
 * @param style A string that can be used to indicate a specific type of clip to create. Examples:
 *   - <i>"d10"</i> to create an eVTR/D10 MXF OP1a movie clip.
 *   - <i>"as02"</i> to create an AS02 MXF movie clip.
 *   - <i>"rdd9"</i> to create an RDD9 MXF OP1a movie clip.
 *   - <i>"lowLatency"</i> to create a low latency MXF OP1a movie clip.
 * @return A handle that can be used to obtain information about the asynchronous save operation, or 0 if <i>m</i> is an invalid handle.
 * @remarks 
 *   - The omMovieSaveCopy() operation is asynchronous, this function will return immediately and the
 *     operation will be carried out as a background task. 
 *   - The omMovieGetSaveProgress() function can be used to find out when the operation has completed.
 *   - Multiple save operations can be started. The returned OmSaveHandle identifies each one.
 * @see omMovieGetSaveProgress
 * @see OmSaveHandle
 */
OMMOVIE_C_API OmSaveHandle omMovieSaveCopy(OmMovieHandle m,
                                           const char* filename,
                                           bool replace,
                                           enum OmWrapMode wrapMode,
                                           const char* style);

/**
 * Return progress information about an asynchronous save operation.
 * @param m Handle to OmMovie object.
 * @param saveHandle The OmSaveHandle instance returned by omMovieSave() or omMovieSaveCopy().
 * @param totalFrames If not NULL, the total number of frames will be stored on this location.
 * @param processedFrames If not NULL, the number of processed frames will be stored in this location.
 * @return Error code
 *   - <i>omErrOk</i>: the save operation completed successfully. The totalFrames and processedFrames numbers are final.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInProgress</i>: the save operation is still in progress. The totalFrames and processedFrames numbers are not final.
 *   - <i>omErrAborted</i>: the background save was aborted by a call to omMovieAbortSave().
 *   - <i>omErrInvalidArgument</i>: the handle is not valid for this object.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks 
 *   - If the source clip is growing, totalFrames will change as the clip grows.
 *   - To compute save completion percentage in the 0-100 range, use the following expression:<br /> 
 *     <i>totalFrames == 0 ? 0 : processedFrames * 100 / totalFrames</i>.
 *   - Save handles are unique across OmMovie objects, so any OmMovie instance (even one that is in a closed state)
 *     can return progress information for any save operation currently in progress.
 * @see omMovieSave
 * @see omMovieSaveCopy
 * @see omMovieAbortSave
 * @see OmSaveHandle
 * @see OmWrapMode
 */
#ifndef SWIG
OMMOVIE_C_API OmMovieErr omMovieGetSaveProgress(OmMovieHandle m,
                                                OmSaveHandle saveHandle,
                                                unsigned int* totalFrames,
                                                unsigned int* processedFrames);
#else
OMMOVIE_C_API OmMovieErr omMovieGetSaveProgress(OmMovieHandle m,
                                                OmSaveHandle saveHandle,
                                                unsigned int* OUTPUT,
                                                unsigned int* OUTPUT);
#endif

/** 
 * Abort a save operation.
 * @param m Handle to OmMovie object.
 * @param saveHandle The OmSaveHandle instance returned by omMovieSave() or omMovieSaveCopy().
 * @return Error code
 *   - <i>omErrOk</i>: the save operation was canceled.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: the handle is not valid for this object.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks This function simply passes the abort request to the background save task. The
 *   task has been effectively aborted when calls to omMovieGetSaveProgress() return an
 *   <i>omErrAborted</i> error code.
 * @see omMovieSave
 * @see omMovieSaveCopy
 */
OMMOVIE_C_API OmMovieErr omMovieAbortSave(OmMovieHandle m, OmSaveHandle saveHandle);

/** 
 * Close an OmMovie object.
 * This function closes an open OmMovie object, releasing all the resources associated with the open movie clip and
 * bringing the object back to an empty state.
 * @param m Handle to OmMovie object.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the object is already in a closed state.
 * @remarks Omneon recommends that you close OmMovie objects as soon as you are done with them,
 *  as this releases all the resources associated with the open movie clip. Closing an open object
 *  is required if the object is going to be reused. Note that freeOmMovie() automatically closes
 *  objects that are still open.
 * @see omMovieOpen
 * @see freeOmMovie
 */
OMMOVIE_C_API OmMovieErr omMovieClose(OmMovieHandle m);

/**
 * Return the duration of the movie.
 * @param m Handle to OmMovie object.
 * @param trimAudio If set to <i>true</i>, the duration returned will be the one for the longest video track. 
 *  If set to <i>false</i> the duration returned will be the one for the longest track of any type. 
 * @return The duration of the movie in video frames, or 0 in case an error occurred.
 * @remarks 
 *   - Some movies have slightly longer audio tracks, and that may cause the movie duration
 *     to be a frame too long. Passing trimAudio set to true prevents the audio tracks from
 *     being considered when calculating the movie duration.
 *   - Error information can be obtained by calling omMovieGetLastErrorCode() and omMovieGetLastErrorString().
 */
OMMOVIE_C_API int omMovieGetDuration(OmMovieHandle m, bool trimAudio);

/**
 * Return movie information.
 * @param m Handle to OmMovie object.
 * @param info A reference to a OmMovieInfo structure, where the movie information will be stored.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: <i>info</i> is NULL.
 *   - <i>omErrBadState</i>: the movie cannot return movie information in its current state. For example, it may be closed.
 * @see OmMovieInfo
 */
OMMOVIE_C_API OmMovieErr omMovieGetMovieInfo(OmMovieHandle m, struct OmMovieInfo* info);

/**
 * Return the media id associated with the specified media file index.
 * @param m Handle to OmMovie object.
 * @param mediaIndex A zero-based index for the media file.
 * @return OmMediaId for the requested media file, or OmMediaId(0) if the mediaIndex given is invalid.
 * @remarks The total number of media files in a movie is returned in the numMedia field of the OmMovieInfo structure.
 *  The return value of this function can be passed as an argument to omMovieGetPath() to obtain a pathname.
 * @see OmMovieInfo
 * @see omMovieGetMovieInfo
 * @see omMovieGetPath
 */
OMMOVIE_C_API OmMediaId omMovieGetMediaId(OmMovieHandle m, int mediaIndex);

/**
 * Return the pathname of the media file associated with the given media id.
 * @param m Handle to OmMovie object.
 * @param id The OmMediaId of the media file. A media file index can be converted to a OmMediaId by the omMovieGetMediaId() function.
 * @param buffer The buffer that will hold the pathname.
 * @param bufferSize On input, a pointer to the size of buffer. On output, the actual length of the pathname, including the string terminator.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the movie cannot return path information in its current state. For example, it may be closed.
 *   - <i>omErrBufferTooSmall</i>: the buffer provided isn't big enough to hold the pathname. The bufferSize argument indicates how much space is needed.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 */
#ifndef SWIG
OMMOVIE_C_API OmMovieErr omMovieGetPath(OmMovieHandle m, OmMediaId id, char* buffer, int* bufferSize);
#else
OMMOVIE_C_API OmMovieErr omMovieGetPath(OmMovieHandle m, OmMediaId id, char* OUTPUT, int* INOUT);
#endif

#if 0
/**
 * Return the pathname of the media file associated with the given media id.
 * @param m Handle to OmMovie object.
 * @param id The OmMediaId of the media file. A media file index can be converted to a OmMediaId by the omMovieGetMediaId() function.
 * @return A string with the requested pathname, or 0 if there was an error.
 * @remarks 
 *   - The returned pointer points to memory owned by the OmMovie class. The pointer may become invalid
 *     after other calls are made. Therefore, Omneon recommends that you copy the data into an
 *     application-owned buffer.
 *   - Error information can be obtained by calling omMovieGetLastErrorCode() and omMovieGetLastErrorString().
 */
OMMOVIE_C_API const char* omMovieGetPath(OmMovieHandle m, OmMediaId id);
#endif

/**
 * Return track information.
 * @param m Handle to OmMovie object.
 * @param trackNum The zero-based index for the track.
 * @param info A reference to a OmTrackInfo structure where the track information will be stored.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the movie cannot return track information in its current state. For example, it may be closed.
 *   - <i>omErrInvalidArgument</i>: the track index is out of range, or info is NULL.
 * @remarks The total number of tracks in a movie is returned in the numTracks field of the OmMovieInfo structure.
 * @see OmTrackInfo
 * @see OmMovieInfo
 */
OMMOVIE_C_API OmMovieErr omMovieGetTrackInfo(OmMovieHandle m, int trackNum, struct OmTrackInfo* info);

/**
 * Return frame information.
 * @param m Handle to OmMovie object.
 * @param trackNum The zero-based index for the track.
 * @param frameNum The frame number.
 * @param info A reference to a OmFrameInfo structure, where the frame information will be stored.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the movie cannot return frame information in its current state. For example, it may be closed.
 *   - <i>omErrInvalidArgument</i>: the track or frame index is out of range, or info is NULL.
 * @remarks
 *   - The total number of tracks in a movie is returned in the numTracks field of the OmMovieInfo structure.
 *   - The valid frame range is given in the numPrecharge, firstFrame and lastFrame fields of the OmMovieInfo structure.
 *     The range goes from (firstFrame - numPrecharge) to (lastFrame - 1).
 * @see OmFrameInfo
 * @see OmMovieInfo
 */
OMMOVIE_C_API OmMovieErr omMovieGetFrameInfo(OmMovieHandle m, int trackNum, int frameNum, struct OmFrameInfo* info);

/**
 * Read a frame of the movie.
 * @param m Handle to OmMovie object.
 * @param trackNum The zero-based index for the track.
 * @param frameNum The frame number.
 * @param buffer The buffer where the frame is to be stored.
 * @param bufferSize A pointer to the size of buffer. On output the actual size of the frame will be stored in this variable.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the movie cannot return a frame in its current state. For example, it may be closed.
 *   - <i>omErrBufferTooSmall</i>: the buffer provided isn't big enough to hold the entire frame. The bufferSize argument indicates how much space is needed.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 */
#ifndef SWIG
OMMOVIE_C_API OmMovieErr omMovieReadFrame(OmMovieHandle m, int trackNum, int frameNum, char* buffer, int* bufferSize);
#else
OMMOVIE_C_API OmMovieErr omMovieReadFrame(OmMovieHandle m, int trackNum, int frameNum, char* OUTPUT, int* INOUT);
#endif

#if 0
/**
 * Read a frame of the movie.
 * @param m Handle to OmMovie object.
 * @param trackNum The zero-based index for the track.
 * @param frameNum The frame number.
 * @param bufferSize A pointer where the size of the frame will be stored.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the movie cannot return a frame in its current state. For example, it may be closed.
 *   - <i>omErrInvalidArgument</i>: the track or frame index is out of range, or bufferSize is NULL.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 */
#ifndef SWIG
OMMOVIE_C_API const char* omMovieReadFrame(OmMovieHandle m, int trackNum, int frameNum, int* bufferSize);
#else
OMMOVIE_C_API const char* omMovieReadFrame(OmMovieHandle m, int trackNum, int frameNum, int* IGNORE);
#endif
#endif

/**
 * Rename the movie on disk.
 * @param m Handle to OmMovie object.
 * @param newName The new pathname of the movie.
 * @param renameMedia If <i>true</i>, media files will also be renamed. If <i>false</i>, media files will keep their names.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the movie cannot be renamed in its current state. For example, it may be closed, or read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks 
 *   - The newName argument can indicate a new directory for the movie, in which case the movie will be
 *     moved to that directory, along with all its referenced media files.
 *   - If the renameMedia argument is <i>true</i> then the movie must be open with write access to perform
 *     the rename operation.
 */
OMMOVIE_C_API OmMovieErr omMovieRename(OmMovieHandle m, const char* newName, bool renameMedia);

/**
 * Delete the movie on disk.
 * @param m Handle to OmMovie object.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the movie cannot be deleted in its current state. For example, it may be closed.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks Any media files referenced by the movie will also be deleted.
 */
OMMOVIE_C_API OmMovieErr omMovieRemove(OmMovieHandle m);

/**
 * Check if the movie was created by Omneon.
 * @param m Handle to OmMovie object.
 * @return <i>true</i> if the movie was created by Omneon software, <i>false</i> otherwise, or <i>m</i> is not a valid handle.
 */
OMMOVIE_C_API bool omMovieIsOmneonMovie(OmMovieHandle m);

/**
 * Return the version of Omneon software that created the movie.
 * @param m Handle to OmMovie object.
 * @param major Holds the major release number.
 * @param minor Holds the minor release number.
 * @param service Holds the service release number.
 * @param hotfix Holds the hotfix release number.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidArgument</i>: one of the arguments was null.
 * @remarks If the movie was not created by Omneon software, the returned OmSwVersion will
 *  be marked as invalid (major, minor, service and hotfix are all <i>0xff</i>).
 * @see OmSwVersion
 * @see omMovieGetThisSwVersionAsScalar
 * @see omMovieGetOmneonCreateVersion
 * @see omMovieGetOmneonCreateVersionAsScalar
 */
#ifndef SWIG
OMMOVIE_C_API OmMovieErr omMovieGetOmneonCreateVersion(OmMovieHandle m,
                                                       unsigned char *major,
                                                       unsigned char *minor,
                                                       unsigned char *service,
                                                       unsigned char *hotfix);
#else
OMMOVIE_C_API OmMovieErr omMovieGetOmneonCreateVersion(OmMovieHandle m,
                                                       unsigned char *OUTPUT,
                                                       unsigned char *OUTPUT,
                                                       unsigned char *OUTPUT,
                                                       unsigned char *OUTPUT);
#endif

/**
 * Return the version of Omneon software that created the movie, as a scalar.
 * This function returns the software version as a single integer. This makes
 * it easy to do comparisons on version numbers.
 * @return The version number.
 * @remarks If the movie was not created by Omneon software, the returned version
 *  is invalid (<i>0xffffffff</i>).
 * @see OmSwVersion
 * @see omMovieGetOmneonCreateVersion
 * @see omMovieGetThisSwVersion
 * @see omMovieGetThisSwVersionAsScalar
 */
OMMOVIE_C_API unsigned int omMovieGetOmneonCreateVersionAsScalar(OmMovieHandle m); 

/**
 * Return the default in frame of the movie.
 * @param m Handle to OmMovie object.
 * @param defaultIn A reference to an integer variable that will receive the default in frame number of the movie.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: defaultIn is NULL.
 *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
 * @remarks To returned default in frame number will be between OmMovieInfo::firstFrame
 *  and the current default out frame number.
 * @see omMovieGetMovieInfo
 * @see omMovieGetFirstFrame
 */
#ifndef SWIG
OMMOVIE_C_API OmMovieErr omMovieGetDefaultIn(OmMovieHandle m, int* defaultIn);
#else
OMMOVIE_C_API OmMovieErr omMovieGetDefaultIn(OmMovieHandle m, int* OUTPUT);
#endif

/**
 * Set the default in frame of the movie.
 * @param m Handle to OmMovie object.
 * @param defaultIn The frame number of the new default in frame of the movie.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks The range of valid values for the default in frame number is between OmMovieInfo::firstFrame
 *  and the current default out frame number.
 * @see omMovieGetMovieInfo
 * @see omMovieGetFirstFrame
 */
OMMOVIE_C_API OmMovieErr omMovieSetDefaultIn(OmMovieHandle m, int defaultIn);

/**
 * Return the default out frame of the movie.
 * @param m Handle to OmMovie object.
 * @param defaultOut A reference to an integer variable that will receive the default out frame number of the movie.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: defaultOut is NULL.
 *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
 * @remarks To returned default out frame number will be between the current default in frame number and 
 *  OmMovieInfo::lastFrame
 * @see omMovieGetMovieInfo
 * @see omMovieGetFirstFrame
 */
#ifndef SWIG
OMMOVIE_C_API OmMovieErr omMovieGetDefaultOut(OmMovieHandle m, int* defaultOut);
#else
OMMOVIE_C_API OmMovieErr omMovieGetDefaultOut(OmMovieHandle m, int* OUTPUT);
#endif

/**
 * Set the default out frame of the movie.
 * @param m Handle to OmMovie object.
 * @param defaultOut The frame number of the new default out frame of the movie.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks The range of valid values for the default out frame number is between the current default in
 *  frame number and OmMovieInfo::lastFrame.
 * @see omMovieGetMovieInfo
 * @see omMovieGetFirstFrame
 */
OMMOVIE_C_API OmMovieErr omMovieSetDefaultOut(OmMovieHandle m, int defaultOut);

/**
 * Return the timecode for the first frame of the movie.
 * @param m Handle to OmMovie object.
 * @param hour A reference to an integer variable that will receive the hour portion of the start timecode.
 * @param min A reference to an integer variable that will receive the minute portion of the start timecode.
 * @param sec A reference to an integer variable that will receive the second portion of the start timecode.
 * @param frame A reference to an integer variable that will receive the frame portion of the start timecode.
 * @param drop A reference to a boolean variable that will receive the drop-frame flag of the start timecode.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: hour, min, sec, frame, or drop is NULL.
 *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
 */
#ifndef SWIG
OMMOVIE_C_API OmMovieErr omMovieGetStartTimecode(OmMovieHandle m, int* hour, int* min, int* sec, int* frame, bool* drop);
#else
OMMOVIE_C_API OmMovieErr omMovieGetStartTimecode(OmMovieHandle m, int* OUTPUT, int* OUTPUT, int* OUTPUT, int* OUTPUT, bool* OUTPUT);
#endif

/**
 * Set the timecode for the first frame of the movie.
 * @param m Handle to OmMovie object.
 * @param hour The hour portion of the new start timecode.
 * @param min The minute portion of the new start timecode.
 * @param sec The second portion of the new start timecode.
 * @param frame The frame portion of the new start timecode.
 * @param drop The drop-frame flag of the new start timecode, <i>true</i> for drop-frame, <i>false</i> for non-drop frame.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 */
OMMOVIE_C_API OmMovieErr omMovieSetStartTimecode(OmMovieHandle m, int hour, int min, int sec, int frame, bool drop);

/**
 * Return the starting frame number for the movie.
 * @param m Handle to OmMovie object.
 * @param firstFrame A reference to an integer variable that will receive the first frame number of the movie.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: firstFrame is NULL.
 *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
 * @remarks All frame numbers returned and accepted by omMovie* functions are adjusted by the first frame of the movie.
 */
#ifndef SWIG
OMMOVIE_C_API OmMovieErr omMovieGetFirstFrame(OmMovieHandle m, int* firstFrame);
#else
OMMOVIE_C_API OmMovieErr omMovieGetFirstFrame(OmMovieHandle m, int* OUTPUT);
#endif

/**
 * Set the starting frame number for the movie.
 * @param m Handle to OmMovie object.
 * @param firstFrame The new first frame number of the movie.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks All frame numbers returned and accepted by omMovie* functions are adjusted by the first frame of the movie.
 */
OMMOVIE_C_API OmMovieErr omMovieSetFirstFrame(OmMovieHandle m, int firstFrame);


/**
 * Return the UMID for the movie.
 * @param m Handle to OmMovie object.
 * @param buffer The buffer that will hold the UMID.
 * @param bufferSize The size of buffer. This variable will store the actual length of the UMID, including the string terminator.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: buffer, or bufferSize is NULL.
 *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
 *   - <i>omErrBufferTooSmall</i>: the buffer provided isn't big enough to hold the umid. The bufferSize argument indicates how much space is needed.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 */
#ifndef SWIG
OMMOVIE_C_API OmMovieErr omMovieGetUmid(OmMovieHandle m, char* buffer, int* bufferSize);
#else
OMMOVIE_C_API OmMovieErr omMovieGetUmid(OmMovieHandle m, char* OUTPUT, int* INOUT);
#endif

#if 0
/**
 * Return the UMID for the movie.
 * @param m Handle to OmMovie object.
 * @return A string with the movie UMID, or 0 if there was an error.
 * @remarks 
 *   - The returned pointer points to memory owned by the OmMovie class. The pointer may become invalid after other calls are made.
 *     Therefore, Omneon recommends that you copy the data into an application-owned buffer.
 *   - Error information can be obtained by calling omMovieGetLastErrorCode() and omMovieGetLastErrorString().
 */
OMMOVIE_C_API const char* omMovieGetUmid(OmMovieHandle m);
#endif

/**
 * Generate a new UMID for the movie.
 * @param m Handle to OmMovie object.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 */
OMMOVIE_C_API OmMovieErr omMovieGenerateUmid(OmMovieHandle m);

/**
 * Set the UMID of a proxy movie.
 * @param m Handle to OmMovie object.
 * @param sourceMovie Handle to the proxy source movie
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> or sourceMovie is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: sourceMovie could not be used.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be closed.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks
 *   - A proxy's UMID is identical to the source movie's UMID with the exception of the instance number byte (bytes 14). See SMPTE 330M. 
 *   - No validation is done to ensure that the UMID on the source movie really does describe the contents of the proxy (such as number of tracks, and their types).
 */
OMMOVIE_C_API OmMovieErr omMovieSetProxyUmid(OmMovieHandle m, OmMovieHandle sourceMovie);

/**
 * Return the UMID for a proxy's source movie.
 * @param m Handle to OmMovie object.
 * @param buffer The buffer that will hold the UMID.
 * @param bufferSize The size of buffer. This variable will store the actual length of the UMID, including the string terminator.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: buffer, or bufferSize is NULL.
 *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
 *   - <i>omErrBufferTooSmall</i>: the buffer provided isn't big enough to hold the umid. The bufferSize argument indicates how much space is needed.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 */
#ifndef SWIG
OMMOVIE_C_API OmMovieErr omMovieGetSourceUmid(OmMovieHandle m, char* buffer, int* bufferSize);
#else
OMMOVIE_C_API OmMovieErr omMovieGetSourceUmid(OmMovieHandle m, char* OUTPUT, int* INOUT);
#endif

#if 0
/**
 * Return the UMID for a proxy's source movie.
 * @param m Handle to OmMovie object.
 * @return A string with the movie UMID, or 0 if there was an error.
 * @remarks 
 *   - The returned pointer points to memory owned by the OmMovie class. The pointer may become invalid after other calls are made.
 *     Therefore, Omneon recommends that you copy the data into an application-owned buffer.
 *   - Error information can be obtained by calling getLastErrorCode() and getLastErrorString().
 */
OMMOVIE_C_API const char* omMovieGetSourceUmid(OmMovieHandle m);
#endif

/**
 * Return the AFD (active format description) associated with the movie.
 * @param m Handle to OmMovie object.
 * @param afd A reference to a variable that will receive the AFD of the movie.
 * @param trackNum The zero-based index of the track to query, or ~0 to use the first video track of the movie.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: the requested track is not a video track, or afd is NULL.
 *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks See SMPTE 2016-1 for the format of the AFD byte.
 */
#ifndef SWIG
OMMOVIE_C_API OmMovieErr omMovieGetVideoAfd(OmMovieHandle m, unsigned char* afd, int trackNum);
#else
OMMOVIE_C_API OmMovieErr omMovieGetVideoAfd(OmMovieHandle m, unsigned char* OUTPUT, int trackNum);
#endif

/**
 * Set the AFD (active format description) of the movie.
 * @param m Handle to OmMovie object.
 * @param afd The new AFD value for the movie.
 * @param trackNum The zero-based index of the track to change, or ~0 to use the first video track of the movie.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: the requested track is not a video track.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks See SMPTE 2016-1 for the format of the AFD byte.
 */
OMMOVIE_C_API OmMovieErr omMovieSetVideoAfd(OmMovieHandle m, unsigned char afd, int trackNum);

/**
 * Extract data such as closed captions or timecodes embedded in the frames.
 * @param m Handle to OmMovie object.
 * @param trackNum The zero-based index for the track.
 * @param startFrame The first frame number to extract.
 * @param numFrames The number of frames to extract.
 * @param dataType An OmMediaClipDataType value that indicates the type of data to extract.
 * @param buffer The buffer where the data is to be stored.
 * @param bufferSize A pointer to the size of the buffer. On output the actual size of the returned data will be stored in this variable.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: one of the arguments is invalid.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @see OmMediaClipDataType
 */
#ifndef SWIG
OMMOVIE_C_API OmMovieErr omMovieGetFrameData(OmMovieHandle m, int trackNum, int startFrame, int numFrames,
                              enum OmMediaClipDataType dataType, char *buffer, int *bufferSize);
#else
OMMOVIE_C_API OmMovieErr omMovieGetFrameData(OmMovieHandle m, int trackNum, int startFrame, int numFrames,
                              enum OmMediaClipDataType dataType, char *OUTPUT, int *INOUT);
#endif

#if 0
/**
 * Extract data such as closed captions or timecodes embedded in the frames.
 * @param m Handle to OmMovie object.
 * @param trackNum The zero-based index for the track.
 * @param startFrame The first frame number to read.
 * @param numFrames The number of frames to extract.
 * @param dataType An OmMediaClipDataType value that indicates the type of data to extract.
 * @param bufferSize A pointer to the size of the buffer. On output the actual size of the data will be stored in this variable.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: one of the arguments is invalid.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @see OmMediaClipDataType
 */
#ifndef SWIG
OMMOVIE_C_API const char* omMovieGetFrameData(OmMovieHandle m, int trackNum, int startFrame, int numFrames,
                  enum OmMediaClipDataType dataType, int *bufferSize);
#else
OMMOVIE_C_API const char* omMovieGetFrameData(OmMovieHandle m, int trackNum, int startFrame, int numFrames,
                  enum OmMediaClipDataType dataType, int *IGNORE);
#endif
#endif

/**
 * Insert data such as closed captions or timecodes into frames.
 * @param m Handle to OmMovie object.
 * @param trackNum The zero-based index for the track.
 * @param startFrame The first frame number to read.
 * @param numFrames The number of frames to extract.
 * @param dataType An OmMediaClipDataType value that indicates the type of data to insert.
 * @param buffer The buffer that will hold the data.
 * @param bufferSize A pointer to the size of buffer. On output the actual size of the data will be stored in this variable.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: one of the arguments is invalid.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @see OmMediaClipDataType
 */
OMMOVIE_C_API OmMovieErr omMovieSetFrameData(OmMovieHandle m, int trackNum, int startFrame, int numFrames,
                  enum OmMediaClipDataType dataType, char *buffer, int *bufferSize);

/**
 * Return the number of properties associated with the movie.
 * @param m Handle to OmMovie object.
 * @return The number of properties stored in the movie, or 0 in case of error.
 * @remarks Error information can be obtained by calling omMovieGetLastErrorCode() and omMovieGetLastErrorString().
 */
OMMOVIE_C_API int omMovieGetMoviePropertyCount(OmMovieHandle m);

/**
 * Return a property of the movie.
 * @param m Handle to OmMovie object.
 * @param index The index of the property.
 * @param name A buffer to store the property name.
 * @param nameSize Size of name buffer. On output, the actual size of name will be stored in this variable.
 * @param value A buffer to store the property value.
 * @param valueSize Size of value buffer. On output, the actual size of the value will be stored in this variable.
 * @param type What type of value is stored in the value buffer.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omInvalidArgument</i>: the property index is out of range, or one of the pointer arguments is NULL.
 *   - <i>omErrBufferTooSmall</i>: either the name or value buffer is too small.
 *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks On output, maxNameBytes and maxValueBytes may be larger than the buffer size. 
 * @see omMovieGetMoviePropertyByName
 * @see omMovieGetTrackProperty
 * @see omMovieGetTrackPropertyByName
 * @see OmMediaPropertyType
 */
OMMOVIE_C_API OmMovieErr omMovieGetMovieProperty(OmMovieHandle m, int index,
                                                 char *name, uint *nameSize,
                                                 void *value, uint *valueSize,
                                                 OmMediaPropertyType *type);

/**
 * Return a property of the movie.
 * @param m Handle to OmMovie object.
 * @param name The name of the property.
 * @param value A buffer to store the property value.
 * @param valueSize Size of value buffer. On output, the actual size of the value will be stored in this variable.
 * @param type What type of value is stored in the value buffer.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omInvalidArgument</i>: the property index is out of range, or the property name was not found, or one of thepointer arguments was NULL.
 *   - <i>omErrBufferTooSmall</i>: the value buffer is too small.
 *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @see omMovieGetMovieProperty
 * @see omMovieGetTrackProperty
 * @see omMovieGetTrackPropertyByName
 * @see OmMediaPropertyType
 */
OMMOVIE_C_API OmMovieErr omMovieGetMoviePropertyByName(OmMovieHandle m, const char* name,
                                                       void *value, uint *valueSize,
                                                       OmMediaPropertyType *type);

/**
 * Add or replace a property in the movie.
 * @param m Handle to OmMovie object.
 * @param name property name
 * @param value property value
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omInvalidArgument</i>: the property is incompatible with an existing property of the same name.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks This function can only be used to set properties with text values.
 * @see omMovieSetMoviePropertyAndType
 * @see omMovieSetTrackProperty
 * @see omMovieSetTrackPropertyAndType
 * @see OmMediaPropertyType
 */
OMMOVIE_C_API OmMovieErr omMovieSetMovieProperty(OmMovieHandle m, const char *name, const char *value);

/**
 * Add or replace a property in the movie.
 * @param m Handle to OmMovie object.
 * @param name property name
 * @param value property value
 * @param valueSize Size of value buffer.
 * @param type What type of value is stored in the value buffer.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omInvalidArgument</i>: the property is incompatible with an existing property of the same name.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @see omMovieSetMovieProperty
 * @see omMovieSetTrackProperty
 * @see omMovieSetTrackPropertyAndType
 * @see OmMediaPropertyType
 */
OMMOVIE_C_API OmMovieErr omMovieSetMoviePropertyAndType(OmMovieHandle m, const char *name,
                                                        const void *value, uint valueSize,
                                                        OmMediaPropertyType type);

/**
 * Delete a property of the movie.
 * @param m Handle to OmMovie object.
 * @param name The name of the property to delete.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 */
OMMOVIE_C_API OmMovieErr omMovieDeleteMovieProperty(OmMovieHandle m, const char* name);

/**
 * Return the number of properties associated with a track of the movie.
 * @param m Handle to OmMovie object.
 * @param trackNum track number (indexed from 0)
 * @return The number of properties stored in the track, or 0 in case of error.
 * @remarks Error information can be obtained by calling getLastErrorCode() and getLastErrorString().
 */
OMMOVIE_C_API int omMovieGetTrackPropertyCount(OmMovieHandle m, int trackNum);

/**
 * Return a track property of the movie.
 * @param m Handle to OmMovie object.
 * @param trackNum The zero-based index for the track.
 * @param index The index of the property.
 * @param name A buffer to store the property name.
 * @param nameSize Size of name buffer. On output, the actual size of name will be stored in this variable.
 * @param value A buffer to store the property value.
 * @param valueSize Size of value buffer. On output, the actual size of the value will be stored in this variable.
 * @param type What type of value is stored in the value buffer.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omInvalidArgument</i>: the track or property indexes are out of range, or one of the pointer arguments was NULL.
 *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
 *   - <i>omErrBufferTooSmall</i>: either the name or value buffer is too small.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @see omMovieGetTrackPropertyByName
 * @see omMovieGetMovieProperty
 * @see omMovieGetMoviePropertyByName
 * @see OmMediaPropertyType
 */
OMMOVIE_C_API OmMovieErr omMovieGetTrackProperty(OmMovieHandle m, int trackNum, int index,
                                                 char *name, uint *nameSize,
                                                 void *value, uint *valueSize,
                                                 OmMediaPropertyType *type);

/**
 * Return a track property of the movie.
 * @param m Handle to OmMovie object.
 * @param trackNum The zero-based index for the track.
 * @param name The name of the property.
 * @param value A buffer to store the property value.
 * @param valueSize Size of value buffer. On output, the actual size of the value will be stored in this variable.
 * @param type What type of value is stored in the value buffer.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omInvalidArgument</i>: the track or property indexes are out of range, the property name was not found, or one of the pointer arguments was NULL.
 *   - <i>omErrBadState</i>: the movie cannot return this information in its current state. For example, it may be closed.
 *   - <i>omErrBufferTooSmall</i>: the value buffer is too small.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @see omMovieGetTrackProperty
 * @see omMovieGetMovieProperty
 * @see omMovieGetMoviePropertyByName
 * @see OmMediaPropertyType
 */
OMMOVIE_C_API OmMovieErr omMovieGetTrackPropertyByName(OmMovieHandle m, int trackNum,
                                                       const char* name,
                                                       void *value, uint *valueSize,
                                                       OmMediaPropertyType* type);

/**
 * Add or replace a track property of the movie.
 * @param m Handle to OmMovie object.
 * @param trackNum The zero-based index for the track.
 * @param name property name.
 * @param value property value.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omInvalidArgument</i>: the track index is out of range, or the property is incompatible with an existing property of the same name.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks This function can only be used to set properties with text values.
 * @see omMovieSetTrackPropertyAndType
 * @see omMovieSetMovieProperty
 * @see omMovieSetMoviePropertyAndType
 * @see OmMediaPropertyType
 */
OMMOVIE_C_API OmMovieErr omMovieSetTrackProperty(OmMovieHandle m, int trackNum,
                                                 const char *name, const char *value);

/**
 * Add or replace a track property of the movie.
 * @param m Handle to OmMovie object.
 * @param trackNum The zero-based index for the track.
 * @param name property name.
 * @param value property value.
 * @param valueSize length of value buffer.
 * @param type What type of value is stored in the value buffer.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omInvalidArgument</i>: the track index is out of range, or the property is incompatible with an existing property of the same name.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks This function can only be used to set properties with text values.
 * @see omMovieSetTrackPropertyAndType
 * @see omMovieSetMovieProperty
 * @see omMovieSetMoviePropertyAndType
 * @see OmMediaPropertyType
 */
OMMOVIE_C_API OmMovieErr omMovieSetTrackPropertyAndType(OmMovieHandle m, int trackNum,
                                                        const char *name, const void *value,
                                                        uint valueSize,
                                                        OmMediaPropertyType type);

/**
 * Delete a track property of the movie.
 * @param m Handle to OmMovie object.
 * @param trackNum The zero-based index for the track.
 * @param name Name of the property to delete.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omInvalidArgument</i>: the track index is out of range.
 *   - <i>omErrBadState</i>: the movie cannot be modified in its current state. For example, it may be read-only.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 */
OMMOVIE_C_API OmMovieErr omMovieDeleteTrackProperty(OmMovieHandle m, int trackNum, const char* name);

/**
 * Create a new track.
 * @param m Handle to OmMovie object.
 * @param trackInfo A reference to a OmTrackInfo structure that describes the track.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: trackInfo is NULL, or a field in the trackInfo structure is invalid.
 *   - <i>omErrBadState</i>: A track cannot be added to the movie in its current state.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks
 *   - Only movies open with omAccCreate or omAccTruncate access can create new tracks.
 *   - The omMovieCreateTrack() function cannot be mixed with omMovieAddTrack(), omMovieAddMovie() and omMovieAddEffect().
 * @see OmTrackInfo
 */
OMMOVIE_C_API OmMovieErr omMovieCreateTrack(OmMovieHandle m, struct OmTrackInfo* trackInfo);

/**
 * Create a new track.
 * @param m Handle to OmMovie object.
 * @param trackInfo A reference to a OmTrackInfo structure that describes the track.
 * @param filename A filename to use for this track when writing a referenced movie.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: trackInfo is NULL, or a field in the trackInfo structure is invalid.
 *   - <i>omErrBadState</i>: A track cannot be added to the movie in its current state.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks
 *   - Only movies open with omAccCreate or omAccTruncate access can create new tracks.
 *   - The omMovieCreateTrack() function cannot be mixed with omMovieAddTrack(), omMovieAddMovie() and omMovieAddEffect().
 *   - Only the base name portion of the filename argument is used. The path and the file
 *     extension cannot be changed.
 *   - The filename argument is ignored if the wrap mode is not omWrapDiscrete.
 */
OMMOVIE_C_API OmMovieErr omMovieCreateReferencedTrack(OmMovieHandle m, struct OmTrackInfo* trackInfo, const char* filename);

/**
 * Add a referenced media file to the movie.
 * @param m Handle to OmMovie object.
 * @param filename The pathname of the media file added to the movie.
 * @param id A pointer to an OmMediaId that will receive the id assigned to the media file.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: A referenced media file cannot be added to the movie in its current state.
 * @remarks This function can only be called for movies that were open with omAccCreate or omAccTruncate
 *   access, and with omWrapReferenced wrap mode.
 */
#ifndef SWIG
OMMOVIE_C_API OmMovieErr omMovieAddReferencedMedia(OmMovieHandle m, const char* filename, OmMediaId* id);
#else
OMMOVIE_C_API OmMovieErr omMovieAddReferencedMedia(OmMovieHandle m, const char* INPUT, OmMediaId* OUTPUT);
#endif

#if 0
/**
 * Add a referenced media file to the movie.
 * @param m Handle to OmMovie object.
 * @param filename The pathname of the media file added to the movie.
 * @return The OmMediaId assigned to the media file.
 * @remarks 
 *   - This function can only be called for movies open with omAccCreate or omAccTruncate access, and 
 *     with omWrapReferenced wrap mode.
 *   - Error information can be obtained by calling omMovieGetLastErrorCode() and omMovieGetLastErrorString().
 */
OMMOVIE_C_API OmMediaId omMovieAddReferencedMedia(OmMovieHandle m, const char* filename);
#endif

/**
 * Prepare the movie to accept precharge frames. Precharge frames may be necessary to decode the first picture
 * on non-intracoded material.
 * @param m Handle to OmMovie object.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: precharge frames cannot be added to the movie in its current state.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks 
 *   - This function is only required for non-intracoded movies that have precharge, and should be called before beginRecord().
 *   - After calling this function precharge frames can be written to the movie by calling omMovieWriteFrame().
 * @see omMovieBeginRecord
 * @see omMovieWriteFrame
 */
OMMOVIE_C_API OmMovieErr omMovieBeginPrecharge(OmMovieHandle m);

/**
 * Prepare the movie to accept frames.
 * @param m Handle to OmMovie object.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: frames cannot be added to the movie in its current state.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks 
 *   - If the movie has precharge frames, those must be added to the movie before calling this function.
 *   - After calling this function frames can be written to the movie by calling omMovieWriteFrame().
 * @see omMovieBeginPrecharge
 * @see omMovieWriteFrame
 */
OMMOVIE_C_API OmMovieErr omMovieBeginRecord(OmMovieHandle m);

/**
 * Prepare the movie to accept rollout frames.
 * Rollout frames may be necessary to play the last frame on non-intracoded material.
 * @param m Handle to OmMovie object.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrBadState</i>: rollout frames cannot be added to the movie in its current state.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @remarks 
 *   - This function is only necessary for non-intracoded movies. If used, it should be called after the last visible frame of the movie has been written.
 *   - For non intra-coded material the movie will have an implicit frame of rollout.
 *   - After calling this function rollout frames can be written to the movie by calling omMovieWriteFrame().
 *   - During recording of non-intracoded material a rollout of one frame is implied. To finalize a clip that has no rollout frames, call omMovieBeginRollout() after the last frame is written and then don't write any more frames.
 * @see omMovieBeginPrecharge
 * @see omMovieWriteFrame
 */
OMMOVIE_C_API OmMovieErr omMovieBeginRollout(OmMovieHandle m);

/**
 * Write a frame to the movie.
 * @param m Handle to OmMovie object.
 * @param trackNum The zero-based index of the track where the frame is to be written.
 * @param info A pointer to a OmFrameInfo structure that describes the frame.
 * @param data A buffer with the frame data.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: An argument is out of range or invalid, or info is NULL.
 *   - <i>omErrBadState</i>: a frame cannot be written to the movie in its current state.
 *   - <i>omErrUnknown</i>: an internal error has occurred.
 * @see OmFrameInfo
 */
OMMOVIE_C_API OmMovieErr omMovieWriteFrame(OmMovieHandle m, int trackNum, const struct OmFrameInfo* info, char* data);

/**
 * Add a track from another movie to this movie.
 * @param m Handle to OmMovie object.
 * @param sourceMovie A handle to the movie object that owns the track to add.
 * @param sourceTrackNum The zero-based index of the track in the source movie.
 * @param destTrackNum The zero-based index of the track where the new content will be added. To create a new track, enter -1 for this value. 
 * @param destFrameNum The start position within the track where the new content will be added. To align the new content with the beginning of the movie, enter -1 for this value.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> or sourceMovie is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: An argument is out of range or invalid.
 *   - <i>omErrBadState</i>: A track cannot be added to this movie in its current state.
 *   - <i>omErrUnknown</i>: An internal error has occurred.
 */
OMMOVIE_C_API OmMovieErr omMovieAddTrack(OmMovieHandle m, const OmMovieHandle sourceMovie, int sourceTrackNum, int destTrackNum, int destFrameNum);

/**
 * Add all tracks from another movie to this movie.
 * @param m Handle to OmMovie object.
 * @param sourceMovie A handle to the movie object that owns the track to add.
 * @param destTrackNum The zero-based index of the destination track where the first track of the source movie will be added. The remaining source tracks will be added to the 
 *   movie in the tracks that follow immediately after this one. To add the tracks of the source movie as new tracks, enter -1 for this value. 
 * @param destFrameNum The start position within the track where the new content will be added. To align the new content with the beginning of the movie, enter -1 for this value.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> or sourceMovie is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: An argument is out of range or invalid, or the source and destination tracks do not match.
 *   - <i>omErrBadState</i>: A source movie cannot be added to this movie in its current state.
 *   - <i>omErrUnknown</i>: An internal error has occurred.
 * @remarks 
 *   - The source tracks will be inserted in the order in which they are defined in the source movie.
 *   - The movie on disk will not be immediately updated when omMovieAddMovie() is called. To update the movie call omMovieSave() after all the modifications have been done.
 *     To leave the original movie unmodified and write a new movie with the changes use omMovieSaveCopy().
 * @see omMovieSave
 * @see omMovieSaveCopy
 */
OMMOVIE_C_API OmMovieErr omMovieAddMovie(OmMovieHandle m, const OmMovieHandle sourceMovie, int destTrackNum, int destFrameNum);

/**
 * Add a filter to a track of the movie.
 * @param m Handle to OmMovie object.
 * @param destTrackNum The zero-based index of the track where the filter will be added. 
 * @param destFrameNum The start position of the filter.
 * @param numFrames The duration of the filter.
 * @param name The name of the filter.
 * @param arguments A string with a comma-separated list of key/value pairs that configure the filter.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: An argument is out of range or invalid.
 *   - <i>omErrBadState</i>: A source movie cannot be added to this movie in its current state.
 *   - <i>omErrUnknown</i>: An internal error has occurred.
 * @remarks
 *   - Currently available filters are "xfade" and "vfade" for audio tracks.
 *   - None of the available filters require arguments at this time, but arguments will be used in the future.
 */
OMMOVIE_C_API OmMovieErr omMovieAddFilter(OmMovieHandle m, int destTrackNum, int destFrameNum, int numFrames, const char* name, const char* arguments);

/**
 * Add a filter to all the tracks of the movie that match the given essence type.
 * @param m Handle to OmMovie object.
 * @param trackEssenceType The track type. 
 * @param destFrameNum The start position of the filter.
 * @param numFrames The duration of the filter.
 * @param name The name of the filter.
 * @param arguments A string with a comma separated list of key/value pairs that configure the filter.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: An argument is out of range or invalid.
 *   - <i>omErrBadState</i>: A source movie cannot be added to this movie in its current state.
 *   - <i>omErrUnknown</i>: An internal error has occurred.
 * @remarks
 *   - Currently available filters are "xfade" and "vfade" for audio tracks.
 *   - None of the available filters require arguments at this time, but arguments will be used in the future.
 */
OMMOVIE_C_API OmMovieErr omMovieAddFilters(OmMovieHandle m, enum OmMediaType trackEssenceType, int destFrameNum, int numFrames, const char* name, const char* arguments);

/**
 * Remove a track from this movie.
 * @param m Handle to OmMovie object.
 * @param trackNum The zero-based index of the track to remove.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: An argument is out of range or invalid.
 *   - <i>omErrBadState</i>: A source movie cannot be added to this movie in its current state.
 *   - <i>omErrUnknown</i>: An internal error has occurred.
 * @remarks
 *  - The movie on disk will not be immediately updated when removeTrack is called. To update the movie, call omMovieSave() after all the modifications have been done.
 *  - To leave the original movie unmodified and write a new movie with the changes, use omMovieSaveCopy().
 * @see omMovieSave
 * @see omMovieSaveCopy
 */
OMMOVIE_C_API OmMovieErr omMovieRemoveTrack(OmMovieHandle m, int trackNum);

/**
 * Discard frames from the beginning and/or the end of the movie.
 * @param m Handle to OmMovie object.
 * @param startFrameNum The first frame of the range of frames to keep.
 * @param numFrames The number of frames to keep.
 * @return Error code
 *   - <i>omErrOk</i>: the operation was successful.
 *   - <i>omErrInvalidMovieHandle</i>: <i>m</i> is not a valid OmMovie object handle.
 *   - <i>omErrInvalidArgument</i>: An argument is out of range or invalid.
 *   - <i>omErrBadState</i>: A source movie cannot be added to this movie in its current state.
 *   - <i>omErrUnknown</i>: An internal error has occurred.
 * @remarks 
 *  - The movie on disk will not be immediately updated when subClip is called. To update the movie call omMovieSave() after all the modifications have been done.
 *  - To leave the original movie unmodified and write a new movie with the changes use omMovieSaveCopy().
 * @see omMovieSave
 * @see omMovieSaveCopy
 */
OMMOVIE_C_API OmMovieErr omMovieSubClip(OmMovieHandle m, int startFrameNum, int numFrames);

#endif

/**********************************************************************
Filename:    ommedia.h

Description: Defines the Omneon Media API

Copyright (c) 1998-2007 Omneon Video Networks (TM)

OMNEON VIDEO NETWORKS CONFIDENTIAL
************************************************************************/

/** 
 * @file ommedia.h
 * Definition of the OmMediaCopier and OmMediaQuery classes.
 */

#ifndef _OMMEDIA_H_
#define _OMMEDIA_H_

#  ifdef _MSC_VER
#    ifdef OMMEDIA_EXPORTS
       // defined for developers of this DLL
#      define OMMEDIA_CPP_API __declspec(dllexport)
#      define OMMEDIA_C_API extern "C" __declspec(dllexport)
#    else
       // defined for DLL users
#      define OMMEDIA_CPP_API __declspec(dllimport)
#      define OMMEDIA_C_API extern "C" __declspec(dllimport)
#    endif
#  else
#    define OMMEDIA_CPP_API
#    define OMMEDIA_C_API extern "C"
#  endif

#include <ommediadefs.h>

// Version of the API in use.  This is passed as a default argument whenever a
// OmMediaCopier or OmMediaQuery object is created to indicate what API version
// the client has been compiled for.
enum MediaAPIVersion {
    mediaAPIVersion1 = 1,
    mediaAPIVersion2 = 2,
    currentMediaAPIVersion = 2
};

// Type of copy operation.
enum OmMediaCopyType {
    omFlattenedWithDiscreteMedia,   // all media copied to new, discrete files
    omFlattenedWithEmbeddedMedia,   // all media copied into the destination movie file
    omReferenceCopy                 // no media copied, new movie file created
};

// Type of clip data.
enum OmMediaClipDataType {
    omClipDataUnknown,

    // 2 bytes of closed caption from field 1
    // This format is only used with interlace clips.
    // See the comments below for omPlrClipDataCcFrame with the difference
    // that only field 1 data is extracted/inserted.
    omClipDataCcField1,

    // 2 bytes of closed caption from field 2
    // This format is only used with interlace clips.
    // See the comments below for omPlrClipDataCcFrame with the difference
    // that only field 2 data is extracted/inserted.
    omClipDataCcField2,

    // 4 bytes of closed caption, 2 from field 1 followed by 2 from field 2
    // When this is used with progressive clips either the two bytes of field 1
    // data or the two bytes of field 2 data should be 0xff,0xff or 0xfc,0xfc.
    // These special values which are normally invalid CC byte values because
    // the parity bit is incorrect are used to indicate "no data". For
    // extraction they mean no data was found. For insertion they mean do not
    // insert or insert invalid data as described below. (The two forms of
    // "no data" indication are needed to support proper insertion into
    // progressive clips.)
    // 
    // (See ATSC A/53 and CEA-708)
    // The following rules are used when extracting CC from MPEG user data.
    // 1. The four return bytes are initialized to 0xff 0xff 0xff 0xff
    // 2. The cc data triples (cc_type, cc_data_1, cc_data_2) are walked
    //    in order and each NTSC triple is processed. Walking stops when a
    //    DTVCC type triple is found.
    // 3. Each NTSC triple is processed as follows:
    //    a. Field 1 marked as invalid (cc_type is 0xf8) converts the first two
    //       returned bytes from 0xff to 0xfc. Do nothing if the first two
    //       return bytes are not 0xff.
    //    b. Field 1 marked as valid (0xfc) stuffs the cc_data_1 and cc_data2
    //       bytes into the first two return bytes
    //    c. Field 2 marked as invalid (0xf9) converts the second two returned
    //       bytes from 0xff to 0xfc. Do nothing if the second two return bytes
    //       are not 0xff.
    //    d. Field 2 marked as valid (0xfd) stuffs the cc_data_1 and cc_data2
    //       bytes into the second two return bytes
    //
    // The following rules are used when inserting CC into MPEG user data.
    // 1. Remove the NTSC cc data triples by walking the cc data triples
    //    converting NTSC triples to DTVCC channel packet data marked as
    //    invalid (cc_type is 0xfa). Stop walking when a DTVCC triple is
    //    found. Return failure if cannot convert one triple for progressive
    //    clips or two triples for interlace clips.
    // 2. Convert the first triple for progressive clips to NTSC cc data
    //    triples using the following rule.
    //    a. If the first two of the supplied four bytes are not 0xff,0xff or
    //       0xfc,0xfc then insert the two bytes as Field 1 data (0xfc)
    //       Else if the second two of the supplied four bytes are not
    //       0xff,0xff or 0xfc,0xfc then insert the two bytes as Field 2
    //       data (0xfd)
    //       Else if the first two of the supplied four bytes are 0xfc,0xfc
    //       then insert Field 1 data marked as invalid (0xf8).
    //       Else if the second two of the supplied four bytes are 0xfc then
    //       insert Field 2 data marked as invalid (0xf9).
    //       Else insert Field 1 data marked as invalid (0xf8).
    // 2. Convert the first two triples for interlace clips to NTSC cc data
    //    triples using the following rules.
    //    a. If the first two of the supplied four bytes are not 0xff,0xff or
    //       0xfc,0xfc then insert the two bytes as Field 1 data (0xfc) into
    //       the first triple
    //       Else insert Field 1 data marked as invalid (0xf8) into the first
    //       triple.
    //    b. If the second two of the supplied four bytes are not 0xff,0xff or
    //       0xfc,0xfc then insert the two bytes as Field 2 data (0xfd) into
    //       the second triple.
    //       Else insert Field 2 data marked as invalid (0xf9) into the second
    //       triple.
    omClipDataCcFrame,

    // 4 bytes of timecode (8 TC nibbles of OmTcData)
    // This is per frame timecode embedded in the video essence.
    // See the comments for type omPlrClipDataClipFileOmTcData.
    omClipDataTimecode,

    // 4 bytes of userbits (8 UB nibbles of OmTcData)
    // This is per frame timecode embedded in the video essence.
    // See the comments for type omPlrClipDataClipFileOmTcData.
    omClipDataUserbits,

    // 4 bytes of timecode followed by 4 bytes userbits
    // This is per frame timecode embedded in the video essence.
    // See the comments for type omPlrClipDataClipFileOmTcData.
    omClipDataTimeUser,

    // 8 bytes in OmTcData format
    // This is per frame timecode embedded in the video essence.
    // See the comments for type omPlrClipDataClipFileOmTcData.
    omClipDataOmTcData,

    // VBI data stored in .vbi file or Omneon user data in mpeg video
    // OmPlrRawVbiHeader followed by 1440 bytes per line.
    omClipDataRawVbi,

    // VBI data stored in a SMPTE436 VBI track
    omClipData436Vbi,

    // SMPTE291 VANC stored in a SMPTE436 VANC track.
    omClipData436Vanc,

    // SMPTE291 VANC stored in the video track such as specified in
    // SMPTE328 or SMPTE375
    omClipDataVideoEmbVanc,

    // CEA-708 closed caption data stored in mpeg user data.
    // The data is formatted as a subset of the ccdata_section in table 5 of
    // SMPTE 334-2-2007. Specifically it is the cc_count value followed by
    // cc_count groups of three bytes. So each frame consists of a byte
    // followed by N more bytes where N is the first byte times 3.
    omClipDataCcA53,

    // Video index data as described in RP186-2008. The data is formatted in
    // the data buffer as a byte array per frame. The byte array starts with
    // a single byte that specifies the number of following bytes followed by
    // that many bytes of the RP186 payload. For instance if a clip contains
    // only class 1.1 of the RP186 data then a read of 2 frames from this clip
    // may respond with the following bytes:
    // 0x03 0x41 0x00 0x00 0x03 0x41 0x00 0x00
    omClipDataViRp186,

    // 8 bytes in OmTcData format
    // This is per frame timecode stored in the clip file (not in the video
    // essence). Note: If both wrapper timecode and essence timecode are present, the
    // MediaDirector will use the essence timecode.
    omClipDataClipFileOmTcData,

    // 8 bytes in OmTcData format
    // This is per frame timecode stored in the video essence (not the movie wrapper). Reads and writes
    // of this data type will not use the timecode stored in the clip file.
    // Note: If both wrapper timecode and essence timecode are present, the
    // MediaDirector will use the essence timecode.
    omClipDataVideoEssenceOmTcData,
};

// In the C-world, this is really an instance of an OmMediaCopier.
struct OmMediaCopierRec;
typedef struct OmMediaCopierRec* OmMediaCopierHandle;

// In the C-world, this is really an instance of an OmMediaQuery.
struct OmMediaQueryRec;
typedef struct OmMediaQueryRec* OmMediaQueryHandle;

// An OmMediaId is an opaque type that describes a media file
#if defined(_LP64) || defined(_M_X64)
typedef uint_64 OmMediaId;
#elif defined(_MSC_VER) && _MSC_VER < 1300
// Legacy VC6 compatible definition
struct OmMedaIdRec;
typedef struct OmMedaIdRec* OmMediaId;
#else
typedef uint OmMediaId;
#endif

struct OmMediaInfo {
    uint        firstFrame;     // 1st recorded frame (may be non-zero)
    uint        lastFrame;      // last recorded frame
    uint        defaultIn;      // default in (inclusive, 1st frame to play)
    uint        defaultOut;     // default out (excl., 1st frame *not* played)
    uint        numTracks;      // # of video and audio tracks
    uint        numMedia;       // # of media files referenced by movie
    uint        numPrecharge;   // # of precharge frames before the first frame
    enum OmFrameRate frameRate; // clip frame rate
    const char* clipProperties; // comma-delimited list of properties
};

enum { maxMediaChunks = 2 };
struct OmMediaChunk {
    uint nBytes;        // number of bytes in the sample
    uint_64 offset;     // file offset for the sample
};

struct OmMediaSample {
    int frameNum;       // frame number of the sample; may be negative
    OmMediaId id;       // media ID for the file containing the sample
    uint nChunks;       // number of chunks below
    struct OmMediaChunk chunk[maxMediaChunks];
};

// The status of an ongoing copy operation.
struct OmCopyProgress {
    uint nTotalFrames;      // equal to (out-in)*nTracks
    uint nComplete;         // frames completed out of total copy
};

// Property value type
typedef enum {
    OmMediaPropertyString,   // property is text
    OmMediaPropertyPrivate,  // property is a user-defined private structure
    OmMediaPropertyUint8,    // property is uint8
    OmMediaPropertyUint16,   // property is uint16
    OmMediaPropertyUint32,   // property is uint32
    OmMediaPropertyUint64,   // property is uint64
    OmMediaPropertyInt8,     // property is int8
    OmMediaPropertyInt16,    // property is int16
    OmMediaPropertyInt32,    // property is int32
    OmMediaPropertyInt64,    // property is int64
    OmMediaPropertyFloat32,  // property is a 32 bit float
    OmMediaPropertyFloat64,  // property is a 64 bit float
    OmMediaPropertyBinary,   // property is non-specific binary
} OmMediaPropertyType;

#ifdef WIN32
# ifndef _WCHAR_T_DEFINED
typedef unsigned short wchar_t;
#  define _WCHAR_T_DEFINED
# endif
#endif

#ifdef __cplusplus

/////////////////////////////////////////////////////////////////////////////
//
// C++ interfaces
//
/////////////////////////////////////////////////////////////////////////////

// forward declaration for a structures defined internally
struct OmMediaQueryImpl;
struct OmMediaPropertyListImpl;
class OmMediaCopierImpl;

/**
 * Omneon software version information.
 */
struct OMMEDIA_CPP_API OmSwVersion {
    unsigned char m_major;
    unsigned char m_minor;
    unsigned char m_service;
    unsigned char m_hotfix;

    enum Scalar { scalar };

    /**
     * Construct an empty version object.
     */
    OmSwVersion()
      : m_major  (0xff),
        m_minor  (0xff),
        m_service(0xff),
        m_hotfix (0xff)
    {}

    OmSwVersion(unsigned int v, Scalar)
      : m_major  ((unsigned char)((v >> 24) & 0xff)),
        m_minor  ((unsigned char)((v >> 16) & 0xff)),
        m_service((unsigned char)((v >>  8) & 0xff)),
        m_hotfix ((unsigned char)((v >>  0) & 0xff))
    {}

    OmSwVersion(uint major_,
                uint minor_,
                uint release_ = 0,
                uint hotfix_ = 0)
      : m_major(major_),
        m_minor(minor_),
        m_service(release_),
        m_hotfix(hotfix_)
    {}

    /**
     * Return a version number encoded as a single integer.
     * @return An 32-bit integer that encodes the four components of a version number.
     * @remarks The major, minor, service and hotfix numbers each use 8-bits. The 
     *   8 most significant bits are the major number, followed by minor, service and
     *   hotfix.
     */
    unsigned int getScalar() const
    {
        return (m_major   << 24)
             | (m_minor   << 16)
             | (m_service <<  8)
             | (m_hotfix  <<  0);
    }

    /**
     * Return the major version number.
     * @return An integer that represents the major version number.
     */
    uint getMajor() const   { return m_major; }
    /**
     * Return the minor version number.
     * @return An integer that represents the minor version number.
     */
    uint getMinor() const   { return m_minor; }
    /**
     * Return the service version number.
     * @return An integer that represents the service version number.
     */
    uint getService() const { return m_service; }
    /**
     * Return the hotfix version number.
     * @return An integer that represents the hotfix version number.
     */
    uint getHotfix() const  { return m_hotfix; }
    /**
     * Check if the version number stored in this object is valid.
     * @return <i>true</i> if the version is valid, <i>false</i> otherwise.
     * @remarks This is the inverse of isNotValid()
     * @see isNotValid
     */
    bool isValid() const    { return getScalar() != 0xffffffff; }
    /**
     * Check if the version number stored in this object is invalid.
     * @return <i>true</i> if the version is invalid, <i>false</i> otherwise.
     * @remarks This is the inverse of isValid()
     * @see isValid
     */
    bool isNotValid() const { return ! isValid(); }
    /**
     * Equality operator between version numbers.
     * @param rhs A reference to version object to be compared against this object.
     * @return <i>true</i> if this object is equal to rhs, <i>false</i> otherwise.
     */
    bool operator==(const OmSwVersion& rhs) const { return getScalar() == rhs.getScalar(); }
    /**
     * Inequality operator between version numbers.
     * @param rhs A reference to version object to be compared against this object.
     * @return <i>true</i> if this object is different than rhs, <i>false</i> if they are equal.
     */
    bool operator!=(const OmSwVersion& rhs) const { return getScalar() != rhs.getScalar(); }
    /**
     * Less than or equal operator between version numbers.
     * @param rhs A reference to version object to be compared against this object.
     * @return <i>true</i> if this object represents an older or equal version than rhs, <i>false</i> otherwise.
     */
    bool operator<=(const OmSwVersion& rhs) const { return getScalar() <= rhs.getScalar(); }
    /**
     * Less than operator between version numbers.
     * @param rhs A reference to version object to be compared against this object.
     * @return <i>true</i> if this object represents an older version than rhs, <i>false</i> otherwise.
     */
    bool operator< (const OmSwVersion& rhs) const { return getScalar() <  rhs.getScalar(); }
    /**
     * Greater than or equal operator between version numbers.
     * @param rhs A reference to version object to be compared against this object.
     * @return <i>true</i> if this object represents a newer or equal version than rhs, <i>false</i> otherwise.
     */
    bool operator>=(const OmSwVersion& rhs) const { return getScalar() >= rhs.getScalar(); }
    /**
     * Greater than operator between version numbers.
     * @param rhs A reference to version object to be compared against this object.
     * @return <i>true</i> if this object represents a newer version than rhs, <i>false</i> otherwise.
     */
    bool operator> (const OmSwVersion& rhs) const { return getScalar() >  rhs.getScalar(); }
};

/////////////////////////////////////////////////////////////////////////////
// OmMediaProperty represents a single movie property
/////////////////////////////////////////////////////////////////////////////
class OMMEDIA_CPP_API OmMediaProperty {
private:
    char*               m_name;         // property name
    char*               m_value;        // storage for this follows m_name
    uint                m_valueLen;     // length of property value, in bytes
    OmMediaPropertyType m_valueType;    // type of the value (string, binary, integer, etc.)

public:
    OmMediaProperty()
        : m_name(0),  m_value(0), m_valueLen(0), m_valueType(OmMediaPropertyString)
        {}
    OmMediaProperty(const char* name, const void* value, uint valueLen,
        OmMediaPropertyType type)
        : m_name(0),  m_value(0), m_valueLen(0), m_valueType(type)
        { set(name, value, valueLen, type); }
    OmMediaProperty(const char* name, const char* value)
        : m_name(0),  m_value(0), m_valueLen(0), m_valueType(OmMediaPropertyString)
        { set(name, value); }
    OmMediaProperty(const char* name, unsigned char value)
        : m_name(0),  m_value(0), m_valueLen(0), m_valueType(OmMediaPropertyString)
        { setUint8(name, value); }
    OmMediaProperty(const char* name, unsigned short value)
        : m_name(0),  m_value(0), m_valueLen(0), m_valueType(OmMediaPropertyString)
        { setUint16(name, value); }
    OmMediaProperty(const char* name, unsigned int value)
        : m_name(0),  m_value(0), m_valueLen(0), m_valueType(OmMediaPropertyString)
        { setUint32(name, value); }
    OmMediaProperty(const char* name, uint_64 value)
        : m_name(0),  m_value(0), m_valueLen(0), m_valueType(OmMediaPropertyString)
        { setUint64(name, value); }
    OmMediaProperty(const char* name, char value)
        : m_name(0),  m_value(0), m_valueLen(0), m_valueType(OmMediaPropertyString)
        { setInt8(name, value); }
    OmMediaProperty(const char* name, short value)
        : m_name(0),  m_value(0), m_valueLen(0), m_valueType(OmMediaPropertyString)
        { setInt16(name, value); }
    OmMediaProperty(const char* name, int value)
        : m_name(0),  m_value(0), m_valueLen(0), m_valueType(OmMediaPropertyString)
        { setInt32(name, value); }
    OmMediaProperty(const char* name, int_64 value)
        : m_name(0),  m_value(0), m_valueLen(0), m_valueType(OmMediaPropertyString)
        { setInt64(name, value); }
    OmMediaProperty(const char* name, float value)
        : m_name(0),  m_value(0), m_valueLen(0), m_valueType(OmMediaPropertyString)
        { setFloat32(name, value); }
    OmMediaProperty(const char* name, double value)
        : m_name(0),  m_value(0), m_valueLen(0), m_valueType(OmMediaPropertyString)
        { setFloat64(name, value); }
    OmMediaProperty(const char* name, const char* value, uint valueLen)
        : m_name(0),  m_value(0), m_valueLen(0), m_valueType(OmMediaPropertyString)
        { setBinary(name, value, valueLen); }
    OmMediaProperty(const OmMediaProperty& rhs)
        : m_name(0),  m_value(0), m_valueLen(0), m_valueType(rhs.m_valueType)
        { set(rhs.m_name, rhs.m_value, rhs.m_valueLen, rhs.m_valueType);}
    ~OmMediaProperty()
        { delete m_name; /* don't delete m_value*/ }
    OmMediaProperty& operator=(const OmMediaProperty& rhs)
        { set(rhs.m_name, rhs.m_value, rhs.m_valueLen, rhs.m_valueType); return *this; }

    const char* getValue() const
        { return m_value; }
    const uint getValueLength() const
        { return m_valueLen; }
    const OmMediaPropertyType getType() const
        { return m_valueType; }

    const char* getName() const
        { return m_name; }

    const char* getString() const
        { if (m_valueType != OmMediaPropertyString) return 0; return m_value; }
    bool getUint8(unsigned char& OUTPUT) const
        { OUTPUT = *(unsigned char*)m_value; return (m_valueType == OmMediaPropertyUint8); }
    bool getUint16(unsigned short& OUTPUT) const
        { OUTPUT = *(unsigned short*)m_value; return (m_valueType == OmMediaPropertyUint16); }
    bool getUint32(unsigned int& OUTPUT) const
        { OUTPUT = *(unsigned int*)m_value; return (m_valueType == OmMediaPropertyUint32); }
    #ifndef SWIG
    bool getUint64(uint_64& OUTPUT) const
    #else
    #ifndef _LP64
    bool getUint64(unsigned long long& OUTPUT) const
    #else
    bool getUint64(unsigned long& OUTPUT) const
    #endif
    #endif
        { OUTPUT = *(uint_64*)m_value; return (m_valueType == OmMediaPropertyUint64); }
    bool getInt8(char& OUTPUT) const
        { OUTPUT = *(char*)m_value; return (m_valueType == OmMediaPropertyInt8); }
    bool getInt16(short& OUTPUT) const
        { OUTPUT = *(short*)m_value; return (m_valueType == OmMediaPropertyInt16); }
    bool getInt32(int& OUTPUT) const
        { OUTPUT = *(int*)m_value; return (m_valueType == OmMediaPropertyInt32); }
    #ifndef SWIG
    bool getInt64(int_64& OUTPUT) const
    #else
    #ifndef _LP64
    bool getInt64(long long& OUTPUT) const
    #else
    bool getInt64(long& OUTPUT) const
    #endif
    #endif
        { OUTPUT = *(int_64*)m_value; return (m_valueType == OmMediaPropertyInt64); }
    bool getFloat32(float& OUTPUT) const
        { OUTPUT = *(float*)m_value; return (m_valueType == OmMediaPropertyFloat32); }
    bool getFloat64(double& OUTPUT) const
        { OUTPUT = *(double*)m_value; return (m_valueType == OmMediaPropertyFloat64); }
    const char* getBinary() const
        { if (m_valueType != OmMediaPropertyBinary) return 0; return m_value; }

    void set(const char* name, const void* value, uint valueLen,
             OmMediaPropertyType type);
    void set(const char* name, const char* value);

    void setString(const char* name, const char* value)
        { set(name, value); }
    void setUint8(const char* name, unsigned char value)
        { set(name, &value, sizeof(value), OmMediaPropertyUint8); }
    void setUint16(const char* name, unsigned short value)
        { set(name, &value, sizeof(value), OmMediaPropertyUint16); }
    void setUint32(const char* name, unsigned int value)
        { set(name, &value, sizeof(value), OmMediaPropertyUint32); }
    void setUint64(const char* name, uint_64 value)
        { set(name, &value, sizeof(value), OmMediaPropertyUint64); }
    void setInt8(const char* name, char value)
        { set(name, &value, sizeof(value), OmMediaPropertyInt8); }
    void setInt16(const char* name, short value)
        { set(name, &value, sizeof(value), OmMediaPropertyInt16); }
    void setInt32(const char* name, int value)
        { set(name, &value, sizeof(value), OmMediaPropertyInt32); }
    void setInt64(const char* name, int_64 value)
        { set(name, &value, sizeof(value), OmMediaPropertyInt64); }
    void setFloat32(const char* name, float value)
        { set(name, &value, sizeof(value), OmMediaPropertyFloat32); }
    void setFloat64(const char* name, double value)
        { set(name, &value, sizeof(value), OmMediaPropertyFloat64); }
    void setBinary(const char* name, const char* value, uint valueLen)
        { set(name, value, valueLen, OmMediaPropertyBinary); }
};

/////////////////////////////////////////////////////////////////////////////
// OmMediaProperty represents an indexed list of movie property
/////////////////////////////////////////////////////////////////////////////
class OMMEDIA_CPP_API OmMediaPropertyList {
private:
    friend class OmMediaQuery;
    friend class OmMediaCopier;
    struct OmMediaPropertyListImpl& m;

public:
    OmMediaPropertyList();
    ~OmMediaPropertyList();

    // Returns the current count of properties
    uint getPropertyCount() const;

    // Returns the indexed property
    const OmMediaProperty* get(uint index) const;

    // Returns the property having the specified name
    const OmMediaProperty* get(const char*) const;

    // Sets the specified property. Returns false if the name or value is NULL.
    // Note that this only sets the property in an instance of this class.
    // It does not affect a movie referenced by a OmMediaQuery instance --
    // to do that you must use OmMediaQuery::setProperty().
    bool set(const OmMediaProperty&);

private:
    // copy constructor and assignment operator are not defined
    OmMediaPropertyList(const OmMediaPropertyList&);
    OmMediaPropertyList& operator=(const OmMediaPropertyList&);
};

/////////////////////////////////////////////////////////////////////////////
// OmMediaCopier accepts media files and can produce a movie container
/////////////////////////////////////////////////////////////////////////////
class OMMEDIA_CPP_API OmMediaCopier {
public:
    OmMediaCopier();
    OmMediaCopier(MediaAPIVersion version);
    ~OmMediaCopier();

    // Turn debug logging on or off.  If fname is specified, debugging will
    // be logged to the file, overwriting any previous content.  If fname
    // is NULL or "", debug logging is turned off.  Note: this function logs
    // ALL ommedia.dll function calls, not just those of OmMediaCopier.
    static bool setDebug(const char *fname);

    // Set system-specific debug variables
    static bool setDebug(const char *debugvar, const char *debugbit);
    static bool setDebug(const char *debugvar, uint value);

    // Set this copy to be handled by a remote media server
    bool setRemoteHost(const char *host);

    // Initialize the remote media server. This causes any ongoing transfers
    // on that server to abort immediately. This may be useful in cases
    // where the client application crashed or exited unexpectedly leaving
    // one or more orphaned transfer tasks running on the remote server.
    // The application can call this function after it is restarted to
    // ensure that the host goes back to a clean state.
    // A limitation of this function is that in a situation where there are
    // several clients sending transfers to the same host all transfers will
    // be aborted, even those that were started by a different client.
    // Returns true if the remote host was initialized, false if the host
    // could not be contacted or could not be initialized.
    bool initializeRemoteHost();

    // Add a single source track from the specified path to the media file.
    // Returns true on success, false if the media file is not understood.
    bool addSourceTrack(const char* mediaPath, uint track);
    bool addSourceTrack(const wchar_t* mediaPath, uint track);

    // Add all source tracks found in the specified path to the media file;
    // Returns true on success, false if the media file is not understood.
    bool addSourceTracks(const char* mediaPath);
    bool addSourceTracks(const wchar_t* mediaPath);

    // Add a single source track from the specified path to the end of a track
    // in the media file. Optionally, a range of frames to copy may be given.
    // Returns true on success, false if the media file is not understood.
    bool appendTrack(uint dstTrack, uint srcTrack, const char* mediaPath,
                     uint inSrcFrame=0, uint outSrcFrame=~0);
    bool appendTrack(uint dstTrack, uint srcTrack, const wchar_t* mediaPath,
                     uint inSrcFrame=0, uint outSrcFrame=~0);

    // Add all source tracks from the specified path to the media file starting
    // at track 'dstTrack'. Optionally, a range of frames to copy may be given.
    // Returns true on success, false if the media file is not understood.
    bool appendTracks(uint dstTrack, const char* mediaPath,
                      uint inSrcFrame=0, uint outSrcFrame=~0);
    bool appendTracks(uint dstTrack, const wchar_t* mediaPath,
                      uint inSrcFrame=0, uint outSrcFrame=~0);

    // Specify the destination movie file; the suffix implies the movie type;
    // i.e., .mov implies a Quicktime movie.
    bool setDestination(const char* moviePath, bool replace = false);
    bool setDestination(const wchar_t* moviePath, bool replace = false);

    // Specify a format for the destination movie
    // use "qt7" for newer Apple compatible MPEG format
    // use "qt6" for Omneon's legacy MPEG QT wrapper
    // If this function is not called a format will be chosen automatically
    // based on the format of the input movie(s) and the global default
    // chosen with the OmQtChooser utility.
    void setClipProperties(const char *clipProperties);

    // Specify type type of copy to be performed;
    // the default is omFlattenedWithDiscreteMedia.
    void setCopyType(OmMediaCopyType = omFlattenedWithDiscreteMedia);

    // Set the copy range on the source(s); this implies the destination
    // will be outFrame-inFrame frames in length. Returns false if
    // outFrame <= inFrame; If outFrame is ~0, it is shorthand for the
    // end of the input. Also, if outFrame is beyond the end of the
    // input (and not ~0) and force==false, the function returns false.
    // Note that the OmMediaCopier's frame numbers are always zero-based.
    bool setRange(uint inFrame, uint outFrame);

    // Set the copy range on the specified track. Track numbers begin at
    // zero and increase with each call to addSourceTracks(). If you are
    // unsure about the track numbers you can use getDstInfo() and
    // getDstTrackInfo() to clarify. This method can be used to specify
    // a shift  in a track relative to other tracks, or to select a subset
    // of a source track for inclusion in the destination. For example, a
    // call of setTrackRange(2,5,~0) will extract frame 5 through the end
    // of track 2; a call of setTrackRange(2, -20, 10) will extract frame
    // 0 through frame 9 from the source and place it at frame 20 through
    // 29 in the destination.
    bool setTrackRange(uint track, uint inFrame, uint outFrame);

    // Specify that, independent of any specified outFrame, the copy will
    // terminate on the last frame of video.  This is a simple way of making
    // sure a too-long audio track doesn't make the final movie too long.
    // By default, the value is false.
    void setTrimmedAudio(bool = true);

    // Set the default video rate to be used... for audio-only files and dnxhd.
    void setDefaultFrameRate(OmFrameRate vrate);

    // change the file name suffix for individual media files created as
    // as part of the copy() processing. Provide the suffix without the dot,
    // for example, "m2v".
    bool setOutputSuffix(OmMediaFileType, const char* suffix);
    bool setOutputSuffix(OmMediaFileType, const wchar_t* suffix);

    // Get the current output suffix for the specified type
    const char* getOutputSuffix(OmMediaFileType) const;
    const wchar_t* getOutputSuffixW(OmMediaFileType) const;

    // Get the type for specified suffix. Returns omMediaUnknown if the
    // suffix is not currently recognized
    static OmMediaFileType getOutputType(const char* suffix);
    static OmMediaFileType getOutputType(const wchar_t* suffix);

    // Obtain the summary information for the destination movie. This
    // changes as source tracks are added and parameters are changed.
    bool getDstInfo(OmMediaInfo&);

    // Obtain information about the specified destination track.
    bool getDstTrackInfo(uint trackNum, OmMediaSummary&);
    bool getDstTrackInfo1(uint trackNum, OmMediaSummary1&);

    // Set the number of seconds a movie that is recording needs to be watched
    // for changes before assuming the recording ended. The default for this
    // value is 20 seconds.
    bool setMaxRecordAge(uint seconds);

    // Perform the copy, creating the new output movie, and possibly new media
    // files as specified by the copy type. This does not return until the
    // copy is complete or cancel() is called (by another thread).
    bool copy();

    // Get the copy progress.  This can be called while the copy is in progress
    // from another thread.  Note that it may not count linearly from
    // one frame to the next because some tracks may be omitted if, for
    // example, the media contains embedded audio.
    OmCopyProgress getProgress();
    void getProgress(OmCopyProgress* progress);

    // Since only the DLL can create an OmMediaCopierRec, this is safe, except
    // from the truly twisted.
    static OmMediaCopier* castFrom(OmMediaCopierHandle p)
        { return (OmMediaCopier*)p; }

    // If you plan on holding on to the OmMediaCopier instance, then you
    // should call release() when you are done to free up the resources
    // and close open files.
    void release();

    // If a call to copy() is in progress, a call to cancel() by some other
    // thread will cause the copy to end at the next frame. The movie at that
    // point will be mostly coherent, although the length of the tracks may
    // differ by one frame.
    void cancel();

private:
    OmMediaCopier(const OmMediaCopier&);    // prevent copy constructor
    OmMediaCopier& operator=(const OmMediaCopier&); // prevent assignment
    class OmMediaCopierImpl& m;
};

// Extended version of OmMediaCopier
class OMMEDIA_CPP_API OmMediaCopierEx : public OmMediaCopier {
public:
    OmMediaCopierEx(MediaAPIVersion version = currentMediaAPIVersion);
};

#ifndef OMMEDIA_EXPORTS
#define OmMediaCopier OmMediaCopierEx
#endif

/////////////////////////////////////////////////////////////////////////////
// OmMediaQuery opens both media and container movies and allows queries
// on various properties.
/////////////////////////////////////////////////////////////////////////////
class OMMEDIA_CPP_API OmMediaQuery {
public:
    // constructor
    OmMediaQuery();
    OmMediaQuery(MediaAPIVersion version);

    // destructor; frees internal resources used
    ~OmMediaQuery();

    // Open the specified media or movie path. Returns true on success; false
    // if the file is corrupt, missing, or unrecognized. Any previously held
    // movie files are closed and released. Writable must be specified as
    // true to use set methods.
    bool setFile(const char* mediaPath, bool writable = false);
    bool setFile(const wchar_t* mediaPath, bool writable = false);

    // Get movie information. Always returns true unless setFile()
    // was unsuccessful.
    bool getMovieInfo(OmMediaInfo&) const;

    // Get summary information for specified track. Returns true on success;
    // false if the track number is greater than OmMediaInfo::numTracks.
    bool getTrackInfo(uint trackNum, OmMediaSummary&) const;
    bool getTrackInfo1(uint trackNum, OmMediaSummary1&) const;

    // Get detailed information about the specified frame. Returns true
    // on success; false if the track number is greater than
    // OmMediaInfo::numTracks or if the frame number is out of bounds.  Note
    // that the frame number may be negative if the movie has precharge.
    bool getSampleInfo(uint trackNum, int frameNum, OmMediaSample&) const;

    // Extract data from a clip, for example closed caption data.
    // Extract data of type dataType from track trackNum. Start at frame startFrame.
    // Extract numFrames frames (max 512 frames). Extract data into buffer rData.
    // Set rDataSize to the size of the pData buffer. Upon successful return,
    // rDataSize returns the amount of data extracted.
    bool getFrameData(uint trackNum, uint startFrame, uint numFrames,
                      OmMediaClipDataType dataType, unsigned char *rData,
                      uint *rDataSize) const;

    // Insert data into a clip, for example closed caption data.
    // Insert data of type dataType into track trackNum. Start at frame startFrame.
    // Insert numFrames frames (max 512 frames). Insert data from wData.
    // Set wDataSize to the size of the pData buffer. Upon successful return,
    // wDataSize returns the amount of data inserted.
    bool setFrameData(uint trackNum, uint startFrame, uint numFrames,
                      OmMediaClipDataType dataType, unsigned char *wData,
                      uint *wDataSize);

    // Get the media ID with the specified index. Returns non-zero on success,
    // or returns 0 if mediaIndex > OmMediaInfo::numMedia.
    OmMediaId getMediaId(uint mediaIndex) const;

    // Get the pathname associated with the specified media ID. Returns true
    // on success, or false if the path is longer than maxPathBytes.
    bool getPath(OmMediaId, char* path, uint maxPathBytes) const;
    bool getPath(OmMediaId, wchar_t* path, uint maxPathBytes) const;

    // Set the default in for the movie. Returns true on success, returns false
    // if frameNum < OmMediaInfo::firstFrame, or after the default out, or
    // the movie does not support the notion of default in/out.
    bool setDefaultIn(uint frameNum);

    // Set the default out for the movie. Returns true on success, returns
    // false if frameNum > OmMediaInfo::lastFrame, or before the default in, or
    // the movie does not support the notion of default in/out.
    bool setDefaultOut(uint frameNum);

    // Get the number assigned to the first frame of the movie
    #ifndef SWIG
    bool getFirstFrame(uint &frameNum) const;
    #else
    bool getFirstFrame(uint &OUTPUT) const;
    #endif

    // Assign a number to the first frame of the movie
    bool setFirstFrame(uint frameNum);

    // Get the starting timecode from the timecode track. Returns false if
    // there is no timecode track
    #ifndef SWIG
    bool getStartTimecode(uint &hour, uint &min, uint &sec, uint &frame) const;
    #else
    bool getStartTimecode(uint &OUTPUT, uint &OUTPUT, uint &OUTPUT, uint &OUTPUT) const;
    #endif

    // Set the starting timecode for the timecode track. Returns false if
    // there is no timecode track.
    bool setStartTimecode(uint hour, uint min, uint sec, uint frame);

    // Get the value of the dropframe flag
    #ifndef SWIG
    bool getDropFrame(bool &dropFrame) const;
    #else
    bool getDropFrame(bool &OUTPUT) const;
    #endif

    // Set the value of the dropframe flag
    bool setDropFrame(bool dropFrame);

    // Get the set of properties on the currently defined movie; note that,
    // if you change the current movie, the property list may change.
    // getProperties() only returns a property list with string values.
    // getAllProperties() returns a property list with all values.
    const OmMediaPropertyList* getProperties() const;
    const OmMediaPropertyList* getProperties(uint trackNum) const;
    const OmMediaPropertyList* getAllProperties() const;
    const OmMediaPropertyList* getAllProperties(uint trackNum) const;

    // Set a property on the currently defined movie. Returns false if no
    // movie is defined, or its read-only, or there's a conflict with some
    // other internal property of the same name, but with a different type.
    // (Only string types are available through this interface).
    bool setProperty(const OmMediaProperty&);
    bool setProperty(uint trackNum, const OmMediaProperty&);

    // delete a property on the currently defined movie. Returns false if no
    // movie is defined, or its read-only, or there's a conflict with some
    // other internal property of the same name, but with a different type.
    // (Only string types are available through this interface).
    bool deleteProperty(const OmMediaProperty&);
    bool deleteProperty(uint trackNum, const OmMediaProperty&);

    // Change the name of the movie; if renameMedia is true, any media files
    // referenced by the movie will be renamed to match the movie. Returns true
    // on success; false, if the movie could not be updated or the new name
    // already exists or is invalid.  Relative pathnames are OK.
    bool rename(const char* newPath, bool renameMedia = false);
    bool rename(const wchar_t* newPath, bool renameMedia = false);

    // Remove all files associated with the movie
    bool remove() const;

    // Flushes changes to the movie made by the set operations out to disk
    void flush() const;

    // Since only the DLL can create an OmMediaQueryRec, this is safe, except
    // from the truly twisted.
    static OmMediaQuery* castFrom(OmMediaQueryHandle p)
        { return (OmMediaQuery*)p; }

    // New UMID interface. Quicktime and MXF now both have UMIDs, which are
    // accessible through OmMediaQuery. The client can also request that the
    // clip generate a new UMID for itself
    const char* getUmid() const;
    bool generateUmid();
    const char* getSourceUmid() const;

    // Returns the Omneon MediaLayer version used to write this movie, if known.
    // If the version could not be determined or that the file was not written
    // by Omneon, then OmSwVersion::isValid() returns false.
    OmSwVersion getOmneonCreateVersion() const;

    // Returns the Omneon MediaLayer version currently in use
    OmSwVersion getThisSwVersion() const;

    // Returns true if this movie was written by Omneon.
    bool isOmneonMovie() const;

    // interfaces to get or set the active format description (AFD) of the clip,
    // which is represented here as an single byte of unsigned char type.
    // See SMPTE 2016-1 for the format of the afd byte.
    // The trackNum argument, if provided, indicates what track to use. If the
    // default of ~0 is given then the first video track in the clip will be used.
    unsigned char getVideoAfd(uint trackNum = ~0) const;
    bool setVideoAfd(unsigned char afd, uint trackNum = ~0);

    // If you plan on holding on to the OmMediaQuery instance, then you
    // should call release() when you are done to free up the resources
    // and close open files.
    void release();

private:
    OmMediaQuery(const OmMediaQuery&);    // prevent copy constructor
    OmMediaQuery& operator=(const OmMediaQuery&);  // prevent assignment
    struct OmMediaQueryImpl& m;
};

// Extended version of OmMediaQuery
class OMMEDIA_CPP_API OmMediaQueryEx : public OmMediaQuery {
public:
    // constructor
    OmMediaQueryEx(MediaAPIVersion version = currentMediaAPIVersion);
};

#    ifndef OMMEDIA_EXPORTS
#        define OmMediaQuery OmMediaQueryEx
#    endif

#    define OMMEDIA_BYREF(NAME)     NAME&
#    define OMMEDIA_DFLT(VALUE)     =VALUE

#    else

#    undef  OMMEDIA_C_API
#    define OMMEDIA_C_API
#    define OMMEDIA_BYREF(NAME)     NAME*
#    define OMMEDIA_DFLT(VALUE)
#    if (defined(__linux__) && !defined(_WCHAR_T_DEFINED)) || (defined(__MACH__) && !defined(_WCHAR_T))
#        define __need_wchar_t
#        include <stddef.h>
#        define _WCHAR_T_DEFINED
#    endif

#   ifndef bool
#       define bool                 unsigned char
#   endif

#    endif // __cplusplus

#ifndef SWIG

/////////////////////////////////////////////////////////////////////////////
//
// C interfaces
//
/////////////////////////////////////////////////////////////////////////////

// Create an instance of a OmMediaCopier
OMMEDIA_C_API OmMediaCopierHandle omMediaCopierCreate(void);
OMMEDIA_C_API OmMediaCopierHandle omMediaCopierCreateEx(enum MediaAPIVersion version);
#ifndef OMMEDIA_EXPORTS
#define omMediaCopierCreate() omMediaCopierCreateEx(currentMediaAPIVersion)
#endif

// Destroy an instance of a OmMediaCopier
OMMEDIA_C_API void omMediaCopierDestroy(OmMediaCopierHandle);

// Set this copy to be handled by a remote media server
OMMEDIA_C_API bool omMediaSetRemoteHost(OmMediaCopierHandle p,
                                        const char* host);

// Add all source tracks found in the specified path to the media file;
// If TrackNo is specified, only the specific track is added.
// Returns true on success, false if the media file is not understood
OMMEDIA_C_API bool omMediaAddSourceTrackW(OmMediaCopierHandle,
                                          const wchar_t* mediaPath,
                                          uint TrackNo);
OMMEDIA_C_API bool omMediaAddSourceTrack(OmMediaCopierHandle,
                                         const char* mediaPath,
                                         uint TrackNo);

// Add all source tracks found in the specified path to the media file;
// Returns true on success, false if the media file is not understood
OMMEDIA_C_API bool omMediaAddSourceTracks(OmMediaCopierHandle,
                                          const char* mediaPath);
OMMEDIA_C_API bool omMediaAddSourceTracksW(OmMediaCopierHandle,
                                           const wchar_t* mediaPath);

// Add a single source track from the specified path to the end of a track
// in the media file. Optionally, a range of frames to copy may be given.
// Returns true on success, false if the media file is not understood.
OMMEDIA_C_API bool omMediaAppendTrack(OmMediaCopierHandle p, uint dstTrack,
                                      uint srcTrack, const char* mediaPath,
                                      uint inSrcFrame OMMEDIA_DFLT(0),
                                      uint outSrcFrame OMMEDIA_DFLT(~0));
OMMEDIA_C_API bool omMediaAppendTrackW(OmMediaCopierHandle p, uint dstTrack,
                                       uint srcTrack, const wchar_t* mediaPath,
                                       uint inSrcFrame OMMEDIA_DFLT(0),
                                       uint outSrcFrame OMMEDIA_DFLT(~0));

// Add all source tracks from the specified path to the media file starting
// at track 'dstTrack'. Optionally, a range of frames to copy may be given.
// Returns true on success, false if the media file is not understood.
OMMEDIA_C_API bool omMediaAppendTracks(OmMediaCopierHandle p, uint dstTrack,
                                       const char* mediaPath,
                                       uint inSrcFrame OMMEDIA_DFLT(0),
                                       uint outSrcFrame OMMEDIA_DFLT(~0));
OMMEDIA_C_API bool omMediaAppendTracksW(OmMediaCopierHandle p, uint dstTrack,
                                        const wchar_t* mediaPath,
                                        uint inSrcFrame OMMEDIA_DFLT(0),
                                        uint outSrcFrame OMMEDIA_DFLT(~0));

// Specify the destination movie file, the suffix implies the movie type;
// i.e., .mov implies a Quicktime movie.
OMMEDIA_C_API bool omMediaSetDestination(OmMediaCopierHandle,
                                         const char* moviePath, bool replace);
OMMEDIA_C_API bool omMediaSetDestinationW(OmMediaCopierHandle,
                                          const wchar_t* moviePath, bool replace);

// Specify a format for the destination movie.  For clipProperties, pass:
//      - "qt7" for Apple/Final Cut Pro compatible MPEG format
//      - "qt6" for Omneon's legacy MPEG QT wrapper.
// If this function is not called a format will be chosen automatically
// based on the format of the input movie(s) and the global default chosen
// with the OmQtChooser utility.
OMMEDIA_C_API void OmMediaSetClipProperties(OmMediaCopierHandle p,
                                            const char *clipProperties);

// Specify the type of copy to be performed; the default is
// omFlattenedWithDiscreteMedia.
OMMEDIA_C_API void omMediaSetCopyType(OmMediaCopierHandle,
                                      enum OmMediaCopyType);

// Set the copy range on the source(s); this implies the destination
// will be outFrame-inFrame frames in length. Returns false if
// outFrame <= inFrame; If outFrame is ~0, it is shorthand for the
// end of the input. Also, if outFrame is beyond the end of the
// input (and not ~0) and force==false, the function returns false.
// Note that the OmMediaCopier's frame numbers are always zero-based.
OMMEDIA_C_API bool omMediaSetRange(OmMediaCopierHandle,
                                   uint inFrame, uint outFrame);

// Set the copy range on the specified track. Track numbers begin at
//  zero and increase with each call to addSourceTracks(). If you are
// unsure about the track numbers you can use getDstInfo() and
// getDstTrackInfo() to clarify. This method can be used to specify
// a shift  in a track relative to other tracks, or to select a subset
// of a source track for inclusion in the destination. For example, a
// call of setTrackRange(2,5,~0) will extract frame 5 through the end
// of track 2; a call of setTrackRange(2, -20, 10) will extract frame
// 0 through frame 9 from the source and place it at frame 20 through
// 29 in the destination.
OMMEDIA_C_API bool omMediaSetTrackRange(OmMediaCopierHandle, uint track,
                                        uint inFrame, uint outFrame);

// Specify that, independent of any specified outFrame, the copy will
// terminate on the last frame of video.  This is a simple way of making
// sure a too-long audio track, doesn't make the final movie too long.
// By default, the value is false.
OMMEDIA_C_API void omMediaSetTrimmedAudio(OmMediaCopierHandle, bool);

// Set the default video rate to be used for audio-only files.
OMMEDIA_C_API void omMediaSetDefaultFrameRate(OmMediaCopierHandle, enum OmFrameRate);

// change the file name suffix for individual media files created as
// as part of the copy() processing. Provide the suffix without the dot,
// for example, "m2v".
OMMEDIA_C_API bool omMediaSetOutputSuffix(OmMediaCopierHandle,
                                          enum OmMediaFileType,
                                          const char* suffix);

// Get the current output suffix for the specified type
OMMEDIA_C_API const char* omMediaGetOutputSuffix(OmMediaCopierHandle,
                                                 enum OmMediaFileType);

// Get the type for specified suffix. Returns omMediaUnknown if the
// suffix is not currently recognized
OMMEDIA_C_API enum OmMediaFileType omMediaGetOutputType(const char* suffix);

// Obtain the summary information for the destination movie. This
// changes as source tracks are added and parameters are changed.
OMMEDIA_C_API bool omMediaGetDstInfo(OmMediaCopierHandle,
                                     struct OmMediaInfo*);

// Obtain information about the specified destination track.
OMMEDIA_C_API bool omMediaGetDstTrackInfo(OmMediaCopierHandle,
                                          uint trackNum, struct OmMediaSummary*);
OMMEDIA_C_API bool omMediaGetDstTrackInfo1(OmMediaCopierHandle,
                                           uint trackNum, struct OmMediaSummary1*);

// Set the number of seconds a movie that is recording needs to be watched
// for changes before assuming the recording ended. The default for this
// value is 20 seconds.
OMMEDIA_C_API bool omMediaSetMaxRecordAge(OmMediaCopierHandle, uint seconds);

// perform the copy, creating the new output movie, and possibly new media
// files as specified by the copy type. This does not return until the
// copy is complete or omMediaCopyCancel() is called (by another thread).
OMMEDIA_C_API bool omMediaCopy(OmMediaCopierHandle);

// Get the copy progress.  This can be called while the copy is in progress
// from another thread.  Note that it may not count linearly from
// one frame to the next because some tracks may be ommitted if, for
// example, the media contains embedded audio.
OMMEDIA_C_API struct OmCopyProgress omMediaGetProgress(OmMediaCopierHandle);
OMMEDIA_C_API void omMediaGetProgressPtr(OmMediaCopierHandle,
                                         struct OmCopyProgress* progress);

// If you plan on holding on to the OmMediaCopier instance, then you
// should call omMediaCopyRelease() when you are done to free up the
// resources and close open files.
OMMEDIA_C_API void omMediaCopyRelease(OmMediaCopierHandle);

// If a call to copy() is in progress, a call to cancel() by some other
// thread will cause the copy to end at the next frame. The movie at that
// point will be mostly coherent, although the length if the tracks may
// differ by one frame.
OMMEDIA_C_API void omMediaCopyCancel(OmMediaCopierHandle);

// Create an instance of a OmMediaQuery
OMMEDIA_C_API OmMediaQueryHandle omMediaQueryCreate(void);
OMMEDIA_C_API OmMediaQueryHandle omMediaQueryCreateEx(enum MediaAPIVersion version);
#ifndef OMMEDIA_EXPORTS
#define omMediaQueryCreate() omMediaQueryCreateEx(currentMediaAPIVersion)
#endif

// Destroy an instance of a OmMediaQuery
OMMEDIA_C_API void omMediaQueryDestroy(OmMediaQueryHandle);

// Open the specified media or movie path. Returns true on success; false
// if the file is corrupt, missing, or unrecognized. Any previously held
// movie files are closed and released. Writable must be specified as
// true to use set methods
OMMEDIA_C_API bool omMediaSetFile(OmMediaQueryHandle, const char* mediaPath,
                                  bool writable);

// Get movie information. Always returns true unless setFile()
// was unsuccessful.
OMMEDIA_C_API bool omMediaGetMovieInfo(OmMediaQueryHandle,
                                       OMMEDIA_BYREF(struct OmMediaInfo));

// Get summary information for specified track. Returns true on success;
// false if the track number is greater than OmMediaInfo::numTracks
OMMEDIA_C_API bool omMediaGetTrackInfo(OmMediaQueryHandle,
                                       uint trackNum,
                                       OMMEDIA_BYREF(struct OmMediaSummary));
OMMEDIA_C_API bool omMediaGetTrackInfo1(OmMediaQueryHandle,
                                       uint trackNum,
                                       OMMEDIA_BYREF(struct OmMediaSummary1));

// Get detailed information about the specified frame. Returns true
// on success; false if the track number is greater than
// OmMediaInfo::numTracks or if the frame number is out of bounds.  Note
// that the frame number may be negative if the movie has precharge.
OMMEDIA_C_API bool omMediaGetSampleInfo(OmMediaQueryHandle, uint trackNum,
                                        int frameNum,
                                        OMMEDIA_BYREF(struct OmMediaSample));

// Extract data from a clip, for example closed caption data.
// Extract data of type dataType from track trackNum. Start at frame startFrame.
// Extract numFrames frames (max 512 frames). Extract data into buffer pData.
// Set pDataSize to the size of the pData buffer. Upon successful return,
// pDataSize returns the amount of data extracted.
OMMEDIA_C_API bool getFrameData(OmMediaQueryHandle, uint trackNum,
                                uint startFrame, uint numFrames,
                                enum OmMediaClipDataType dataType,
                                unsigned char *pData, uint *pDataSize);

// Insert data into a clip, for example closed caption data.
// Insert data of type dataType into track trackNum. Start at frame startFrame.
// Insert numFrames frames (max 512 frames). Insert data from pData.
// Set pDataSize to the size of the pData buffer. Upon successful return,
// pDataSize returns the amount of data inserted.
OMMEDIA_C_API bool setFrameData(OmMediaQueryHandle, uint trackNum,
                                uint startFrame, uint numFrames,
                                enum OmMediaClipDataType dataType,
                                unsigned char *pData, uint *pDataSize);

// Get the media ID with the specified index. Returns non-zero on success,
// or returns 0 if mediaIndex > OmMediaInfo::numMedia.
OMMEDIA_C_API OmMediaId omMediaGetMediaId(OmMediaQueryHandle, uint mediaIndex);

// Get the pathname associated with the specified media ID. Returns true
// on success, or false if the path is longer than maxPathBytes
OMMEDIA_C_API bool omMediaGetPath(OmMediaQueryHandle, OmMediaId,
                                  char* path, uint maxPathBytes);

// Set the default in for the movie. Returns true on success, returns false
// if frameNum < OmMediaInfo::firstFrame, or after the default out, or
// the movie does not support the notion of default in/out.
OMMEDIA_C_API bool omMediaSetDefaultIn(OmMediaQueryHandle, uint frameNum);

// Set the default out for the movie. Returns true on success, returns
// false if frameNum > OmMediaInfo::lastFrame, or before the default in, or
// the movie does not support the notion of default in/out.
OMMEDIA_C_API bool omMediaSetDefaultOut(OmMediaQueryHandle, uint frameNum);

// Get the number assigned to the first frame
OMMEDIA_C_API bool omMediaGetFirstFrame(OmMediaQueryHandle,
                                        OMMEDIA_BYREF(uint) frameNum);

// Assign a number to the first frame of the movie
OMMEDIA_C_API bool omMediaSetFirstFrame(OmMediaQueryHandle,uint frameNum);

// Get the timecode assigned to the first frame
OMMEDIA_C_API bool omMediaGetStartTimecode(OmMediaQueryHandle,
                                           OMMEDIA_BYREF(uint) hour,
                                           OMMEDIA_BYREF(uint) min,
                                           OMMEDIA_BYREF(uint) sec,
                                           OMMEDIA_BYREF(uint) frame);

// Assign a timecode to the first frame of the movie
OMMEDIA_C_API bool omMediaSetStartTimecode(OmMediaQueryHandle,
                                           uint hour, uint min, uint sec,
                                           uint frame);

// Get the value of the dropframe flag
OMMEDIA_C_API bool omMediaGetDropFrame(OmMediaQueryHandle p,
                                       OMMEDIA_BYREF(bool) dropFrame);

// Set the value of the dropframe flag
OMMEDIA_C_API bool omMediaSetDropFrame(OmMediaQueryHandle p,
                                       bool dropFrame);

// Get the number of movie properties with text values.
OMMEDIA_C_API uint omMediaGetPropertyCount(OmMediaQueryHandle p);

// Get the number of movie properties of all types.
OMMEDIA_C_API uint omMediaGetAllPropertyCount(OmMediaQueryHandle p);

// Get the number of properties on a track with text values
OMMEDIA_C_API uint omMediaGetTrackPropertyCount(OmMediaQueryHandle p,
                                                uint trackNum);
// Get the number of movie properties on a track of all types.
OMMEDIA_C_API uint omMediaGetTrackAllPropertyCount(OmMediaQueryHandle p,
                                                   uint trackNum);

// Get the movie property specified by "index".  The key will be returned
// in "name", and the value in "value", up to the specified number of bytes
OMMEDIA_C_API bool omMediaGetProperty(OmMediaQueryHandle p, uint index,
                                      char *name,  uint maxNameBytes,
                                      char *value, uint maxValueBytes);

// Get the movie property specified by "index".  The key will be returned
// in "name", and the value in "value", up to the specified number of bytes,
// and the type of the value in type
OMMEDIA_C_API bool omMediaGetPropertyAndType(OmMediaQueryHandle p, uint index,
                                             char *name,  uint maxNameBytes,
                                             void *value,
                                             OMMEDIA_BYREF(uint) maxValueBytes,
                                             OMMEDIA_BYREF(OmMediaPropertyType) type);

// Get the track property specified by "index".  The key will be returned
// in "name", and the value in "value", up to the specified number of bytes
OMMEDIA_C_API bool omMediaGetTrackProperty(OmMediaQueryHandle p, uint trackNum,
                                           uint index,
                                           char *name,  uint maxNameBytes,
                                           char *value, uint maxValueBytes);

// Get the track property specified by "index".  The key will be returned
// in "name", and the value in "value", up to the specified number of bytes,
// and the type of the value in type
OMMEDIA_C_API bool omMediaGetTrackPropertyAndType(OmMediaQueryHandle p,
                                                  uint trackNum, uint index,
                                                  char *name,  uint maxNameBytes,
                                                  void *value,
                                                  OMMEDIA_BYREF(uint) maxValueBytes,
                                                  OMMEDIA_BYREF(OmMediaPropertyType) type);

// Set the movie property to the specified name and value.
// If the name already exists, its value will be replaced.  If the
// name does not exist, the name and value will be added to the movie
OMMEDIA_C_API bool omMediaSetProperty(OmMediaQueryHandle p,
                                      char *name, char *value);

// Set the movie property to the specified name.value and type.
// If the name already exists, its value will be replaced.  If the
// name does not exist, the name and value will be added to the movie
OMMEDIA_C_API bool omMediaSetPropertyAndType(OmMediaQueryHandle p,
                                             char *name, void *value,
                                             uint valueLen,
                                             OmMediaPropertyType type);

// Set the property on a track to the specified name and value.
// If the name already exists, its value will be replaced.  If the
// name does not exist, the name and value will be added to that track
OMMEDIA_C_API bool omMediaSetTrackProperty(OmMediaQueryHandle p,
                                           uint trackNum,
                                           char *name, char *value);

// Set the property on a track to the specified name.value and type.
// If the name already exists, its value will be replaced.  If the
// name does not exist, the name and value will be added to the movie
OMMEDIA_C_API bool omMediaSetTrackPropertyAndType(OmMediaQueryHandle p,
                                                  uint trackNum, char *name,
                                                  void *value, uint valueLen,
                                                  OmMediaPropertyType type);

// Delete the specified movie property
OMMEDIA_C_API bool omMediaDeleteProperty(OmMediaQueryHandle p, char *name);

// Delete the specified movie property from the track
OMMEDIA_C_API bool omMediaDeleteTrackProperty(OmMediaQueryHandle p,
                                              uint trackNum, char *name);

// Change the name of the movie; if renameMedia is true, any media files
// referenced by the movie will be renamed to match the movie. Returns true
// on success, false if the movie could not be updated or the new name
// already exists or is invalid.  Relative pathnames are OK.
OMMEDIA_C_API bool omMediaRename(OmMediaQueryHandle,
                                 const char* newPath, bool renameMedia);

// Remove all files associated with the movie
OMMEDIA_C_API bool omMediaRemove(OmMediaQueryHandle);

// Flush changes to the movie made by the set operations out to disk
OMMEDIA_C_API void omMediaFlush(OmMediaQueryHandle);

// New UMID interface. Quicktime and MXF now both have UMIDs, which are
// accessible through OmMediaQuery. The client can also request that the
// clip generate a new UMID for itself
OMMEDIA_C_API const char* getUmid(OmMediaQueryHandle);
OMMEDIA_C_API bool generateUmid(OmMediaQueryHandle);
OMMEDIA_C_API const char* getSourceUmid(OmMediaQueryHandle);

// interfaces to get or set the active format description (AFD) of the clip,
// which is represented here as an single byte of unsigned char type.
// See SMPTE 2016-1 for the format of the afd byte.
// The trackNum argument, if provided, indicates what track to use. If the
// default of ~0 is given then the first video track in the clip will be used.
OMMEDIA_C_API unsigned char omMediaGetVideoAfd(OmMediaQueryHandle p, uint trackNum);
OMMEDIA_C_API bool omMediaSetVideoAfd(OmMediaQueryHandle p,
                                      unsigned char afd, uint trackNum);

// If you plan on holding on to the OmMediaQuery instance, then you
// should call omMediaQueryRelease() when you are done to free up the
// resources and close open files.
OMMEDIA_C_API void omMediaQueryRelease(OmMediaQueryHandle);

#endif // SWIG

// The following C api functions are useful in SWIG wrappers...

// Safely release OmMedia resources. This must be called before 
// the application exits, signalling threads to stop and free up
// resources.
OMMEDIA_C_API bool omMediaShutdown();

// Initialize OmMedia resources. This must be called once, before calling
// any other Media API function.
OMMEDIA_C_API bool omMediaInit();


#    undef OMMEDIA_BYREF
#    undef OMMEDIA_DFLT

#endif // _OMMEDIA_H_

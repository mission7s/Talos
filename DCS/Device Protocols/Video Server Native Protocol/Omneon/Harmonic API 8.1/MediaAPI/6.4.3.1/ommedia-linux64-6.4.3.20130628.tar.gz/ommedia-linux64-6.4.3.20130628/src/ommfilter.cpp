/*
    Omneon MediaAPI Sample File: omfilter.cpp

    Sample cli application demonstrating using the OmMovie
    class to apply audio filters to movies.

    Copyright (c) 2010 Harmonic Inc.
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

// For cross platform sleep
#ifdef _MSC_VER
#include <windows.h>
void waitMsec(unsigned int ms) { Sleep(ms); }
#else
#include <unistd.h>
void waitMsec(unsigned int ms) { usleep(ms*1000); }
#endif

// Media API Includes
#include "ommovie.h"

bool pauseAtExit = false;

int pauseExec(int value)
{
    char buf[ 128 ];
    if (pauseAtExit) {
        printf("hit return to exit...");
        if (fgets(buf, sizeof(buf) - 1, stdin) == 0)
            return 2;
    }
    OmMovie::shutdown();
    return value;
}

// Help message
static void usage(const char* format, ...)
{
    va_list argList;
    va_start(argList, format);
    vfprintf(stderr, format, argList);
    printf("\nUsage: omfilter -srcMovie <clipname> -srcMovie <clipname> -filter <filtername> -duration <# frames> -dstMovie <filename> <options>\n"
        " Where:\n"
        "  -srcMovie   Filename of source movie.  Requires 2 movies.\n"
        "  -filter     Type of filter to apply. See Available Filters.\n"
        "  -duration   Duration of the filter in frames.  Must be a positive value.\n"
        "  -dstMovie   Filename of destination movie.  Use replace to overwrite existing file.\n"
        "\n"
        " Available Filters:\n"
        "  xfade       Performs a cross-fade between audio tracks\n"
        "              requires frame overlap to be greater than 0\n"
        "  vfade       Performs a v-fade between audio tracks\n"
        "\n"
        " Available Options:\n"
        "  -help       this message\n"
        "  -pause      wait for a CR from user before exiting\n"
        "  -replace    overwrite dstMovie if it exists\n"
        " \n");
    exit(pauseExec(1));
}

static char* getArg(int& argc, char**& argv)
{
    if (argc <= 1) {
        usage("\nMissing argument..\n\n");
        exit(1);
    }
    argc--, argv++;
    return *argv;
}

static char* getErrorString(OmMovieErr e)
{
    switch (e) {
    case omErrOk:               return "omErrOk";
    case omErrNotImplemented:   return "omErrNotImplemented";
    case omErrInvalidArgument:  return "omErrInvalidArgument";
    case omErrBadState:         return "omErrBadState";
    case omErrBufferTooSmall:   return "omErrBufferTooSmall";
    case omErrInProgress:       return "omErrInProgress";
    case omErrAborted:          return "omErrAborted";
    case omErrUnknown:          return "omErrUnknown";
    default:                    return "unknown error";
    }
}

int main(int argc, char** argv)
{
    const char* srcMovieA = 0;  // srcMovie A
    const char* srcMovieB = 0;  // srcMovie B
    const char* dstFile = 0;    // dstMovie
    const char* filter = 0;     // filter name
    int duration = -1;          // filter duration
    bool replace = false;       // overwrites existing dstFile if true
    
    if (argc < 2)
        usage("");

    // Process the cli arguments
    for (argc--, argv++; argc; argc--, argv++) {
        if (strcmp(*argv, "-help") == 0) {
            usage("");
        
        } else if (strcmp(*argv, "-replace") == 0) {
            replace = true;
        
        }  else if (strcmp(*argv, "-pause") == 0) {
            pauseAtExit = true;

        } else if (strcmp(*argv, "-srcMovie") == 0) {
            if (srcMovieA == NULL)
                srcMovieA = getArg(argc, argv);
            else if (srcMovieB == NULL)
                srcMovieB = getArg(argc, argv);
            else
                usage("Too many src movies");
        
        } else if (strcmp(*argv, "-dstMovie") == 0) {
            dstFile = getArg(argc, argv);
        
        } else if (strcmp(*argv, "-filter") == 0) {
            filter = getArg(argc, argv);

            // Only have support for xfade and vfade
            if (! (strcmp(filter, "xfade") == 0 || strcmp(filter, "vfade") == 0))
                usage("Unsupported filter \"%s\"", filter);
        
        } else if (strcmp(*argv, "-duration") == 0) {
            duration = atoi(getArg(argc, argv));
        }
    }

    // Check that we got all the arguments we needed
    if (srcMovieA == 0 || srcMovieB == 0 || dstFile == 0 ||filter == 0 || duration == -1)
        usage("Invalid arguments");

    OmMovieErr status;  // error status code
    OmMovie omMovieA;   // movie object for srcMovie A
    OmMovie omMovieB;   // movie object for srcMovie B
    OmMovieInfo info;   // info for Movie 
   
    // Open srcMovie A and then query it to get basic info such as the length
    status = omMovieA.open(srcMovieA);
    if (status != omErrOk) {
        printf("%s while opening %s\n", getErrorString(status), srcMovieA);
        return pauseExec(1);
    }

    status = omMovieA.getMovieInfo(info);
    if (status != omErrOk) {
        printf("%s while querying %s\n", getErrorString(status), srcMovieA);
        omMovieA.close();
        return pauseExec(1);
    }
   
    // Open srcMovie B and then query it to get basic info such as the length
    status = omMovieB.open(srcMovieB);
    if (status != omErrOk) {
        printf("%s while opening %s\n", getErrorString(status), srcMovieB);
        omMovieA.close();
        return pauseExec(1);
    }

    /* Calculate the placement of the 2nd Movie

        In general overlap between two movies (or tracks) must be zero or greater.
        Some filters have specific overlap requirements, for instance
        xfade requires a non-zero frame overlap.

        In this example we'll handle the two fades differently.
    */
    unsigned int moviePos = 0;      // frame position for the 2nd movie to be added at
    unsigned int filterPos = 0;     // frame position for the filter to start at
    
    if (strcmp(filter, "xfade") == 0) {
        /*  For X-Fade we require some amount of overlap, we'll use the user specified
            filter duration as the amount of overlap required.

                          [--] Filter
                          [--------] Movie B
            Movie A [--------]
                          
        */
            
        // We need a non-zero overlap, which for this example requires a non-zero duration
        if (duration <= 0) {
            printf("xfade requires a positive duration\n");
            omMovieA.close();
            omMovieB.close();
            return pauseExec(1);
        }

        // the duration cannot be greater than both movies
        if (duration > omMovieA.getDuration() && duration > omMovieB.getDuration()) {
            printf("Duration %d is greater than the length of both srcMovies\n", duration);
            omMovieA.close();
            omMovieB.close();
            return pauseExec(1);
        }

        moviePos = omMovieA.getDuration() - duration;
        filterPos = moviePos;

    } else if (strcmp(filter, "vfade") == 0) {
        /*  For V-Fade we will have 0 overlap, and center the filter over the transition point
        
                           [----] Filter
                              [--------] Movie B
            Movie A [--------]
                              
        */

        moviePos = omMovieA.getDuration();
        filterPos = moviePos - (duration / 2);
    
    } else {
        omMovieA.close();
        omMovieB.close();
        usage("Unsupported filter \"%s\"", filter);
    }

    // Create the destination movie
    OmMovie dstMovie;
    status = dstMovie.open(dstFile,
                    replace ? omAccTruncate : omAccCreate, 
                    info.containment == omMediaContainmentReference ? omWrapReferenced  : omWrapEmbedded);

    if (status != omErrOk) {
        printf("%s while creating dstFile %s\n", getErrorString(status), dstFile);
        omMovieA.close();
        omMovieB.close();
        return pauseExec(1);
    }

    // Add Movie A to the destination movie
    status = dstMovie.addMovie(omMovieA);
    if (status != omErrOk) {
        printf("%s while adding %s at frame %d\n", getErrorString(status), srcMovieA, 0);
        omMovieA.close();
        omMovieB.close();
        dstMovie.close();
        return pauseExec(1);
    }

    omMovieA.close();  // close movie A, it is no longer needed

    // stack Movie B on top of Movie A at the calculated position
    // we use zero for  because we want the second set of tracks
    status = dstMovie.addMovie(omMovieB, 0, moviePos);
    if (status != omErrOk) {
        printf("%s while adding %s at frame %d\n", getErrorString(status), srcMovieB, moviePos);
        omMovieB.close();
        dstMovie.close();
        return pauseExec(1);
    }

    omMovieB.close(); // close movie B, it is no longer needed
      

    /* Apply the filter

        We use addFilters() rather than addFilter() because we want to apply the same filter, in this
        example an audio filter across all the audio tracks in our destination movie.
    */
    //status = omMovieA.addFilters(omMediaPcmAudio, filterPos, duration, filter);
    //if (status != omErrOk) {
    //    printf("%s while applying %s filter\n", getErrorString(status), filter);
    //    return pauseExec(1);
    //}

    // Write the new movie to disk
    OmSaveHandle saveHandle = dstMovie.save();
    
    // wait for the movie to write out to disk
    while ((status = omMovieA.getSaveProgress(saveHandle)) == omErrInProgress)
        waitMsec(100); // sleep for 100ms, see ifdef at top of file for cross platform definition

    if (status != omErrOk) {
        printf("%s while writing saving %s\n", getErrorString(status), dstFile);
        dstMovie.close();
        return pauseExec(1);
    }

    dstMovie.close(); // close the dst movie
    return pauseExec(0);;
}

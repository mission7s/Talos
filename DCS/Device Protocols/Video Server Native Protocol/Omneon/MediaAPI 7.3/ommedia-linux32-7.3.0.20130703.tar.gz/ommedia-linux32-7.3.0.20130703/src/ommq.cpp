#include "ommedia.h"
#include "ommovie.h"
#include <stdio.h>
//#include <process.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>

bool pauseAtExit = false;

int pauseExec(int value)
{
    char buf[ 128 ];
    if (pauseAtExit) {
        printf("hit return to exit...");
        if (fgets(buf, sizeof(buf) - 1, stdin));
    }
    omMediaShutdown();
    return value;
}

static void fatalErr(const char* format, ...)
{
    va_list argList;
    va_start(argList, format);
    vfprintf(stderr, format, argList);
    exit(pauseExec(1));
}

static void usage(const char* format, ...)
{
    va_list argList;
    va_start(argList, format);
    vfprintf(stderr, format, argList);
    printf("Usage: ommq <options> movie [movie...]\n"
           "where the options are:\n"
           "  -lsamples in addition to the movie and track summary, sizes\n"
           "            and offsets for every frame in the movie\n"
           "  -ldata    list the (string) user data items\n"
           "  -sdata name=value\n"
           "  -sdata N:name=value\n"
           "            set user data items on the movie (first\n"
           "            usage), or on track N (second usage)\n"
           "  -genumid  generate a new UMID in the movie\n"
           "  -q        quiet; by default ommq shows a summary of all the\n"
           "            tracks; -q suppresses that (useful w/ -din & -dout,\n"
           "            or if you just want -lsamples output.\n"
           "  -din N    change the default in frame to N\n"
           "  -dout N   change the default out frame to N\n"
           "  -fframe N change the first frame to N\n"
           "  -tc HH:MM:SS.FF\n"
           "            change the start timecode to HH:MM:SS.FF\n"
           "  -afd N    change the afd value of the first video track to N,\n"
           "            which should be given as an 8-bit hex number. See\n"
           "            SMPTE 2016-1 for the allowed values.\n"
           "  -pause    wait for a CR from user before exiting\n");
    exit(pauseExec(1));
}

static char* getArg(int& argc, char**& argv)
{
    if (argc <= 1)
        fatalErr("missing %s argument\n", *argv);
    argc--, argv++;
    return *argv;
}

const char* toString(OmFrameRate fr)
{
    switch(fr) {
    default:                return "bad FPS";
    case omFrmRate23_976Hz: return "23.976 FPS";
    case omFrmRate24Hz:     return "24 FPS";
    case omFrmRate25Hz:     return "25 FPS";
    case omFrmRate29_97Hz:  return "29.97 FPS";
    case omFrmRate30Hz:     return "30 FPS";
    case omFrmRate50Hz:     return "50 FPS";
    case omFrmRate59_94Hz:  return "59.94 FPS";
    case omFrmRate60Hz:     return "60 FPS";
    }
};

const char* toString(OmVideoSampleRatio vsr)
{
    switch(vsr) {
    default:                return "bad VSR";
    case omVideoSampleNone: return "none";
    case omVideoSample420:  return "4:2:0";
    case omVideoSample411:  return "4:1:1";
    case omVideoSample422:  return "4:2:2";
    case omVideoSample444:  return "4:4:4";
    }
};

const char* toString(OmVideoAspectRatio asr)
{
    switch (asr) {
    default: return ""; 
    case omVideoAspect4to3: return "4:3";
    case omVideoAspect16to9: return "16:9";
    }
};

const char *gopToString(const OmTrackInfo& trackInfo)
{
    if (trackInfo.gopLength == 1)
        return "iframe";
    return "lgop";
}

const char* typeToString(const OmTrackInfo& trackInfo)
{
    const char *typeStr = "";

    switch(trackInfo.essenceType) {
    case omMediaMpegVideo:      return "mpeg video";
    case omMediaMpegStdAudio:   typeStr = "mpeg audio"; break;
    case omMediaMpegAc3:        typeStr = "mpeg ac3 audio"; break;
    case omMediaPcmAudio:       typeStr = "pcm audio"; break;
    case omMediaDvVideo:        return "dv video";
    case omMediaDvAudio:        typeStr = "dv audio"; break;
    case omMediaRec601Video:    return "rec601 video";
    case omMediaHdcam:          return "hdcam video";
    case omMediaVbi:            return "vertical blanking";
    case omMediaData:           return "data";
    case omMediaDnxhd:          return "dnxhd video";
    case omMediaAvc:            return "avc video";
    case omMediaAlawAudio:      typeStr = "alaw audio"; break;
    case omMediaMpeg1System:    typeStr = "mpeg1 system"; break;
    case omMedia436mAnc:        return "436Vanc";
    case omMedia436mVbi:        return "436Vbi";
    case omMediaGxfAnc:         return "GxfAnc";
    case omMediaAacAudio:       typeStr = "aac audio"; break;
    case omMediaJpeg2000:       return "jpeg2000 video";
    case omMediaProRes:         return "prores video";
    case omMediaSoftel:         return "softel subtitle";

    // unknown/unmapped
    case omMediaUnknown:
    case omMediaTc:
    case omMediaDisplay:
                                return "unknown media";
    }

    // audio makes it to here...
    static char buf[ 128 ];
    sprintf(buf, "%d-channel,  %s", trackInfo.channels,
        trackInfo.bigEndian ? "big-endian" : "little-endian",
        typeStr);
    return buf;
};

const char* bitrateToString(uint bitrate)
{
    static char buf[ 64 ];
    if (bitrate >= 1000000)
        sprintf(buf, "%0.1fMbit", float(bitrate) / 1000000);
    else
        sprintf(buf, "%0.1fKbit", float(bitrate) / 1000);
    return buf;
}

struct QueryInfo {
    enum { maxInputs = 16 };
    enum { maxDataValues = 16 };

    struct PropInfo {
        int track;
        OmMediaProperty* prop;
        PropInfo() : track(-1), prop(0) {}
        void set(int t, const char* name, const char* value)
        {
            track = t; 
            prop = new OmMediaProperty(name, value);
        }
    };

    char* inputs[ maxInputs ];
    int nInputs;
    PropInfo props[ maxDataValues ];
    int nProperties;
    uint defaultIn;
    uint defaultOut;
    uint firstFrame;
    uint tcHours;
    uint tcMinutes;
    uint tcSeconds;
    uint tcFrames;
    bool tcDropFrame;
    bool quiet;
    bool listSamples;
    bool listData;
    bool generateUmid;
    uint afd;

    QueryInfo()
      : nInputs(0),
        nProperties(0),
        defaultIn(~0),
        defaultOut(~0),
        firstFrame(~0),
        tcHours(~0),
        tcMinutes(~0),
        tcSeconds(~0),
        tcFrames(~0),
        tcDropFrame(false),
        quiet(false),
        listSamples(false),
        listData(false),
        generateUmid(false),
        afd(~0)
    {}
};

void query(QueryInfo& q)
{
    // this is declared locally so that when this function returns,
    // it will properly be destroyed and resources released.  This means
    // that you should not call exit in here which would bypass the destructor.
    OmMovie movie;
    bool writable = q.defaultIn != (unsigned int)~0
                 || q.defaultOut != (unsigned int)~0
                 || q.firstFrame != (unsigned int)~0
                 || q.tcHours != (unsigned int)~0
                 || q.nProperties > 0
                 || q.generateUmid
                 || q.afd != (unsigned int)~0;

    for (int i = 0; i < q.nInputs; i++) {
        if (movie.open(q.inputs[i], writable ? omAccReadWrite : omAccReadOnly) != omErrOk) {
            printf("can't open %s: %s\n", q.inputs[i], movie.getLastErrorString());
            continue;
        }
        OmMovieInfo movieInfo;
        if (movie.getMovieInfo(movieInfo) != omErrOk) {
            printf("can't get movie info for %s: %s\n", q.inputs[i], movie.getLastErrorString());
            continue;
        }

        OmTrackInfo* trackInfo = 0;
        uint trkIdx;
        if (movieInfo.numTracks != 0) {
            trackInfo = new OmTrackInfo[ movieInfo.numTracks ];
            for (trkIdx = 0; trkIdx < movieInfo.numTracks; trkIdx++) {
                if (movie.getTrackInfo(trkIdx, trackInfo[trkIdx]) != omErrOk) {
                    printf("can't get track info for %s, track %d: %s\n",
                        q.inputs[i], trkIdx, movie.getLastErrorString());
                    break;
                }
            }
            if (trkIdx != movieInfo.numTracks)
                continue;
        }

        if (! q.quiet) {
            int tch, tcm, tcs, tcf;
            bool drop;
            if (movie.getStartTimecode(tch, tcm, tcs, tcf, drop) != omErrOk) {
                printf("can't get start timecode for %s: %s\n",
                    q.inputs[i], movie.getLastErrorString());
                tch = tcm = tcs = tcf = 0;
                drop = false;
            }

            enum { umidLength = 128 };
            char umid[umidLength];
            if (movie.getUmid(umid, umidLength) != omErrOk) {
                printf("can't get umid for %s: %s\n", q.inputs[i],
                        movie.getLastErrorString());
                umid[0] = '\0';
            }

            unsigned char afd;
            if (movie.getVideoAfd(afd) != omErrOk) {
                printf("can't get video afd for %s: %s\n", q.inputs[i],
                        movie.getLastErrorString());
                afd = 0;
            }
            printf("%s: %s, %d tracks, %d frames (%d-%d)\n"
                "  def in/out=%d/%d, precharge=%d, first frame=%d, tc=%02d:%02d:%02d.%02d\n"
                "  clipProperties=%s, umid=%s, afd=0x%x\n",
                q.inputs[i], toString(movieInfo.frameRate), movieInfo.numTracks,
                movieInfo.lastFrame - movieInfo.firstFrame, movieInfo.firstFrame,
                movieInfo.lastFrame, movieInfo.defaultIn, movieInfo.defaultOut,
                movieInfo.numPrecharge, movieInfo.firstFrame, tch, tcm, tcs, tcf, 
                movieInfo.clipProperties ? movieInfo.clipProperties : "",
                umid, (uint)afd);

            enum { maxPathLength = 512 };
            char path[ maxPathLength ];
            for (uint mediaIdx = 0; mediaIdx < movieInfo.numMedia; mediaIdx++) {
                OmMediaId id = movie.getMediaId(mediaIdx);
                int length = maxPathLength;
                if (id == 0 || movie.getPath(id, path, &length) != omErrOk)
                    printf("  media %d: 0x%x bad? %s, %d\n", mediaIdx, id, movie.getLastErrorString(), length);
                else
                    printf("  media %d: %s\n", mediaIdx, path);
            }
            for (trkIdx = 0; trkIdx < movieInfo.numTracks; trkIdx++) {
                if (trackInfo[trkIdx].essenceType == omMediaMpegVideo) {
                    printf("  track %d: %d-bit %s %s,%s,%s,%s\n",
                        trkIdx, trackInfo[trkIdx].bitsPerUnit,
                        gopToString(trackInfo[trkIdx]),
                        typeToString(trackInfo[trkIdx]),
                        toString(trackInfo[trkIdx].aspect), toString(trackInfo[trkIdx].vsr),
                        bitrateToString(trackInfo[trkIdx].bitrate));
                } else {
                    printf("  track %d: %d-bit %s,%s,%s,%s\n",
                        trkIdx, trackInfo[trkIdx].bitsPerUnit,
                        typeToString(trackInfo[trkIdx]),
                        toString(trackInfo[trkIdx].aspect), toString(trackInfo[trkIdx].vsr),
                        bitrateToString(trackInfo[trkIdx].bitrate));
                }
            }
        }

        if (q.listSamples) {
            OmFrameInfo frameInfo;
            for (int f = movieInfo.firstFrame - movieInfo.numPrecharge; f < int(movieInfo.lastFrame); f++) {
                for (trkIdx = 0; trkIdx < movieInfo.numTracks; trkIdx++) {
                    if (movie.getFrameInfo(trkIdx, f, frameInfo) != omErrOk)
                        continue;
                    printf("t%d,f%d: ", trkIdx, f);
                    printf("%db@%I64d", frameInfo.size0, frameInfo.offset0);
                    if (frameInfo.nChunks > 0)
                        printf(",%db@%I64d", frameInfo.size1, frameInfo.offset1);
                    printf("\n");
                }
            }
        }

        if (q.listData) {
            OmMediaProperty prop;
            for (int i = 0; i < movie.getMoviePropertyCount(); i++) {
                if (i == 0)
                    printf("movie user data:\n");
                if (movie.getMovieProperty(i, prop) != omErrOk) {
                    printf("  %s\n", movie.getLastErrorString());
                    continue;
                }
                printf("  %d: %s=%s\n",
                    i, prop.getName(), prop.getValue());
            }
            for (trkIdx = 0; trkIdx < movieInfo.numTracks; trkIdx++) {
                for (int i = 0; i < movie.getTrackPropertyCount(trkIdx); i++) {
                    if (i == 0)
                        printf("  track %d:\n", trkIdx);
                    if (movie.getTrackProperty(trkIdx, i, prop) != omErrOk) {
                        printf("    %s\n", movie.getLastErrorString());
                        continue;
                    }
                    printf("    %d: %s=%s\n",
                        i, prop.getName(), prop.getValue());
                }
            }
        }

        if (q.generateUmid) {
            OmMovieErr e = movie.generateUmid();
            printf("generate umid %s\n", e == omErrOk ? "success" : "failure");
            if (e != omErrOk)
                printf("  %s\n", movie.getLastErrorString());
        }

        if (q.defaultIn != (unsigned int)~0 && movie.setDefaultIn(q.defaultIn) != omErrOk) {
            printf("can't set default in to %d in %s: %s\n",
                q.defaultIn, q.inputs[i], movie.getLastErrorString());
        }
        if (q.defaultOut != (unsigned int)~0 && ! movie.setDefaultOut(q.defaultOut) != omErrOk) {
            printf("can't set default out to %d in %s: %s\n",
                q.defaultOut, q.inputs[i], movie.getLastErrorString());
        }
        if (q.firstFrame != (unsigned int)~0 && ! movie.setFirstFrame(q.firstFrame) != omErrOk) {
            printf("can't set first frame to %d in %s: %s\n",
                q.firstFrame, q.inputs[i], movie.getLastErrorString());
        }
        if (q.tcHours != (unsigned int)~0 && q.tcMinutes != (unsigned int)~0 &&
            q.tcSeconds != (unsigned int)~0 && q.tcFrames != (unsigned int)~0 &&
            movie.setStartTimecode(q.tcHours, q.tcMinutes, q.tcSeconds, q.tcFrames, q.tcDropFrame) != omErrOk) {
            printf("can't set start timecode to %02d:%02d:%02d.%02d in %s: %s\n",
                q.tcHours, q.tcMinutes, q.tcSeconds, q.tcFrames, q.inputs[i],
                movie.getLastErrorString());
        }

        if (q.afd != (unsigned int)~0 && ! movie.setVideoAfd(q.afd) != omErrOk) {
            printf("can't set afd to 0x%x in %s: %s\n",
                q.afd, q.inputs[i], movie.getLastErrorString());
        }

        if (q.nProperties > 0) {
            for (int i = 0; i < q.nProperties; i++) {
                if (q.props[i].track >= 0) {
                    if (movie.setTrackProperty(q.props[i].track, *q.props[i].prop) != omErrOk) {
                        printf("can't set property %s=%s on track %d: %s\n",
                            q.props[i].prop->getName(),
                            q.props[i].prop->getValue(),
                            q.props[i].track,
                            movie.getLastErrorString());
                    }
                } else {
                    if (movie.setMovieProperty(*q.props[i].prop) != omErrOk) {
                        printf("can't set property %s=%s\n",
                            q.props[i].prop->getName(),
                            q.props[i].prop->getValue(),
                            movie.getLastErrorString());
                    }
                }
            }
        }
    }
}

int main(int argc, char**argv)
{
    QueryInfo q;

    for (argc--, argv++; argc; argc--, argv++) {
        if (strcmp(*argv, "-din") == 0) {
            if (q.defaultIn != (unsigned int)~0)
                usage("-din specified twice\n");
            q.defaultIn = atoi(getArg(argc, argv));
        } else if (strcmp(*argv, "-dout") == 0) {
            if (q.defaultOut != (unsigned int)~0)
                usage("-dout specified twice\n");
            q.defaultOut = atoi(getArg(argc, argv));
        } else if (strcmp(*argv, "-fframe") == 0) {
            if (q.firstFrame != (unsigned int)~0)
                usage("-fframe specified twice\n");
            q.firstFrame = atoi(getArg(argc, argv));
        } else if (strcmp(*argv, "-tc") == 0) {
            char *tc = getArg(argc, argv); 
            if (sscanf(tc, "%d:%d:%d:%d",
                &q.tcHours, &q.tcMinutes, &q.tcSeconds, &q.tcFrames) == 4) {
                q.tcDropFrame = false;
            } else if (sscanf(tc, "%d:%d:%d.%d",
                &q.tcHours, &q.tcMinutes, &q.tcSeconds, &q.tcFrames) == 4) {
                q.tcDropFrame = true;
            } else if (sscanf(tc, "%d:%d:%d;%d",
                &q.tcHours, &q.tcMinutes, &q.tcSeconds, &q.tcFrames) == 4) {
                q.tcDropFrame = true;
            } else {
                usage("incorrect timecode");
            }
        } else if (strcmp(*argv, "-sdata") == 0) {
            if (q.nProperties >= QueryInfo::maxDataValues) {
                usage("too many properties specified (max %d)\n",
                    QueryInfo::maxDataValues);
            }
            const char* p0 = getArg(argc, argv);
            const char* p1 = p0;
            int track = -1;
            while (*p1 && *p1 != '=' && *p1 != ':')
                p1++;
            if (*p1 == ':') {
                track = atoi(p0);
                for (p0 = ++p1; *p1 && *p1 != '=' && *p1 != ':'; )
                    p1++;
            }                

            if (*p1 == '\0' || *(p1+1) == '\0')
                usage("-data arg should have the form name=value\n");
            int length = p1-p0;
            char* pName = new char[ length+1 ];
            strncpy(pName, p0, length);
            pName[ length ] = '\0';
            q.props[q.nProperties++].set(track, pName, ++p1);
            delete pName;
        } else if (strcmp(*argv, "-q") == 0) {
            q.quiet = true;
        } else if (strcmp(*argv, "-pause") == 0) {
            pauseAtExit = true;
        } else if (strcmp(*argv, "-lsamples") == 0) {
            q.listSamples = true;
        } else if (strcmp(*argv, "-ldata") == 0) {
            q.listData = true;
        } else if (strcmp(*argv, "-genumid") == 0) {
            q.generateUmid = true;
        } else if (strcmp(*argv, "-afd") == 0) {
            if (q.afd != (unsigned int)~0)
                usage("-afd specified twice\n");
            sscanf(getArg(argc, argv), "%x", &q.afd);
        } else if (**argv == '-') {
            usage("unknown flag: %s\n", *argv);
        } else {
            if (q.nInputs >= QueryInfo::maxInputs) {
                fatalErr("too many inputs specified (max %d)\n",
                    QueryInfo::maxInputs);
            }
            q.inputs[ q.nInputs++ ] = *argv;
        }
    }

    if (q.nInputs == 0)
        usage("no files specified\n");

    query(q);

    return pauseExec ( 0 );
}

#include "ommedia.h"
#include <stdio.h>
#ifdef WIN32
#include <process.h>
#endif
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>

bool pauseAtExit = false;

static bool errMsg(const char* format, ...)
{
    va_list argList;
    va_start(argList, format);
    vfprintf(stderr, format, argList);
    return false;
}

static void usage(const char* format, ...)
{
    va_list argList;
    va_start(argList, format);
    vfprintf(stderr, format, argList);
    printf("Usage: ommrename <options> oldname newname\n"
           "where the options are:\n"
           "  -all      force reference media files to be renamed as well\n");
    omMediaShutdown();
    exit(1);
}

bool rename(const char* input, const char* output, bool renameAll)
{
    OmMediaQuery omq;

    if (! omq.setFile(input))
        return errMsg("can't open %s\n", input);
    if (! omq.rename(output, renameAll))
        return errMsg("can't rename %s to %s\n", input, output);
    return true;
}

int main(int argc, char**argv)
{
    char *input = 0, *output = 0;
    bool renameAll = false;

    for (argc--, argv++; argc; argc--, argv++) {
        if (strcmp(*argv, "-all") == 0) {
            renameAll = true;
        } else if (**argv == '-') {
            usage("unknown flag: %s\n", *argv);
        } else {
            if (input == 0)
                input = *argv;
            else if (output == 0)
                output = *argv;
            else
                usage("too many files specified\n");
        }
    }

    if (input == 0)
        usage("no input specified\n");
    if (output == 0)
        usage("no output specified\n");

    bool success = rename(input, output, renameAll);
    omMediaShutdown();
    return success ? 0 : 1;
}
